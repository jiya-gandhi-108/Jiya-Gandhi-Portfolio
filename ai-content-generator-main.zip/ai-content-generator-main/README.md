# ContentCraft — AI Content Generator

A full-stack, production-grade AI content platform with multi-agent orchestration, RAG memory, SEO intelligence, and multi-modal output.

---

## Architecture Overview

```
contentcraft/
├── frontend/          # React + Vite + TypeScript
│   └── src/
│       ├── components/      # UI, Editor, Agents, SEO, Calendar, Analytics
│       ├── pages/           # Dashboard, Generate, Calendar, Analytics, Settings
│       ├── hooks/           # Custom React hooks
│       ├── store/           # Zustand global state
│       ├── services/        # API client, WebSocket
│       ├── utils/           # Helpers, formatters
│       └── types/           # Shared TypeScript types
└── backend/           # Node.js + Express + TypeScript
    └── src/
        ├── agents/          # Multi-agent pipeline (Research→Outline→Draft→Edit→SEO)
        ├── api/             # Routes, Controllers, Validators
        ├── db/              # Postgres models, migrations (Prisma)
        ├── services/        # AI, SEO, Memory (RAG), Integrations, Cache
        ├── middleware/       # Auth, rate limiting, logging
        └── types/           # Shared types
```

---

## Tech Stack

### Frontend
| Layer | Tech |
|-------|------|
| Framework | React 18 + Vite |
| Language | TypeScript |
| State | Zustand |
| Styling | Tailwind CSS + CSS Modules |
| Editor | TipTap (Notion-style) |
| Charts | Recharts |
| Realtime | Socket.io-client |
| HTTP | Axios + React Query |
| Auth | Clerk |

### Backend
| Layer | Tech |
|-------|------|
| Runtime | Node.js 20+ |
| Framework | Express + TypeScript |
| ORM | Prisma |
| Database | PostgreSQL (primary) |
| Vector DB | pgvector (RAG memory) |
| Cache | Redis |
| Queue | BullMQ (agent jobs) |
| Auth | Clerk SDK |
| AI | Anthropic Claude (primary), OpenAI (fallback) |
| Image Gen | Stability AI / DALL-E 3 |
| Search | Serper API (live web data) |
| SEO | DataForSEO API |
| Realtime | Socket.io |
| Integrations | WordPress REST, Ghost Admin, Zapier webhooks |

---

## Features

1. **Multi-Modal Generation** — text, images, video scripts, voiceovers, carousels
2. **Context-Aware Memory** — brand voice, past content, audience targeting via pgvector RAG
3. **Real-Time Data** — live web scraping, SEO trends, news injection via Serper
4. **SEO Intelligence** — keyword clustering, intent detection, NLP optimization
5. **Content Planning Engine** — calendar, topic clusters, TOFU/MOFU/BOFU funnel
6. **Multi-Agent Orchestration** — Research → Outline → Draft → Edit → SEO pipeline
7. **Fine-Tuned Personalization** — style transfer, custom instruction pipelines
8. **AI Quality Control** — fluff removal, fact-checking, plagiarism detection
9. **Collaboration Workspace** — version history, comments, Notion-style editor
10. **API & Automation** — WordPress/Ghost/Webflow publish, Zapier/Make webhooks
11. **Prompt Abstraction** — template library, dynamic prompt builders
12. **Performance Optimization** — model routing, Redis caching, streaming
13. **Analytics & Feedback** — content scoring, CTR prediction, feedback loop
14. **Niche Specialization** — SEO blogs, LinkedIn ghostwriting, e-commerce modes

---

## Getting Started

### Prerequisites
- Node.js 20+
- PostgreSQL 15+ with pgvector extension
- Redis 7+
- API keys: Anthropic, OpenAI, Serper, DataForSEO, Stability AI, Clerk

### 1. Clone & Install

```bash
# Install frontend dependencies
cd frontend && npm install

# Install backend dependencies
cd ../backend && npm install
```

### 2. Environment Variables

Copy `.env.example` to `.env` in both `/frontend` and `/backend` and fill in your keys.

### 3. Database Setup

```bash
cd backend
npx prisma migrate dev
npx prisma db seed
```

### 4. Run Development

```bash
# Terminal 1 — Backend
cd backend && npm run dev

# Terminal 2 — Frontend
cd frontend && npm run dev
```

Frontend: http://localhost:5173  
Backend API: http://localhost:3001

---

## Agent Pipeline

```
User Input
    │
    ▼
┌─────────────────────────────────────┐
│          Agent Orchestrator          │
└─────────────────────────────────────┘
    │
    ├─► Agent 1: Research
    │     └─ Web search, trend injection, competitor analysis
    │
    ├─► Agent 2: Outline
    │     └─ Structure, topic clusters, funnel mapping
    │
    ├─► Agent 3: Draft
    │     └─ Brand-voice aware generation with RAG memory
    │
    ├─► Agent 4: Editor
    │     └─ Fluff removal, clarity, tone adjustment
    │
    └─► Agent 5: SEO Optimizer
          └─ Keyword density, headings, meta, readability
```

---

## Deployment

- **Frontend**: Vercel / Netlify
- **Backend**: Railway / Render / AWS ECS
- **Database**: Supabase (Postgres + pgvector) or Neon
- **Redis**: Upstash or Railway Redis
- **Queue**: BullMQ workers as separate process/container
