import { create } from 'zustand'
import { subscribeWithSelector } from 'zustand/middleware'
import { immer } from 'zustand/middleware/immer'
import type {
  AgentJob,
  Content,
  GenerateRequest,
  Workspace,
  WorkspaceSettings,
} from '@/types'
import { api } from '@/services/api'
import { wsClient } from '@/services/websocket'

// ─── Generation Store ─────────────────────────────────────────────────────────

interface GenerationState {
  currentJob: AgentJob | null
  isGenerating: boolean
  streamingStep: string
  streamingText: string
  generatedContent: Content | null
  error: string | null
}

interface GenerationActions {
  startGeneration: (req: GenerateRequest) => Promise<void>
  cancelGeneration: () => void
  reset: () => void
  _setJobUpdate: (job: AgentJob) => void
  _appendStream: (text: string) => void
}

export const useGenerationStore = create<GenerationState & GenerationActions>()(
  subscribeWithSelector(
    immer((set, get) => ({
      currentJob: null,
      isGenerating: false,
      streamingStep: '',
      streamingText: '',
      generatedContent: null,
      error: null,

      startGeneration: async (req) => {
        set((s) => {
          s.isGenerating = true
          s.currentJob = null
          s.streamingText = ''
          s.streamingStep = 'Initializing agent pipeline…'
          s.generatedContent = null
          s.error = null
        })

        try {
          const { data } = await api.post<AgentJob>('/generate', req)
          set((s) => { s.currentJob = data })

          // Subscribe to live updates via WebSocket
          wsClient.subscribeToJob(data.id, {
            onStepUpdate: (job) => get()._setJobUpdate(job),
            onStream: (text) => get()._appendStream(text),
            onComplete: (content) => {
              set((s) => {
                s.isGenerating = false
                s.generatedContent = content
                s.streamingStep = 'Done'
              })
            },
            onError: (err) => {
              set((s) => {
                s.isGenerating = false
                s.error = err
              })
            },
          })
        } catch (err: any) {
          set((s) => {
            s.isGenerating = false
            s.error = err?.response?.data?.error || 'Generation failed'
          })
        }
      },

      cancelGeneration: () => {
        const { currentJob } = get()
        if (currentJob) {
          api.delete(`/generate/${currentJob.id}`)
          wsClient.unsubscribeFromJob(currentJob.id)
        }
        set((s) => {
          s.isGenerating = false
          s.currentJob = null
          s.streamingText = ''
        })
      },

      reset: () => {
        set((s) => {
          s.currentJob = null
          s.isGenerating = false
          s.streamingStep = ''
          s.streamingText = ''
          s.generatedContent = null
          s.error = null
        })
      },

      _setJobUpdate: (job) => {
        set((s) => {
          s.currentJob = job
          const runningStep = job.steps.find((step) => step.status === 'running')
          if (runningStep) s.streamingStep = runningStep.name
        })
      },

      _appendStream: (text) => {
        set((s) => { s.streamingText += text })
      },
    }))
  )
)

// ─── Workspace Store ──────────────────────────────────────────────────────────

interface WorkspaceState {
  workspace: Workspace | null
  isLoading: boolean
}

interface WorkspaceActions {
  setWorkspace: (w: Workspace) => void
  fetchWorkspace: (id: string) => Promise<void>
  updateSettings: (settings: Partial<WorkspaceSettings>) => Promise<void>
}

export const useWorkspaceStore = create<WorkspaceState & WorkspaceActions>()(
  immer((set, get) => ({
    workspace: null,
    isLoading: false,

    setWorkspace: (w) => set((s) => { s.workspace = w }),

    fetchWorkspace: async (id) => {
      set((s) => { s.isLoading = true })
      try {
        const { data } = await api.get<Workspace>(`/workspaces/${id}`)
        set((s) => { s.workspace = data; s.isLoading = false })
      } catch {
        set((s) => { s.isLoading = false })
      }
    },

    updateSettings: async (settings) => {
      const { workspace } = get()
      if (!workspace) return
      try {
        await api.patch(`/workspaces/${workspace.id}/settings`, settings)
        set((s) => {
          if (s.workspace) {
            s.workspace.settings = { ...s.workspace.settings, ...settings }
          }
        })
      } catch (err) {
        console.error('Failed to update settings', err)
      }
    },
  }))
)

// ─── UI Store ─────────────────────────────────────────────────────────────────

interface UIState {
  sidebarOpen: boolean
  theme: 'light' | 'dark'
  activePanel: 'generate' | 'editor' | 'seo' | 'calendar' | 'analytics' | 'settings'
}

interface UIActions {
  toggleSidebar: () => void
  setTheme: (t: 'light' | 'dark') => void
  setActivePanel: (p: UIState['activePanel']) => void
}

export const useUIStore = create<UIState & UIActions>()(
  immer((set) => ({
    sidebarOpen: true,
    theme: 'light',
    activePanel: 'generate',

    toggleSidebar: () => set((s) => { s.sidebarOpen = !s.sidebarOpen }),
    setTheme: (t) => set((s) => { s.theme = t }),
    setActivePanel: (p) => set((s) => { s.activePanel = p }),
  }))
)
