import { useEffect, useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ClerkProvider, useAuth, SignIn, SignUp } from '@clerk/clerk-react'
import { Toaster } from 'react-hot-toast'

import { AppLayout } from '@/components/ui/AppLayout'
import { DashboardPage } from '@/pages/dashboard/DashboardPage'
import { GeneratePage } from '@/pages/generate/GeneratePage'
import { WorkspacePage } from '@/pages/workspace/WorkspacePage'
import { AnalyticsPage } from '@/pages/analytics/AnalyticsPage'
import { SettingsPage } from '@/pages/settings/SettingsPage'
import { FeedPage } from '@/pages/feed/FeedPage'
import { wsClient } from '@/services/websocket'
import { setAuthToken } from '@/services/api'
import { useWorkspaceStore } from '@/store'
import { api } from '@/services/api'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 1000 * 60 * 5, retry: 2 },
  },
})

function ProtectedRoutes() {
  const { getToken, isSignedIn, isLoaded, userId } = useAuth()
  const setWorkspace = useWorkspaceStore(s => s.setWorkspace)
  const [tokenReady, setTokenReady] = useState(false)

  useEffect(() => {
    if (!isSignedIn) return

    const init = async () => {
      const token = await getToken()
      if (token) {
        setAuthToken(token)
        wsClient.connect(token)
        setTokenReady(true)
      }
    }

    init()

    const interval = setInterval(async () => {
      const token = await getToken()
      setAuthToken(token)
    }, 50_000)

    return () => {
      clearInterval(interval)
      wsClient.disconnect()
    }
  }, [isSignedIn, getToken])

  useEffect(() => {
    if (!tokenReady || !userId) return
    api.get('/workspaces/me')
      .then(r => setWorkspace(r.data))
      .catch(() => {})
  }, [tokenReady, userId, setWorkspace])

  if (!isLoaded) return null
  if (!isSignedIn) return <Navigate to="/sign-in" replace />
  if (!tokenReady) return (
    <div className="flex items-center justify-center h-screen bg-ink-50">
      <div className="text-center space-y-3">
        <div className="w-8 h-8 border-2 border-sage-500 border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-sm text-ink-500 font-body">Loading...</p>
      </div>
    </div>
  )

  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/generate" element={<GeneratePage />} />
        <Route path="/workspace/:contentId?" element={<WorkspacePage />} />
        <Route path="/analytics" element={<AnalyticsPage />} />
        <Route path="/settings/*" element={<SettingsPage />} />
        <Route path="/feed" element={<FeedPage />} />
      </Routes>
    </AppLayout>
  )
}

export default function App() {
  return (
    <ClerkProvider publishableKey={import.meta.env.VITE_CLERK_PUBLISHABLE_KEY}>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <Routes>
            <Route path="/sign-in/*" element={<SignIn routing="path" path="/sign-in" />} />
            <Route path="/sign-up/*" element={<SignUp routing="path" path="/sign-up" />} />
            <Route path="/*" element={<ProtectedRoutes />} />
          </Routes>
        </BrowserRouter>
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              fontFamily: '"DM Sans", sans-serif',
              fontSize: '14px',
              borderRadius: '8px',
              background: '#1e1b17',
              color: '#f4f3f0',
            },
          }}
        />
      </QueryClientProvider>
    </ClerkProvider>
  )
}
