import { Link, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard, Wand2, FileText, Calendar,
  BarChart3, Settings, ChevronLeft, Zap, Globe,
} from 'lucide-react'
import { useUIStore } from '@/store'
import { UserButton } from '@clerk/clerk-react'
import clsx from 'clsx'

const NAV_ITEMS = [
  { to: '/dashboard',  icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/generate',   icon: Wand2,           label: 'Generate' },
  { to: '/workspace',  icon: FileText,         label: 'Workspace' },
  { to: '/feed',       icon: Globe,            label: 'Team Feed' },
  { to: '/analytics',  icon: BarChart3,        label: 'Analytics' },
  { to: '/settings',   icon: Settings,         label: 'Settings' },
]

interface Props { children: React.ReactNode }

export function AppLayout({ children }: Props) {
  const { sidebarOpen, toggleSidebar } = useUIStore()
  const location = useLocation()

  return (
    <div className="flex h-screen bg-ink-50 font-body overflow-hidden">
      {/* Sidebar */}
      <motion.aside
        animate={{ width: sidebarOpen ? 220 : 64 }}
        transition={{ type: 'spring', stiffness: 280, damping: 30 }}
        className="flex flex-col bg-ink-950 border-r border-ink-800 z-20 overflow-hidden flex-shrink-0"
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-ink-800">
          <div className="w-8 h-8 bg-sage-500 rounded-lg flex items-center justify-center flex-shrink-0">
            <Zap size={16} className="text-white" />
          </div>
          <AnimatePresence>
            {sidebarOpen && (
              <motion.span
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -8 }}
                className="text-white font-display text-lg leading-none"
              >
                content<span className="text-sage-400 italic">craft</span>
              </motion.span>
            )}
          </AnimatePresence>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-2 space-y-0.5">
          {NAV_ITEMS.map(({ to, icon: Icon, label }) => {
            const active = location.pathname.startsWith(to)
            return (
              <Link
                key={to}
                to={to}
                className={clsx(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all group',
                  active
                    ? 'bg-sage-600 text-white'
                    : 'text-ink-400 hover:bg-ink-800 hover:text-ink-100'
                )}
              >
                <Icon size={18} className="flex-shrink-0" />
                <AnimatePresence>
                  {sidebarOpen && (
                    <motion.span
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="text-sm font-medium truncate"
                    >
                      {label}
                    </motion.span>
                  )}
                </AnimatePresence>
              </Link>
            )
          })}
        </nav>

        {/* Footer */}
        <div className="p-3 border-t border-ink-800 flex items-center gap-3">
          <UserButton afterSignOutUrl="/sign-in" />
          <AnimatePresence>
            {sidebarOpen && (
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={toggleSidebar}
                className="ml-auto text-ink-500 hover:text-ink-300 transition-colors"
              >
                <ChevronLeft size={16} />
              </motion.button>
            )}
          </AnimatePresence>
        </div>
      </motion.aside>

      {/* Collapsed sidebar toggle */}
      {!sidebarOpen && (
        <button
          onClick={toggleSidebar}
          className="absolute left-16 top-1/2 -translate-y-1/2 z-30 bg-ink-800 text-ink-300
                     hover:bg-sage-600 hover:text-white rounded-r-lg px-1 py-3 transition-all"
        >
          <ChevronLeft size={14} className="rotate-180" />
        </button>
      )}

      {/* Main */}
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  )
}
