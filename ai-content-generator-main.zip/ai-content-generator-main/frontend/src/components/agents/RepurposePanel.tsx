import { useState } from 'react'
import { X, Loader2, Copy, ChevronDown, ChevronUp } from 'lucide-react'
import { contentApi } from '@/services/api'
import type { Content, ContentType } from '@/types'
import toast from 'react-hot-toast'
import clsx from 'clsx'

const REPURPOSE_OPTIONS: { value: ContentType; label: string; icon: string; desc: string }[] = [
  { value: 'twitter_thread',   label: 'Twitter Thread',   icon: '𝕏',  desc: '10-tweet thread' },
  { value: 'linkedin_post',    label: 'LinkedIn Post',    icon: '💼', desc: 'Long-form professional' },
  { value: 'email_newsletter', label: 'Email Newsletter', icon: '📧', desc: 'With subject + CTA' },
  { value: 'carousel',         label: 'Carousel Slides',  icon: '🎠', desc: '10-slide outline' },
  { value: 'video_script',     label: 'Video Script',     icon: '🎬', desc: 'Hook + body + CTA' },
  { value: 'ad_copy',          label: 'Ad Variations',    icon: '📣', desc: '3 ad copy variants' },
]

interface Props {
  content: Content
  onClose: () => void
}

export function RepurposePanel({ content, onClose }: Props) {
  const [selected, setSelected] = useState<Set<ContentType>>(new Set())
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<Content['repurposed']>([])
  const [expanded, setExpanded] = useState<string | null>(null)

  const toggle = (type: ContentType) => {
    setSelected(s => {
      const next = new Set(s)
      next.has(type) ? next.delete(type) : next.add(type)
      return next
    })
  }

  const handleRepurpose = async () => {
    if (selected.size === 0) { toast.error('Select at least one format'); return }
    setLoading(true)
    try {
      const { data } = await contentApi.repurpose(content.id, Array.from(selected))
      setResults(data.repurposed)
      toast.success(`Repurposed into ${data.repurposed.length} formats!`)
    } catch {
      toast.error('Repurposing failed')
    } finally {
      setLoading(false)
    }
  }

  const copy = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success('Copied!')
  }

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="flex items-center justify-between px-4 py-3 border-b border-ink-200">
        <h3 className="font-semibold text-sm text-ink-800">Repurpose Content</h3>
        <button onClick={onClose} className="text-ink-400 hover:text-ink-700 transition">
          <X size={16} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Format selection */}
        <div>
          <p className="text-xs font-medium text-ink-500 uppercase tracking-wider mb-3">Select formats</p>
          <div className="space-y-2">
            {REPURPOSE_OPTIONS.map(({ value, label, icon, desc }) => (
              <div
                key={value}
                onClick={() => toggle(value)}
                className={clsx(
                  'flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition',
                  selected.has(value) ? 'border-sage-400 bg-sage-50' : 'border-ink-200 hover:border-ink-300'
                )}
              >
                <span className="text-lg">{icon}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-ink-800">{label}</p>
                  <p className="text-xs text-ink-400">{desc}</p>
                </div>
                <div className={clsx(
                  'w-4 h-4 rounded border-2 flex items-center justify-center transition',
                  selected.has(value) ? 'bg-sage-500 border-sage-500' : 'border-ink-300'
                )}>
                  {selected.has(value) && <div className="w-2 h-2 bg-white rounded-sm" />}
                </div>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={handleRepurpose}
          disabled={loading || selected.size === 0}
          className="w-full py-2.5 bg-ink-900 text-white rounded-lg text-sm font-medium
                     hover:bg-ink-700 disabled:opacity-50 disabled:cursor-not-allowed
                     flex items-center justify-center gap-2 transition"
        >
          {loading ? <><Loader2 size={14} className="animate-spin" /> Repurposing…</> : `Repurpose into ${selected.size} format${selected.size !== 1 ? 's' : ''}`}
        </button>

        {/* Results */}
        {results && results.length > 0 && (
          <div>
            <p className="text-xs font-medium text-ink-500 uppercase tracking-wider mb-3">Results</p>
            <div className="space-y-2">
              {results.map((r) => {
                const opt = REPURPOSE_OPTIONS.find(o => o.value === r.type)
                return (
                  <div key={r.id} className="border border-ink-200 rounded-lg overflow-hidden">
                    <div
                      className="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-ink-50 transition"
                      onClick={() => setExpanded(expanded === r.id ? null : r.id)}
                    >
                      <span>{opt?.icon}</span>
                      <span className="text-sm font-medium text-ink-700 flex-1">{opt?.label}</span>
                      <button
                        onClick={(e) => { e.stopPropagation(); copy(r.body) }}
                        className="text-ink-400 hover:text-ink-700 p-1"
                      >
                        <Copy size={12} />
                      </button>
                      {expanded === r.id ? <ChevronUp size={14} className="text-ink-400" /> : <ChevronDown size={14} className="text-ink-400" />}
                    </div>
                    {expanded === r.id && (
                      <div className="px-3 pb-3 text-xs text-ink-600 leading-relaxed whitespace-pre-wrap border-t border-ink-100 pt-2">
                        {r.body}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
