import { useQuery } from '@tanstack/react-query'
import { X, TrendingUp, AlertCircle, Info, CheckCircle2, Loader2 } from 'lucide-react'
import { contentApi } from '@/services/api'
import type { SEOAnalysis } from '@/types'
import clsx from 'clsx'

interface Props {
  contentId: string
  onClose: () => void
}

export function SEOPanel({ contentId, onClose }: Props) {
  const { data: seo, isLoading } = useQuery<SEOAnalysis>({
    queryKey: ['seo', contentId],
    queryFn: () => contentApi.analyze(contentId).then(r => r.data),
  })

  const scoreColor = (score: number) =>
    score >= 80 ? 'text-sage-600' : score >= 60 ? 'text-amber-500' : 'text-red-500'

  const scoreRing = (score: number) =>
    score >= 80 ? 'stroke-sage-500' : score >= 60 ? 'stroke-amber-400' : 'stroke-red-400'

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="flex items-center justify-between px-4 py-3 border-b border-ink-200">
        <h3 className="font-semibold text-sm text-ink-800 flex items-center gap-2">
          <TrendingUp size={14} className="text-sage-500" />
          SEO Analysis
        </h3>
        <button onClick={onClose} className="text-ink-400 hover:text-ink-700">
          <X size={16} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-5">
        {isLoading && (
          <div className="flex items-center justify-center py-12">
            <Loader2 size={20} className="animate-spin text-sage-500" />
          </div>
        )}

        {seo && (
          <>
            {/* Score Ring */}
            <div className="flex items-center justify-center gap-6">
              <div className="text-center">
                <ScoreRing score={seo.score} label="SEO Score" />
              </div>
              <div className="text-center">
                <ScoreRing score={seo.readabilityScore} label="Readability" />
              </div>
            </div>

            {/* Meta suggestions */}
            {seo.metaTitle && (
              <div className="space-y-2">
                <p className="text-xs font-medium text-ink-500 uppercase tracking-wider">Suggested Meta</p>
                <div className="bg-ink-50 rounded-lg p-3 space-y-2">
                  <div>
                    <p className="text-xs text-ink-400">Title</p>
                    <p className="text-sm text-ink-800 font-medium">{seo.metaTitle}</p>
                  </div>
                  {seo.metaDescription && (
                    <div>
                      <p className="text-xs text-ink-400">Description</p>
                      <p className="text-sm text-ink-700">{seo.metaDescription}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Keyword density */}
            <div>
              <p className="text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">Keyword Density</p>
              <div className="space-y-1.5">
                {Object.entries(seo.keywordDensity).slice(0, 8).map(([kw, density]) => (
                  <div key={kw} className="flex items-center gap-2">
                    <span className="text-xs text-ink-700 flex-1 truncate">{kw}</span>
                    <div className="w-20 h-1.5 bg-ink-100 rounded-full overflow-hidden">
                      <div
                        className={clsx('h-full rounded-full', density > 3 ? 'bg-red-400' : density >= 1 ? 'bg-sage-500' : 'bg-ink-300')}
                        style={{ width: `${Math.min(density * 25, 100)}%` }}
                      />
                    </div>
                    <span className="text-xs text-ink-400 w-10 text-right">{density.toFixed(1)}%</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Heading structure */}
            <div>
              <p className="text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">Heading Structure</p>
              <div className="space-y-1">
                {seo.headingStructure.map((h, i) => (
                  <div key={i} className="flex items-center gap-2" style={{ paddingLeft: (h.level - 1) * 12 }}>
                    <span className="text-xs font-mono text-ink-400 w-6">H{h.level}</span>
                    <span className="text-xs text-ink-700 truncate">{h.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Suggestions */}
            <div>
              <p className="text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
                Suggestions ({seo.suggestions.length})
              </p>
              <div className="space-y-2">
                {seo.suggestions.map((s, i) => (
                  <div key={i} className={clsx(
                    'flex items-start gap-2 p-2.5 rounded-lg text-xs',
                    s.type === 'error' ? 'bg-red-50 text-red-700' :
                    s.type === 'warning' ? 'bg-amber-50 text-amber-700' :
                    'bg-blue-50 text-blue-700'
                  )}>
                    {s.type === 'error' ? <AlertCircle size={12} className="mt-0.5 flex-shrink-0" /> :
                     s.type === 'warning' ? <AlertCircle size={12} className="mt-0.5 flex-shrink-0" /> :
                     <Info size={12} className="mt-0.5 flex-shrink-0" />}
                    <div>
                      <p className="font-medium">{s.message}</p>
                      {s.fix && <p className="opacity-75 mt-0.5">{s.fix}</p>}
                    </div>
                  </div>
                ))}
                {seo.suggestions.length === 0 && (
                  <div className="flex items-center gap-2 p-2.5 bg-sage-50 rounded-lg text-xs text-sage-700">
                    <CheckCircle2 size={12} />
                    <span>No SEO issues found. Great work!</span>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

function ScoreRing({ score, label }: { score: number; label: string }) {
  const r = 28
  const circ = 2 * Math.PI * r
  const offset = circ - (score / 100) * circ
  const color = score >= 80 ? '#528444' : score >= 60 ? '#f59e0b' : '#ef4444'

  return (
    <div className="flex flex-col items-center gap-1">
      <svg width={72} height={72} viewBox="0 0 72 72">
        <circle cx={36} cy={36} r={r} fill="none" stroke="#e8e6e0" strokeWidth={6} />
        <circle
          cx={36} cy={36} r={r}
          fill="none"
          stroke={color}
          strokeWidth={6}
          strokeDasharray={circ}
          strokeDashoffset={offset}
          strokeLinecap="round"
          transform="rotate(-90 36 36)"
          style={{ transition: 'stroke-dashoffset 0.6s ease' }}
        />
        <text x={36} y={40} textAnchor="middle" fontSize={14} fontWeight={700} fill={color}>
          {score}
        </text>
      </svg>
      <span className="text-xs text-ink-500">{label}</span>
    </div>
  )
}
