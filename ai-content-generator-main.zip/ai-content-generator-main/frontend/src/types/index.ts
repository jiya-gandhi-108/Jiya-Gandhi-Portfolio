// ─── Content Types ────────────────────────────────────────────────────────────

export type ContentType =
  | 'blog'
  | 'twitter_thread'
  | 'linkedin_post'
  | 'email_newsletter'
  | 'ad_copy'
  | 'video_script'
  | 'carousel'
  | 'product_description'

export type ContentStatus = 'draft' | 'in_progress' | 'review' | 'published' | 'scheduled'

export type FunnelStage = 'TOFU' | 'MOFU' | 'BOFU'

export type Tone =
  | 'professional'
  | 'casual'
  | 'persuasive'
  | 'witty'
  | 'inspirational'
  | 'authoritative'
  | 'empathetic'

export interface Content {
  id: string
  workspaceId: string
  title: string
  body: string
  type: ContentType
  status: ContentStatus
  tone: Tone
  keywords: string[]
  seoScore: number
  readabilityScore: number
  wordCount: number
  funnelStage?: FunnelStage
  publishedAt?: string
  scheduledAt?: string
  createdAt: string
  updatedAt: string
  versions: ContentVersion[]
  comments: Comment[]
  repurposed?: RepurposedContent[]
  mediaAssets?: MediaAsset[]
}

export interface ContentVersion {
  id: string
  contentId: string
  body: string
  createdAt: string
  createdBy: User
  label?: string
}

export interface RepurposedContent {
  id: string
  type: ContentType
  body: string
  platform: string
}

// ─── Agent Types ──────────────────────────────────────────────────────────────

export type AgentStatus = 'idle' | 'running' | 'done' | 'error'

export interface AgentStep {
  id: string
  name: string
  description: string
  status: AgentStatus
  output?: string
  tokensUsed?: number
  model?: string
  durationMs?: number
  startedAt?: string
  completedAt?: string
}

export interface AgentJob {
  id: string
  status: 'queued' | 'running' | 'completed' | 'failed'
  steps: AgentStep[]
  result?: Content
  error?: string
  createdAt: string
}

export interface GenerateRequest {
  topic: string
  contentType: ContentType
  tone: Tone
  targetAudience: 'beginner' | 'intermediate' | 'expert'
  funnelStage?: FunnelStage
  keywords?: string[]
  useRealTimeData?: boolean
  useBrandVoice?: boolean
  outputFormats?: ContentType[]
  niche?: string
  workspaceId: string
  wordLimit?: number
}

// ─── SEO Types ────────────────────────────────────────────────────────────────

export interface KeywordData {
  keyword: string
  searchVolume: number
  difficulty: number
  cpc: number
  intent: 'informational' | 'navigational' | 'transactional' | 'commercial'
  relatedKeywords: string[]
}

export interface SEOAnalysis {
  score: number
  readabilityScore: number
  keywordDensity: Record<string, number>
  headingStructure: { level: number; text: string }[]
  suggestions: SEOSuggestion[]
  metaTitle?: string
  metaDescription?: string
  estimatedRank?: number
}

export interface SEOSuggestion {
  type: 'error' | 'warning' | 'info'
  message: string
  fix?: string
}

// ─── Memory / Brand Voice Types ───────────────────────────────────────────────

export interface BrandVoice {
  id: string
  workspaceId: string
  tone: Tone[]
  vocabulary: string[]
  avoidWords: string[]
  writingStyle: string
  targetAudiences: AudienceProfile[]
  sampleContent: string[]
  embeddingUpdatedAt: string
}

export interface AudienceProfile {
  id: string
  name: string
  description: string
  expertiseLevel: 'beginner' | 'intermediate' | 'expert'
  painPoints: string[]
  goals: string[]
}

// ─── Calendar Types ───────────────────────────────────────────────────────────

export interface CalendarEntry {
  id: string
  contentId?: string
  title: string
  type: ContentType
  status: ContentStatus
  scheduledAt: string
  platform?: string
  funnelStage?: FunnelStage
  assignedTo?: User
}

export interface TopicCluster {
  id: string
  pillarTopic: string
  subtopics: string[]
  funnelMapping: Record<string, FunnelStage>
  contentIds: string[]
}

// ─── Analytics Types ──────────────────────────────────────────────────────────

export interface ContentAnalytics {
  contentId: string
  views: number
  clicks: number
  ctr: number
  avgTimeOnPage: number
  bounceRate: number
  conversions: number
  seoRank?: number
  socialShares: number
  feedbackScore: number
  predictedCTR: number
}

export interface WorkspaceAnalytics {
  totalContent: number
  publishedThisMonth: number
  avgSeoScore: number
  avgReadabilityScore: number
  topPerformingContent: Content[]
  contentByType: Record<ContentType, number>
  contentByStatus: Record<ContentStatus, number>
  tokensUsed: number
  apiCost: number
}

// ─── Workspace / Collaboration Types ─────────────────────────────────────────

export interface Workspace {
  id: string
  name: string
  slug: string
  plan: 'free' | 'pro' | 'team' | 'enterprise'
  members: WorkspaceMember[]
  brandVoice?: BrandVoice
  integrations: Integration[]
  settings: WorkspaceSettings
}

export interface WorkspaceMember {
  userId: string
  user: User
  role: 'owner' | 'admin' | 'editor' | 'viewer'
  joinedAt: string
}

export interface User {
  id: string
  name: string
  email: string
  avatar?: string
}

export interface Comment {
  id: string
  contentId: string
  body: string
  createdBy: User
  createdAt: string
  resolved: boolean
  position?: { from: number; to: number }
}

export interface WorkspaceSettings {
  defaultTone: Tone
  defaultContentType: ContentType
  defaultAudience: string
  autoSeoOptimize: boolean
  autoPlagiarismCheck: boolean
  autoFactCheck: boolean
  modelPreference: 'fast' | 'balanced' | 'quality'
  niche?: string
}

// ─── Integration Types ────────────────────────────────────────────────────────

export interface Integration {
  id: string
  type: 'wordpress' | 'ghost' | 'webflow' | 'zapier' | 'make' | 'twitter' | 'linkedin'
  name: string
  connected: boolean
  config: Record<string, string>
  lastSyncAt?: string
}

// ─── Media Types ──────────────────────────────────────────────────────────────

export interface MediaAsset {
  id: string
  type: 'image' | 'video' | 'audio'
  url: string
  prompt?: string
  model?: string
  createdAt: string
}

// ─── API Response Types ───────────────────────────────────────────────────────

export interface ApiResponse<T> {
  data: T
  message?: string
  meta?: {
    page: number
    perPage: number
    total: number
  }
}

export interface ApiError {
  error: string
  details?: Record<string, string[]>
  code?: string
}

// ─── Store Types ──────────────────────────────────────────────────────────────

export interface GenerationStore {
  currentJob: AgentJob | null
  isGenerating: boolean
  streamingText: string
  startGeneration: (req: GenerateRequest) => Promise<void>
  cancelGeneration: () => void
  reset: () => void
}

export interface WorkspaceStore {
  workspace: Workspace | null
  setWorkspace: (w: Workspace) => void
  updateSettings: (s: Partial<WorkspaceSettings>) => void
}
