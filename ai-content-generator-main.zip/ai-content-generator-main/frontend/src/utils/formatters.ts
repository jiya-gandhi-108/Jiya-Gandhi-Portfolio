import { formatDistanceToNow, format, isToday, isYesterday } from 'date-fns'

// ─── Date ─────────────────────────────────────────────────────────────────────

export function formatRelativeDate(date: string | Date): string {
  const d = new Date(date)
  if (isToday(d))     return `Today at ${format(d, 'h:mm a')}`
  if (isYesterday(d)) return `Yesterday at ${format(d, 'h:mm a')}`
  return formatDistanceToNow(d, { addSuffix: true })
}

export function formatDate(date: string | Date, pattern = 'MMM d, yyyy'): string {
  return format(new Date(date), pattern)
}

export function formatDateTime(date: string | Date): string {
  return format(new Date(date), 'MMM d, yyyy · h:mm a')
}

// ─── Numbers ──────────────────────────────────────────────────────────────────

export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`
  return n.toLocaleString()
}

export function formatTokens(tokens: number): string {
  if (tokens >= 1_000_000) return `${(tokens / 1_000_000).toFixed(2)}M tokens`
  if (tokens >= 1_000)     return `${(tokens / 1_000).toFixed(1)}K tokens`
  return `${tokens} tokens`
}

export function formatCost(usd: number): string {
  if (usd < 0.001) return '<$0.001'
  if (usd < 1)     return `$${usd.toFixed(3)}`
  return `$${usd.toFixed(2)}`
}

export function formatPercent(value: number, decimals = 1): string {
  return `${value.toFixed(decimals)}%`
}

// ─── Content ──────────────────────────────────────────────────────────────────

export function estimateReadingTime(wordCount: number): string {
  const minutes = Math.ceil(wordCount / 200) // avg 200 wpm
  return minutes === 1 ? '1 min read' : `${minutes} min read`
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength).trimEnd() + '…'
}

export function stripMarkdown(markdown: string): string {
  return markdown
    .replace(/#{1,6}\s+/g, '')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/\*(.+?)\*/g, '$1')
    .replace(/\[(.+?)\]\(.+?\)/g, '$1')
    .replace(/`(.+?)`/g, '$1')
    .replace(/^\s*[-*+]\s+/gm, '')
    .replace(/^\s*\d+\.\s+/gm, '')
    .replace(/\n{2,}/g, '\n')
    .trim()
}

export function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length
}

// ─── Content types ────────────────────────────────────────────────────────────

export function formatContentType(type: string): string {
  const labels: Record<string, string> = {
    blog:             'Blog Post',
    twitter_thread:   'Twitter Thread',
    linkedin_post:    'LinkedIn Post',
    email_newsletter: 'Email Newsletter',
    ad_copy:          'Ad Copy',
    video_script:     'Video Script',
    carousel:         'Carousel',
    product_description: 'Product Description',
  }
  return labels[type] ?? type.replace(/_/g, ' ')
}

export function getContentTypeIcon(type: string): string {
  const icons: Record<string, string> = {
    blog:             '📝',
    twitter_thread:   '𝕏',
    linkedin_post:    '💼',
    email_newsletter: '📧',
    ad_copy:          '📣',
    video_script:     '🎬',
    carousel:         '🎠',
    product_description: '🛒',
  }
  return icons[type] ?? '📄'
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    draft:       'bg-ink-100 text-ink-600',
    in_progress: 'bg-amber-100 text-amber-700',
    review:      'bg-blue-100 text-blue-700',
    published:   'bg-sage-100 text-sage-700',
    scheduled:   'bg-purple-100 text-purple-700',
  }
  return colors[status] ?? 'bg-ink-100 text-ink-600'
}

export function getSEOScoreColor(score: number): string {
  if (score >= 80) return 'text-sage-600'
  if (score >= 60) return 'text-amber-500'
  return 'text-red-500'
}

export function getSEOScoreLabel(score: number): string {
  if (score >= 80) return 'Excellent'
  if (score >= 60) return 'Good'
  if (score >= 40) return 'Needs work'
  return 'Poor'
}
