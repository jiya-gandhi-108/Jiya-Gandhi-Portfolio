// ─── String ───────────────────────────────────────────────────────────────────

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export function isValidUrl(url: string): boolean {
  try {
    new URL(url)
    return true
  } catch {
    return false
  }
}

export function isNonEmpty(value: string): boolean {
  return value.trim().length > 0
}

export function isBetween(value: string, min: number, max: number): boolean {
  return value.trim().length >= min && value.trim().length <= max
}

// ─── Content validation ───────────────────────────────────────────────────────

export interface ContentFormErrors {
  topic?: string
  keywords?: string
  tone?: string
}

export function validateGenerateForm(values: {
  topic: string
  keywords: string
  contentType: string
}): ContentFormErrors {
  const errors: ContentFormErrors = {}

  if (!isNonEmpty(values.topic)) {
    errors.topic = 'Topic is required'
  } else if (!isBetween(values.topic, 3, 500)) {
    errors.topic = 'Topic must be between 3 and 500 characters'
  }

  if (values.keywords) {
    const kwList = values.keywords.split(',').map(k => k.trim()).filter(Boolean)
    if (kwList.length > 20) {
      errors.keywords = 'Maximum 20 keywords allowed'
    }
    if (kwList.some(k => k.length > 60)) {
      errors.keywords = 'Each keyword must be under 60 characters'
    }
  }

  return errors
}

export function validateBrandVoiceForm(values: {
  writingStyle: string
  vocabulary: string
  avoidWords: string
}): Record<string, string> {
  const errors: Record<string, string> = {}

  if (values.writingStyle && values.writingStyle.length > 1000) {
    errors.writingStyle = 'Writing style description must be under 1000 characters'
  }

  return errors
}

export function validateIntegrationConfig(
  type: string,
  config: Record<string, string>
): Record<string, string> {
  const errors: Record<string, string> = {}

  if (type === 'wordpress') {
    if (!isValidUrl(config.siteUrl || '')) errors.siteUrl = 'Valid site URL required'
    if (!config.username)   errors.username = 'Username required'
    if (!config.appPassword) errors.appPassword = 'Application password required'
  }

  if (type === 'ghost') {
    if (!isValidUrl(config.adminUrl || '')) errors.adminUrl = 'Valid admin URL required'
    if (!config.adminApiKey) errors.adminApiKey = 'Admin API key required'
  }

  if (type === 'zapier' || type === 'make') {
    if (!isValidUrl(config.webhookUrl || '')) errors.webhookUrl = 'Valid webhook URL required'
  }

  return errors
}

// ─── Sanitize ─────────────────────────────────────────────────────────────────

export function sanitizeKeywords(raw: string): string[] {
  return raw
    .split(',')
    .map(k => k.trim().toLowerCase())
    .filter(k => k.length > 0 && k.length <= 60)
    .slice(0, 20)
}

export function sanitizeSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 80)
}
