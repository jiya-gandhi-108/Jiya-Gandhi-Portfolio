import { clsx, type ClassValue } from 'clsx'

/**
 * Merge class names with clsx.
 * Drop-in replacement for clsx that also handles conditional classes.
 *
 * Usage:
 *   cn('base-class', isActive && 'active', { 'conditional': flag })
 */
export function cn(...inputs: ClassValue[]): string {
  return clsx(...inputs)
}
