// ─── Markdown → Plain Text ────────────────────────────────────────────────────

export function markdownToPlainText(markdown: string): string {
  return markdown
    .replace(/^#{1,6}\s+(.+)$/gm, '$1')      // headings
    .replace(/\*\*(.+?)\*\*/g, '$1')          // bold
    .replace(/\*(.+?)\*/g, '$1')              // italic
    .replace(/~~(.+?)~~/g, '$1')             // strikethrough
    .replace(/`{3}[\s\S]+?`{3}/g, '')        // code blocks
    .replace(/`(.+?)`/g, '$1')               // inline code
    .replace(/\[(.+?)\]\(.+?\)/g, '$1')      // links
    .replace(/!\[.+?\]\(.+?\)/g, '')         // images
    .replace(/^\s*[-*+]\s+/gm, '')           // unordered lists
    .replace(/^\s*\d+\.\s+/gm, '')           // ordered lists
    .replace(/^\s*>\s+/gm, '')               // blockquotes
    .replace(/---+/g, '')                    // horizontal rules
    .replace(/\n{3,}/g, '\n\n')             // excessive newlines
    .trim()
}

// ─── Extract sections ─────────────────────────────────────────────────────────

export interface MarkdownSection {
  level: number
  heading: string
  content: string
}

export function extractSections(markdown: string): MarkdownSection[] {
  const lines = markdown.split('\n')
  const sections: MarkdownSection[] = []
  let current: MarkdownSection | null = null

  for (const line of lines) {
    const headingMatch = line.match(/^(#{1,6})\s+(.+)$/)
    if (headingMatch) {
      if (current) sections.push(current)
      current = {
        level: headingMatch[1].length,
        heading: headingMatch[2].trim(),
        content: '',
      }
    } else if (current) {
      current.content += line + '\n'
    }
  }

  if (current) sections.push(current)
  return sections
}

// ─── Extract title (first H1) ─────────────────────────────────────────────────

export function extractTitle(markdown: string): string | null {
  const match = markdown.match(/^#\s+(.+)$/m)
  return match ? match[1].trim() : null
}

// ─── Extract headings ─────────────────────────────────────────────────────────

export function extractHeadings(markdown: string): { level: number; text: string }[] {
  const lines = markdown.split('\n')
  return lines
    .map(line => {
      const m = line.match(/^(#{1,6})\s+(.+)$/)
      return m ? { level: m[1].length, text: m[2].trim() } : null
    })
    .filter(Boolean) as { level: number; text: string }[]
}

// ─── Count words ─────────────────────────────────────────────────────────────

export function countMarkdownWords(markdown: string): number {
  const plain = markdownToPlainText(markdown)
  return plain.split(/\s+/).filter(Boolean).length
}

// ─── Estimate reading time ────────────────────────────────────────────────────

export function readingTime(markdown: string, wpm = 200): number {
  return Math.ceil(countMarkdownWords(markdown) / wpm)
}

// ─── Keyword density in text ──────────────────────────────────────────────────

export function keywordDensity(text: string, keyword: string): number {
  const plain = markdownToPlainText(text).toLowerCase()
  const words = plain.split(/\s+/).length
  const kw = keyword.toLowerCase()
  const regex = new RegExp(`\\b${kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'g')
  const count = (plain.match(regex) || []).length
  return words > 0 ? parseFloat(((count / words) * 100).toFixed(2)) : 0
}

// ─── Simple Flesch readability ────────────────────────────────────────────────

function countSyllables(word: string): number {
  word = word.toLowerCase().replace(/[^a-z]/g, '')
  if (word.length <= 3) return 1
  const matches = word.match(/[aeiouy]{1,2}/g)
  return matches ? matches.length : 1
}

export function fleschReadingEase(text: string): number {
  const plain = markdownToPlainText(text)
  const sentences = plain.split(/[.!?]+/).filter(s => s.trim().length > 0)
  const words = plain.split(/\s+/).filter(Boolean)

  if (sentences.length === 0 || words.length === 0) return 0

  const syllables = words.reduce((acc, w) => acc + countSyllables(w), 0)
  const avgSentLen = words.length / sentences.length
  const avgSyllables = syllables / words.length

  const score = 206.835 - 1.015 * avgSentLen - 84.6 * avgSyllables
  return Math.min(100, Math.max(0, Math.round(score)))
}

export function readabilityLabel(score: number): string {
  if (score >= 90) return 'Very Easy'
  if (score >= 80) return 'Easy'
  if (score >= 70) return 'Fairly Easy'
  if (score >= 60) return 'Standard'
  if (score >= 50) return 'Fairly Difficult'
  if (score >= 30) return 'Difficult'
  return 'Very Difficult'
}
