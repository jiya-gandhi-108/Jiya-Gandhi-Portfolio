import { io, Socket } from 'socket.io-client'
import type { AgentJob, Content } from '@/types'

interface JobCallbacks {
  onStepUpdate: (job: AgentJob) => void
  onStream: (text: string) => void
  onComplete: (content: Content) => void
  onError: (error: string) => void
}

class WebSocketClient {
  private socket: Socket | null = null
  private subscriptions = new Map<string, JobCallbacks>()

  connect(token: string) {
    if (this.socket?.connected) return

    this.socket = io(import.meta.env.VITE_WS_URL, {
      auth: { token },
      transports: ['websocket'],
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    })

    this.socket.on('connect', () => {
      console.log('[WS] Connected:', this.socket?.id)
    })

    this.socket.on('disconnect', (reason) => {
      console.log('[WS] Disconnected:', reason)
    })

    this.socket.on('job:step', (job: AgentJob) => {
      const cb = this.subscriptions.get(job.id)
      cb?.onStepUpdate(job)
    })

    this.socket.on('job:stream', ({ jobId, text }: { jobId: string; text: string }) => {
      const cb = this.subscriptions.get(jobId)
      cb?.onStream(text)
    })

    this.socket.on('job:complete', ({ jobId, content }: { jobId: string; content: Content }) => {
      const cb = this.subscriptions.get(jobId)
      cb?.onComplete(content)
      this.subscriptions.delete(jobId)
    })

    this.socket.on('job:error', ({ jobId, error }: { jobId: string; error: string }) => {
      const cb = this.subscriptions.get(jobId)
      cb?.onError(error)
      this.subscriptions.delete(jobId)
    })

    // Collaboration events
    this.socket.on('collab:cursor', (data) => {
      window.dispatchEvent(new CustomEvent('collab:cursor', { detail: data }))
    })

    this.socket.on('collab:update', (data) => {
      window.dispatchEvent(new CustomEvent('collab:update', { detail: data }))
    })
  }

  disconnect() {
    this.socket?.disconnect()
    this.socket = null
    this.subscriptions.clear()
  }

  subscribeToJob(jobId: string, callbacks: JobCallbacks) {
    this.subscriptions.set(jobId, callbacks)
    this.socket?.emit('job:subscribe', { jobId })
  }

  unsubscribeFromJob(jobId: string) {
    this.subscriptions.delete(jobId)
    this.socket?.emit('job:unsubscribe', { jobId })
  }

  joinContentRoom(contentId: string, userId: string) {
    this.socket?.emit('collab:join', { contentId, userId })
  }

  leaveContentRoom(contentId: string) {
    this.socket?.emit('collab:leave', { contentId })
  }

  sendCursorUpdate(contentId: string, position: { from: number; to: number }) {
    this.socket?.emit('collab:cursor', { contentId, position })
  }

  isConnected() {
    return this.socket?.connected ?? false
  }
}

export const wsClient = new WebSocketClient()
