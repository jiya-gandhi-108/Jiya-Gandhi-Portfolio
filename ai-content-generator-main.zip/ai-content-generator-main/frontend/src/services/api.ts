import axios from 'axios'
import toast from 'react-hot-toast'

export const api = axios.create({
  baseURL: `${import.meta.env.VITE_API_URL}/api`,
  timeout: 60_000,
  headers: { 'Content-Type': 'application/json' },
})

// ─── Auth token store — set via setAuthToken() after Clerk loads ──────────────
let _authToken: string | null = null

export function setAuthToken(token: string | null) {
  _authToken = token
}

// ─── Request Interceptor — attach token ───────────────────────────────────────
api.interceptors.request.use((config) => {
  if (_authToken) config.headers.Authorization = `Bearer ${_authToken}`
  return config
})

// ─── Response Interceptor — unified error handling ────────────────────────────
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const status = err?.response?.status
    const message = err?.response?.data?.error || 'Something went wrong'

    if (status === 401) {
      toast.error('Session expired. Please log in again.')
    } else if (status === 429) {
      toast.error('Rate limit hit. Slow down a bit!')
    } else if (status >= 500) {
      toast.error(`Server error: ${message}`)
    }

    return Promise.reject(err)
  }
)

// ─── Typed API helpers ────────────────────────────────────────────────────────

export const contentApi = {
  list: (workspaceId: string, params?: Record<string, any>) =>
    api.get(`/workspaces/${workspaceId}/content`, { params }),
  get: (id: string) => api.get(`/content/${id}`),
  create: (data: any) => api.post('/content', data),
  update: (id: string, data: any) => api.patch(`/content/${id}`, data),
  delete: (id: string) => api.delete(`/content/${id}`),
  repurpose: (id: string, targetTypes: string[]) =>
    api.post(`/content/${id}/repurpose`, { targetTypes }),
  publish: (id: string, integrationId: string) =>
    api.post(`/content/${id}/publish`, { integrationId }),
  analyze: (id: string) => api.get(`/content/${id}/seo`),
  score: (id: string) => api.get(`/content/${id}/score`),
  versions: (id: string) => api.get(`/content/${id}/versions`),
  restoreVersion: (id: string, versionId: string) =>
    api.post(`/content/${id}/versions/${versionId}/restore`),
}

export const seoApi = {
  keywords: (topic: string) => api.get('/seo/keywords', { params: { topic } }),
  competitors: (keyword: string) => api.get('/seo/competitors', { params: { keyword } }),
  trends: (topic: string) => api.get('/seo/trends', { params: { topic } }),
  analyze: (text: string, keywords: string[]) =>
    api.post('/seo/analyze', { text, keywords }),
}

export const calendarApi = {
  entries: (workspaceId: string, start: string, end: string) =>
    api.get(`/workspaces/${workspaceId}/calendar`, { params: { start, end } }),
  createEntry: (workspaceId: string, data: any) =>
    api.post(`/workspaces/${workspaceId}/calendar`, data),
  generatePlan: (workspaceId: string, params: any) =>
    api.post(`/workspaces/${workspaceId}/calendar/generate`, params),
  clusters: (workspaceId: string) =>
    api.get(`/workspaces/${workspaceId}/clusters`),
}

export const analyticsApi = {
  workspace: (workspaceId: string, range: string) =>
    api.get(`/workspaces/${workspaceId}/analytics`, { params: { range } }),
  content: (contentId: string) => api.get(`/content/${contentId}/analytics`),
  feedback: (contentId: string, score: number, comment?: string) =>
    api.post(`/content/${contentId}/feedback`, { score, comment }),
}

export const memoryApi = {
  getBrandVoice: (workspaceId: string) =>
    api.get(`/workspaces/${workspaceId}/brand-voice`),
  updateBrandVoice: (workspaceId: string, data: any) =>
    api.put(`/workspaces/${workspaceId}/brand-voice`, data),
  getSimilarContent: (workspaceId: string, topic: string) =>
    api.get(`/workspaces/${workspaceId}/similar`, { params: { topic } }),
}

export const mediaApi = {
  generateImage: (prompt: string, style?: string) =>
    api.post('/media/image', { prompt, style }),
  generateVoiceover: (text: string, voice?: string) =>
    api.post('/media/voiceover', { text, voice }),
  list: (workspaceId: string) => api.get(`/workspaces/${workspaceId}/media`),
}
