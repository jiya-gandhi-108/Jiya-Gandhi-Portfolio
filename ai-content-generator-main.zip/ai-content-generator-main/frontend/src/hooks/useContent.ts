import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useWorkspaceStore } from '@/store'
import { contentApi } from '@/services/api'
import type { Content, ContentType, ContentStatus } from '@/types'
import toast from 'react-hot-toast'

interface UseContentOptions {
  page?: number
  perPage?: number
  type?: ContentType
  status?: ContentStatus
  search?: string
}

export function useContent(options: UseContentOptions = {}) {
  const workspace = useWorkspaceStore(s => s.workspace)

  return useQuery({
    queryKey: ['content', workspace?.id, options],
    queryFn: () => contentApi.list(workspace!.id, options).then(r => r.data),
    enabled: !!workspace?.id,
    placeholderData: (prev: any) => prev,
  })
}

export function useContentItem(contentId: string | undefined) {
  return useQuery<Content>({
    queryKey: ['content', contentId],
    queryFn: () => contentApi.get(contentId!).then(r => r.data),
    enabled: !!contentId,
  })
}

export function useDeleteContent() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (id: string) => contentApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['content'] })
      toast.success('Content deleted')
    },
    onError: () => toast.error('Failed to delete content'),
  })
}

export function useUpdateContent(contentId: string) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (data: Partial<Content>) => contentApi.update(contentId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['content', contentId] })
    },
    onError: () => toast.error('Failed to save'),
  })
}

export function useRepurposeContent() {
  return useMutation({
    mutationFn: ({ id, targetTypes }: { id: string; targetTypes: string[] }) =>
      contentApi.repurpose(id, targetTypes).then(r => r.data),
    onSuccess: () => toast.success('Content repurposed!'),
    onError: () => toast.error('Repurposing failed'),
  })
}

export function usePublishContent() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ id, integrationId }: { id: string; integrationId?: string }) =>
      integrationId
        ? contentApi.publish(id, integrationId).then(r => r.data)
        : Promise.resolve(null),
    onSuccess: (_: any, variables: { id: string }) => {
      queryClient.invalidateQueries({ queryKey: ['content', variables.id] })
      toast.success('Published successfully!')
    },
    onError: () => toast.error('Publish failed'),
  })
}
