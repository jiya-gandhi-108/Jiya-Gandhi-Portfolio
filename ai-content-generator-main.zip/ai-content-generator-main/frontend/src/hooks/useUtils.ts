import { useState, useEffect, useRef, useCallback } from 'react'

// ─── useDebounce ──────────────────────────────────────────────────────────────

export function useDebounce<T>(value: T, delayMs: number): T {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delayMs)
    return () => clearTimeout(timer)
  }, [value, delayMs])

  return debounced
}

// ─── useDebouncedCallback ─────────────────────────────────────────────────────

export function useDebouncedCallback<T extends (...args: any[]) => any>(
  fn: T,
  delayMs: number
): (...args: Parameters<T>) => void {
  const timer = useRef<ReturnType<typeof setTimeout>>()

  return useCallback(
    (...args: Parameters<T>) => {
      clearTimeout(timer.current)
      timer.current = setTimeout(() => fn(...args), delayMs)
    },
    [fn, delayMs]
  )
}

// ─── useLocalStorage ──────────────────────────────────────────────────────────

export function useLocalStorage<T>(
  key: string,
  initialValue: T
): [T, (value: T | ((prev: T) => T)) => void] {
  const [stored, setStored] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key)
      return item ? JSON.parse(item) : initialValue
    } catch {
      return initialValue
    }
  })

  const setValue = useCallback(
    (value: T | ((prev: T) => T)) => {
      try {
        const next = value instanceof Function ? value(stored) : value
        setStored(next)
        window.localStorage.setItem(key, JSON.stringify(next))
      } catch (err) {
        console.warn(`useLocalStorage: failed to write key "${key}"`, err)
      }
    },
    [key, stored]
  )

  return [stored, setValue]
}

// ─── useAutoSave ──────────────────────────────────────────────────────────────

type SaveStatus = 'saved' | 'saving' | 'unsaved' | 'error'

export function useAutoSave<T>(
  value: T,
  saveFn: (value: T) => Promise<void>,
  options: { delayMs?: number; enabled?: boolean } = {}
): SaveStatus {
  const { delayMs = 1500, enabled = true } = options
  const [status, setStatus] = useState<SaveStatus>('saved')
  const isFirstRender = useRef(true)
  const timer = useRef<ReturnType<typeof setTimeout>>()

  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false
      return
    }
    if (!enabled) return

    setStatus('unsaved')
    clearTimeout(timer.current)

    timer.current = setTimeout(async () => {
      setStatus('saving')
      try {
        await saveFn(value)
        setStatus('saved')
      } catch {
        setStatus('error')
      }
    }, delayMs)

    return () => clearTimeout(timer.current)
  }, [value, delayMs, enabled]) // eslint-disable-line react-hooks/exhaustive-deps

  return status
}

// ─── useKeyboardShortcut ──────────────────────────────────────────────────────

type ModifierKey = 'ctrl' | 'meta' | 'shift' | 'alt'

export function useKeyboardShortcut(
  key: string,
  callback: () => void,
  modifiers: ModifierKey[] = ['meta']
) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const matchKey = e.key.toLowerCase() === key.toLowerCase()
      const matchMods = modifiers.every(mod => {
        if (mod === 'ctrl')  return e.ctrlKey
        if (mod === 'meta')  return e.metaKey
        if (mod === 'shift') return e.shiftKey
        if (mod === 'alt')   return e.altKey
        return false
      })

      if (matchKey && matchMods) {
        e.preventDefault()
        callback()
      }
    }

    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [key, callback, modifiers])
}

// ─── useCopyToClipboard ───────────────────────────────────────────────────────

export function useCopyToClipboard(resetDelayMs = 2000) {
  const [copied, setCopied] = useState(false)

  const copy = useCallback(async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), resetDelayMs)
      return true
    } catch {
      return false
    }
  }, [resetDelayMs])

  return { copy, copied }
}

// ─── useOutsideClick ─────────────────────────────────────────────────────────

export function useOutsideClick<T extends HTMLElement>(
  callback: () => void
) {
  const ref = useRef<T>(null)

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        callback()
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [callback])

  return ref
}

// ─── usePrevious ─────────────────────────────────────────────────────────────

export function usePrevious<T>(value: T): T | undefined {
  const ref = useRef<T>()
  useEffect(() => { ref.current = value }, [value])
  return ref.current
}

// ─── useMediaQuery ────────────────────────────────────────────────────────────

export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(() => window.matchMedia(query).matches)

  useEffect(() => {
    const mq = window.matchMedia(query)
    const handler = (e: MediaQueryListEvent) => setMatches(e.matches)
    mq.addEventListener('change', handler)
    return () => mq.removeEventListener('change', handler)
  }, [query])

  return matches
}
