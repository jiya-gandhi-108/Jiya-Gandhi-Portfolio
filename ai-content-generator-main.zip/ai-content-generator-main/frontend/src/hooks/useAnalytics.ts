import { useQuery, useMutation } from '@tanstack/react-query'
import { useWorkspaceStore } from '@/store'
import { analyticsApi } from '@/services/api'
import type { WorkspaceAnalytics, ContentAnalytics } from '@/types'

export type DateRange = '7d' | '30d' | '90d'

export function useWorkspaceAnalytics(range: DateRange = '30d') {
  const workspace = useWorkspaceStore(s => s.workspace)

  return useQuery<WorkspaceAnalytics>({
    queryKey: ['workspace-analytics', workspace?.id, range],
    queryFn: () => analyticsApi.workspace(workspace!.id, range).then(r => r.data),
    enabled: !!workspace?.id,
    staleTime: 1000 * 60 * 5,
  })
}

export function useContentAnalytics(contentId: string | undefined) {
  return useQuery<ContentAnalytics>({
    queryKey: ['content-analytics', contentId],
    queryFn: () => analyticsApi.content(contentId!).then(r => r.data),
    enabled: !!contentId,
  })
}

export function useSubmitFeedback() {
  return useMutation({
    mutationFn: ({
      contentId,
      score,
      comment,
    }: {
      contentId: string
      score: number
      comment?: string
    }) => analyticsApi.feedback(contentId, score, comment),
  })
}
