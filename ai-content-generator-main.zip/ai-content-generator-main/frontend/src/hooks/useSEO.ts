import { useQuery, useMutation } from '@tanstack/react-query'
import { seoApi } from '@/services/api'
import type { KeywordData, SEOAnalysis } from '@/types'

export function useKeywords(topic: string, enabled = true) {
  return useQuery<KeywordData[]>({
    queryKey: ['keywords', topic],
    queryFn: () => seoApi.keywords(topic).then(r => r.data),
    enabled: enabled && topic.trim().length > 2,
    staleTime: 1000 * 60 * 60, // 1 hour — keyword data is slow-changing
  })
}

export function useCompetitors(keyword: string, enabled = true) {
  return useQuery({
    queryKey: ['competitors', keyword],
    queryFn: () => seoApi.competitors(keyword).then(r => r.data),
    enabled: enabled && keyword.trim().length > 2,
    staleTime: 1000 * 60 * 30,
  })
}

export function useAnalyzeContent() {
  return useMutation<SEOAnalysis, Error, { text: string; keywords: string[] }>({
    mutationFn: ({ text, keywords }) =>
      seoApi.analyze(text, keywords).then(r => r.data),
  })
}

export function useSEOReport(contentId: string | undefined) {
  return useQuery<SEOAnalysis>({
    queryKey: ['seo-report', contentId],
    queryFn: () =>
      import('@/services/api').then(m =>
        m.contentApi.analyze(contentId!).then(r => r.data)
      ),
    enabled: !!contentId,
    staleTime: 1000 * 60 * 5,
  })
}
