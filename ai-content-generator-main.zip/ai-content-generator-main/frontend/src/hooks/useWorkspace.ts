import { useWorkspaceStore } from '@/store'
import type { Workspace } from '@/types'

/**
 * Returns the current workspace from global store.
 * The workspace is loaded in App.tsx after auth.
 */
export function useWorkspace(): { workspace: Workspace | null; isLoading: boolean } {
  const workspace = useWorkspaceStore(s => s.workspace)
  return { workspace, isLoading: !workspace }
}

/**
 * Returns workspace members.
 */
export function useWorkspaceMembers() {
  const workspace = useWorkspaceStore(s => s.workspace)
  return workspace?.members ?? []
}
