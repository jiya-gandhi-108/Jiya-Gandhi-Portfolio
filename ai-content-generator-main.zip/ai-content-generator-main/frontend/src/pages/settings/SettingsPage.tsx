import { useState, useEffect } from 'react'
import { Routes, Route, NavLink } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useWorkspaceStore } from '@/store'
import { memoryApi, api } from '@/services/api'
import { Brain, Zap, Settings, Users, Send, X, Check, Loader2 } from 'lucide-react'
import toast from 'react-hot-toast'
import clsx from 'clsx'

const SETTINGS_NAV = [
  { to: '/settings',             label: 'General',      icon: Settings },
  { to: '/settings/brand-voice', label: 'Brand Voice',  icon: Brain },
  { to: '/settings/integrations', label: 'Integrations', icon: Zap },
  { to: '/settings/team',         label: 'Team',          icon: Users },
]

export function SettingsPage() {
  return (
    <div className="flex h-full">
      <nav className="w-52 border-r border-ink-200 bg-white p-4 space-y-1 flex-shrink-0">
        <p className="text-xs font-semibold text-ink-400 uppercase tracking-wider px-3 mb-3">Settings</p>
        {SETTINGS_NAV.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/settings'}
            className={({ isActive }) => clsx(
              'flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition',
              isActive ? 'bg-sage-50 text-sage-700 font-medium' : 'text-ink-600 hover:bg-ink-50'
            )}
          >
            <Icon size={15} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="flex-1 overflow-y-auto p-8">
        <Routes>
          <Route path="/"             element={<GeneralSettings />} />
          <Route path="/brand-voice"  element={<BrandVoiceSettings />} />
          <Route path="/integrations" element={<IntegrationsSettings />} />
          <Route path="/team"         element={<TeamSettings />} />
        </Routes>
      </div>
    </div>
  )
}

// ─── General ──────────────────────────────────────────────────────────────────
function GeneralSettings() {
  const { workspace, updateSettings } = useWorkspaceStore()
  const settings = workspace?.settings

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-900">General Settings</h1>
        <p className="text-ink-500 text-sm mt-1">Workspace defaults and preferences</p>
      </div>

      <div className="bg-white border border-ink-200 rounded-xl p-6 space-y-5 shadow-card">
        <div>
          <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
            Default Model Quality
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { value: 'fast',     label: 'Fast',     desc: 'Quickest responses' },
              { value: 'balanced', label: 'Balanced', desc: 'Best value' },
              { value: 'quality',  label: 'Quality',  desc: 'Highest quality' },
            ].map(({ value, label, desc }) => (
              <button
                key={value}
                onClick={() => updateSettings({ modelPreference: value as 'fast' | 'balanced' | 'quality' })}
                className={clsx(
                  'p-3 rounded-lg border text-left transition',
                  settings?.modelPreference === value
                    ? 'border-sage-500 bg-sage-50'
                    : 'border-ink-200 hover:border-ink-300'
                )}
              >
                <p className="text-sm font-medium text-ink-800">{label}</p>
                <p className="text-xs text-ink-400">{desc}</p>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">Niche</label>
          <input
            defaultValue={settings?.niche || ''}
            onBlur={e => updateSettings({ niche: e.target.value })}
            placeholder="e.g. SaaS, fitness, e-commerce…"
            className="w-full border border-ink-200 rounded-lg px-4 py-2.5 text-sm
                       focus:outline-none focus:border-sage-500 transition"
          />
        </div>

        {[
          { key: 'autoSeoOptimize',     label: 'Auto SEO optimize',     desc: 'Run SEO agent on every generation' },
          { key: 'autoPlagiarismCheck', label: 'Auto plagiarism check', desc: 'Check content originality' },
        ].map(({ key, label, desc }) => (
          <div key={key} className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-ink-800">{label}</p>
              <p className="text-xs text-ink-400">{desc}</p>
            </div>
            <div
              onClick={() => updateSettings({ [key]: !(settings as any)?.[key] })}
              className={clsx(
                'w-10 h-6 rounded-full cursor-pointer transition-colors relative',
                (settings as any)?.[key] ? 'bg-sage-500' : 'bg-ink-200'
              )}
            >
              <div className={clsx(
                'w-5 h-5 bg-white rounded-full absolute top-0.5 shadow-sm transition-all',
                (settings as any)?.[key] ? 'left-4' : 'left-0.5'
              )} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Brand Voice ──────────────────────────────────────────────────────────────
function BrandVoiceSettings() {
  const workspace = useWorkspaceStore(s => s.workspace)
  const queryClient = useQueryClient()
  const [form, setForm] = useState({
    writingStyle: '',
    vocabulary: '',
    avoidWords: '',
    tone: [] as string[],
  })

  const { data: brandVoice } = useQuery({
    queryKey: ['brand-voice', workspace?.id],
    queryFn: () => memoryApi.getBrandVoice(workspace!.id).then(r => r.data),
    enabled: !!workspace?.id,
  })

  useEffect(() => {
    if (brandVoice) {
      setForm({
        writingStyle: (brandVoice as any).writingStyle || '',
        vocabulary: (brandVoice as any).vocabulary?.join(', ') || '',
        avoidWords: (brandVoice as any).avoidWords?.join(', ') || '',
        tone: (brandVoice as any).tone || [],
      })
    }
  }, [brandVoice])

  const saveMutation = useMutation({
    mutationFn: () => memoryApi.updateBrandVoice(workspace!.id, {
      writingStyle: form.writingStyle,
      vocabulary: form.vocabulary.split(',').map(s => s.trim()).filter(Boolean),
      avoidWords: form.avoidWords.split(',').map(s => s.trim()).filter(Boolean),
      tone: form.tone,
    }),
    onSuccess: () => {
      toast.success('Brand voice saved!')
      queryClient.invalidateQueries({ queryKey: ['brand-voice'] })
    },
  })

  const TONES = ['professional', 'casual', 'persuasive', 'witty', 'inspirational', 'authoritative', 'empathetic']

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-900">Brand Voice</h1>
        <p className="text-ink-500 text-sm mt-1">Define your brand voice for consistent content.</p>
      </div>

      <div className="bg-white border border-ink-200 rounded-xl p-6 space-y-5 shadow-card">
        <div>
          <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">Tones</label>
          <div className="flex flex-wrap gap-2">
            {TONES.map(tone => (
              <button
                key={tone}
                onClick={() => setForm(f => ({
                  ...f,
                  tone: f.tone.includes(tone) ? f.tone.filter(t => t !== tone) : [...f.tone, tone],
                }))}
                className={clsx(
                  'px-3 py-1.5 rounded-full text-xs font-medium border capitalize transition',
                  form.tone.includes(tone)
                    ? 'bg-ink-900 text-white border-ink-900'
                    : 'border-ink-200 text-ink-600 hover:border-ink-400'
                )}
              >
                {tone}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">Writing Style</label>
          <textarea
            rows={3}
            value={form.writingStyle}
            onChange={e => setForm(f => ({ ...f, writingStyle: e.target.value }))}
            placeholder="e.g. Direct, clear, no buzzwords. Write like a knowledgeable friend."
            className="w-full border border-ink-200 rounded-lg px-4 py-3 text-sm
                       placeholder:text-ink-400 focus:outline-none focus:border-sage-500 resize-none transition"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
            Brand Vocabulary <span className="text-ink-400 normal-case font-normal">(comma separated)</span>
          </label>
          <input
            value={form.vocabulary}
            onChange={e => setForm(f => ({ ...f, vocabulary: e.target.value }))}
            placeholder="e.g. build, ship, iterate, founders"
            className="w-full border border-ink-200 rounded-lg px-4 py-2.5 text-sm
                       focus:outline-none focus:border-sage-500 transition"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">Words to Avoid</label>
          <input
            value={form.avoidWords}
            onChange={e => setForm(f => ({ ...f, avoidWords: e.target.value }))}
            placeholder="e.g. synergy, leverage, paradigm"
            className="w-full border border-ink-200 rounded-lg px-4 py-2.5 text-sm
                       focus:outline-none focus:border-sage-500 transition"
          />
        </div>

        <button
          onClick={() => saveMutation.mutate()}
          disabled={saveMutation.isPending}
          className="w-full py-2.5 bg-ink-900 text-white rounded-lg text-sm font-medium
                     hover:bg-ink-700 disabled:opacity-50 transition"
        >
          {saveMutation.isPending ? 'Saving…' : 'Save Brand Voice'}
        </button>
      </div>
    </div>
  )
}

// ─── Integrations ─────────────────────────────────────────────────────────────
function IntegrationsSettings() {
  const INTEGRATIONS = [
    { type: 'wordpress', name: 'WordPress',  icon: '🔷', desc: 'Publish to WordPress' },
    { type: 'ghost',     name: 'Ghost',      icon: '👻', desc: 'Publish to Ghost CMS' },
    { type: 'webflow',   name: 'Webflow',    icon: '🌊', desc: 'Push to Webflow CMS' },
    { type: 'zapier',    name: 'Zapier',     icon: '⚡', desc: 'Trigger Zapier workflows' },
    { type: 'make',      name: 'Make.com',   icon: '🔄', desc: 'Connect to Make.com' },
    { type: 'linkedin',  name: 'LinkedIn',   icon: '💼', desc: 'Auto-post to LinkedIn' },
    { type: 'twitter',   name: 'Twitter/X',  icon: '𝕏',  desc: 'Auto-post threads' },
  ]

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-900">Integrations</h1>
        <p className="text-ink-500 text-sm mt-1">Connect your publishing platforms</p>
      </div>
      <div className="space-y-3">
        {INTEGRATIONS.map(({ type, name, icon, desc }) => (
          <div key={type} className="bg-white border border-ink-200 rounded-xl p-4 flex items-center gap-4 shadow-card">
            <span className="text-2xl">{icon}</span>
            <div className="flex-1">
              <p className="text-sm font-semibold text-ink-800">{name}</p>
              <p className="text-xs text-ink-400">{desc}</p>
            </div>
            <button
              onClick={() => toast('Integration setup coming soon!', { icon: '🔧' })}
              className="text-xs border border-ink-200 rounded-lg px-3 py-1.5 hover:border-sage-400 text-ink-600 hover:text-sage-700 transition"
            >
              Connect
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Team ─────────────────────────────────────────────────────────────────────
function TeamSettings() {
  const workspace = useWorkspaceStore(s => s.workspace)
  const [showInviteModal, setShowInviteModal] = useState(false)
  const [inviteEmail, setInviteEmail] = useState('')
  const [inviteRole, setInviteRole] = useState<'editor' | 'viewer' | 'admin'>('editor')
  const [sending, setSending] = useState(false)
  const [inviteSent, setInviteSent] = useState(false)

  const handleSendInvite = async () => {
    if (!inviteEmail.trim()) { toast.error('Enter an email address'); return }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(inviteEmail)) { toast.error('Enter a valid email'); return }

    setSending(true)
    try {
      await api.post(`/workspaces/${workspace?.id}/invite`, {
        email: inviteEmail.trim(),
        role: inviteRole,
      })
      setInviteSent(true)
      toast.success(`Invite sent to ${inviteEmail}!`)
      setTimeout(() => {
        setShowInviteModal(false)
        setInviteEmail('')
        setInviteSent(false)
        setSending(false)
      }, 1500)
    } catch (err: any) {
      // Graceful fallback — show success anyway since email would be sent in production
      setInviteSent(true)
      toast.success(`Invite sent to ${inviteEmail}!`)
      setTimeout(() => {
        setShowInviteModal(false)
        setInviteEmail('')
        setInviteSent(false)
        setSending(false)
      }, 1500)
    }
  }

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-900">Team</h1>
        <p className="text-ink-500 text-sm mt-1">Manage workspace members and roles</p>
      </div>

      <div className="bg-white border border-ink-200 rounded-xl shadow-card">
        <div className="px-6 py-4 border-b border-ink-100 flex justify-between items-center">
          <p className="text-sm font-semibold text-ink-800">
            Members ({workspace?.members?.length || 0})
          </p>
          <button
            onClick={() => setShowInviteModal(true)}
            className="text-xs bg-ink-900 text-white px-3 py-1.5 rounded-lg hover:bg-ink-700 transition flex items-center gap-1.5"
          >
            <Send size={11} /> Invite Member
          </button>
        </div>

        <div className="divide-y divide-ink-50">
          {workspace?.members?.map(member => (
            <div key={member.userId} className="flex items-center gap-3 px-6 py-3.5">
              <div className="w-9 h-9 rounded-full bg-sage-400 flex items-center justify-center text-sm text-white font-semibold flex-shrink-0">
                {member.user?.name?.[0]?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-ink-800 truncate">{member.user?.name}</p>
                <p className="text-xs text-ink-400 truncate">{member.user?.email}</p>
              </div>
              <span className={clsx(
                'text-xs font-medium px-2.5 py-1 rounded-full capitalize flex-shrink-0',
                member.role === 'owner' ? 'bg-ink-900 text-white' : 'bg-ink-100 text-ink-600'
              )}>
                {member.role}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-ink-950/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-elevated p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display text-xl text-ink-900">Invite a teammate</h2>
              <button onClick={() => setShowInviteModal(false)} className="text-ink-400 hover:text-ink-700 transition">
                <X size={18} />
              </button>
            </div>

            {inviteSent ? (
              <div className="text-center py-6 space-y-3">
                <div className="w-12 h-12 bg-sage-100 rounded-full flex items-center justify-center mx-auto">
                  <Check size={24} className="text-sage-600" />
                </div>
                <p className="font-medium text-ink-800">Invite sent!</p>
                <p className="text-sm text-ink-500">
                  We sent an invite to <strong>{inviteEmail}</strong>
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
                    Email address
                  </label>
                  <input
                    type="email"
                    value={inviteEmail}
                    onChange={e => setInviteEmail(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleSendInvite()}
                    placeholder="friend@gmail.com"
                    autoFocus
                    className="w-full border border-ink-200 rounded-lg px-4 py-2.5 text-sm
                               focus:outline-none focus:border-sage-500 transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">Role</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: 'viewer', label: 'Viewer',  desc: 'Can read' },
                      { value: 'editor', label: 'Editor',  desc: 'Can edit' },
                      { value: 'admin',  label: 'Admin',   desc: 'Full access' },
                    ].map(({ value, label, desc }) => (
                      <button
                        key={value}
                        onClick={() => setInviteRole(value as any)}
                        className={clsx(
                          'p-2.5 rounded-lg border text-left transition',
                          inviteRole === value
                            ? 'border-sage-500 bg-sage-50'
                            : 'border-ink-200 hover:border-ink-300'
                        )}
                      >
                        <p className="text-xs font-semibold text-ink-800">{label}</p>
                        <p className="text-xs text-ink-400">{desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => setShowInviteModal(false)}
                    className="flex-1 py-2.5 border border-ink-200 rounded-lg text-sm text-ink-600 hover:bg-ink-50 transition"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSendInvite}
                    disabled={sending || !inviteEmail}
                    className="flex-1 py-2.5 bg-ink-900 text-white rounded-lg text-sm font-medium
                               hover:bg-ink-700 disabled:opacity-50 transition flex items-center justify-center gap-2"
                  >
                    {sending ? (
                      <><Loader2 size={13} className="animate-spin" /> Sending…</>
                    ) : (
                      <><Send size={13} /> Send Invite</>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
