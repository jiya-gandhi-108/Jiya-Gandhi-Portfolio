import { useEffect, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Placeholder from '@tiptap/extension-placeholder'
import Highlight from '@tiptap/extension-highlight'
import Typography from '@tiptap/extension-typography'
import Link from '@tiptap/extension-link'
import {
  Bold, Italic, Heading2, Heading3, List, ListOrdered,
  Quote, Highlighter, MessageSquare, GitBranch,
  Loader2, ChevronLeft, FileText, Clock, Wand2,
  Search, Filter, Globe
} from 'lucide-react'
import { contentApi, api } from '@/services/api'
import { useWorkspaceStore } from '@/store'
import { formatRelativeDate, formatContentType, getContentTypeIcon } from '@/utils/formatters'
import toast from 'react-hot-toast'
import clsx from 'clsx'
import type { Content } from '@/types'

export function WorkspacePage() {
  const { contentId } = useParams()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const workspace = useWorkspaceStore(s => s.workspace)
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved')
  const [showVersions, setShowVersions] = useState(false)
  const [publishing, setPublishing] = useState(false)
  const [showComments, setShowComments] = useState(false)
  const [search, setSearch] = useState('')

  // ── Content list ──────────────────────────────────────────────────────────
  const { data: contentList, isLoading: listLoading } = useQuery({
    queryKey: ['content-list', workspace?.id],
    queryFn: () => contentApi.list(workspace!.id, { perPage: 50 }).then(r => r.data),
    enabled: !!workspace?.id,
  })

  // ── Single content ────────────────────────────────────────────────────────
  const { data: content, isLoading: contentLoading } = useQuery<Content>({
    queryKey: ['content', contentId],
    queryFn: () => contentApi.get(contentId!).then(r => r.data),
    enabled: !!contentId,
  })

  const updateMutation = useMutation({
    mutationFn: (data: { body?: string; title?: string }) =>
      contentApi.update(contentId!, data),
    onSuccess: () => {
      setSaveStatus('saved')
      queryClient.invalidateQueries({ queryKey: ['content', contentId] })
      queryClient.invalidateQueries({ queryKey: ['content-list'] })
    },
  })

  const publishMutation = async () => {
    if (!contentId) return
    setPublishing(true)
    try {
      await api.post(`/content/${contentId}/publish-to-feed`)
      toast.success('Published to Team Feed! 🎉')
      queryClient.invalidateQueries({ queryKey: ['content', contentId] })
    } catch {
      toast.error('Failed to publish')
    } finally {
      setPublishing(false)
    }
  }

  const deleteMutation = useMutation({
    mutationFn: (id: string) => contentApi.delete(id),
    onSuccess: () => {
      toast.success('Deleted')
      queryClient.invalidateQueries({ queryKey: ['content-list'] })
      navigate('/workspace')
    },
  })

  // ── TipTap editor ─────────────────────────────────────────────────────────
  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({ placeholder: 'Start writing…' }),
      Highlight,
      Typography,
      Link.configure({ openOnClick: false }),
    ],
    content: '',
    onUpdate: ({ editor }) => {
      setSaveStatus('unsaved')
      debounceSave(editor.getText())
    },
    editorProps: {
      attributes: {
        class: 'prose prose-ink max-w-none focus:outline-none min-h-[500px] font-body',
      },
    },
  })

  useEffect(() => {
    if (editor && content?.body) {
      editor.commands.setContent(content.body)
    }
  }, [content?.body, editor])

  let saveTimer: ReturnType<typeof setTimeout>
  const debounceSave = useCallback((body: string) => {
    clearTimeout(saveTimer)
    setSaveStatus('saving')
    saveTimer = setTimeout(() => {
      updateMutation.mutate({ body })
    }, 1500)
  }, [contentId])

  // ── Filtered content list ─────────────────────────────────────────────────
  const filtered = contentList?.data?.filter((c: Content) =>
    !search || c.title.toLowerCase().includes(search.toLowerCase())
  ) || []

  return (
    <div className="h-full flex overflow-hidden">

      {/* ── Left sidebar: content list ──────────────────────────────── */}
      <div className="w-72 flex-shrink-0 border-r border-ink-200 bg-white flex flex-col">

        {/* Header */}
        <div className="px-4 py-4 border-b border-ink-100">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-sm text-ink-800 flex items-center gap-2">
              <FileText size={14} className="text-sage-500" />
              Workspace
            </h2>
            <button
              onClick={() => navigate('/generate')}
              className="text-xs bg-ink-900 text-white px-2.5 py-1 rounded-lg hover:bg-ink-700 transition flex items-center gap-1"
            >
              <Wand2 size={11} /> New
            </button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search content…"
              className="w-full pl-8 pr-3 py-2 text-xs border border-ink-200 rounded-lg
                         focus:outline-none focus:border-sage-400 bg-ink-50 transition"
            />
          </div>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto">
          {listLoading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 size={16} className="animate-spin text-sage-500" />
            </div>
          )}

          {!listLoading && filtered.length === 0 && (
            <div className="px-4 py-8 text-center">
              <p className="text-xs text-ink-400">
                {search ? 'No results found' : 'No content yet'}
              </p>
              {!search && (
                <button
                  onClick={() => navigate('/generate')}
                  className="mt-2 text-xs text-sage-600 hover:underline"
                >
                  Generate your first piece →
                </button>
              )}
            </div>
          )}

          {filtered.map((c: Content) => (
            <div
              key={c.id}
              onClick={() => navigate(`/workspace/${c.id}`)}
              className={clsx(
                'px-4 py-3 cursor-pointer transition border-b border-ink-50 group',
                contentId === c.id
                  ? 'bg-sage-50 border-l-2 border-l-sage-500'
                  : 'hover:bg-ink-50'
              )}
            >
              <div className="flex items-start gap-2">
                <span className="text-base flex-shrink-0 mt-0.5">{getContentTypeIcon(c.type)}</span>
                <div className="flex-1 min-w-0">
                  <p className={clsx(
                    'text-xs font-medium truncate',
                    contentId === c.id ? 'text-sage-700' : 'text-ink-700'
                  )}>
                    {c.title}
                  </p>
                  <p className="text-xs text-ink-400 mt-0.5">
                    {formatRelativeDate(c.updatedAt)}
                    {c.wordCount > 0 && ` · ${c.wordCount}w`}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Main editor area ─────────────────────────────────────────── */}
      {!contentId ? (
        <div className="flex-1 flex items-center justify-center bg-ink-50">
          <div className="text-center space-y-3 max-w-sm">
            <div className="w-14 h-14 bg-white border border-ink-200 rounded-2xl flex items-center justify-center mx-auto shadow-card">
              <FileText size={24} className="text-ink-400" />
            </div>
            <h2 className="font-display text-xl text-ink-700">Select content to edit</h2>
            <p className="text-sm text-ink-400">
              Choose a piece from the sidebar, or generate something new.
            </p>
            <button
              onClick={() => navigate('/generate')}
              className="inline-flex items-center gap-2 bg-ink-900 text-white px-4 py-2 rounded-lg
                         text-sm font-medium hover:bg-ink-700 transition mt-2"
            >
              <Wand2 size={14} /> Generate Content
            </button>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col overflow-hidden">

          {/* Editor toolbar */}
          <div className="flex items-center gap-2 px-5 py-2.5 border-b border-ink-200 bg-white flex-shrink-0">
            <button onClick={() => navigate('/workspace')} className="text-ink-400 hover:text-ink-700 mr-1 transition">
              <ChevronLeft size={17} />
            </button>

            {/* Format buttons */}
            <div className="flex items-center gap-0.5 border-r border-ink-200 pr-3">
              {[
                { icon: Bold,        action: () => editor?.chain().focus().toggleBold().run(),        active: editor?.isActive('bold') },
                { icon: Italic,      action: () => editor?.chain().focus().toggleItalic().run(),      active: editor?.isActive('italic') },
                { icon: Heading2,    action: () => editor?.chain().focus().toggleHeading({ level: 2 }).run(), active: editor?.isActive('heading', { level: 2 }) },
                { icon: Heading3,    action: () => editor?.chain().focus().toggleHeading({ level: 3 }).run(), active: editor?.isActive('heading', { level: 3 }) },
                { icon: List,        action: () => editor?.chain().focus().toggleBulletList().run(),  active: editor?.isActive('bulletList') },
                { icon: ListOrdered, action: () => editor?.chain().focus().toggleOrderedList().run(), active: editor?.isActive('orderedList') },
                { icon: Quote,       action: () => editor?.chain().focus().toggleBlockquote().run(),  active: editor?.isActive('blockquote') },
                { icon: Highlighter, action: () => editor?.chain().focus().toggleHighlight().run(),   active: editor?.isActive('highlight') },
              ].map(({ icon: Icon, action, active }, i) => (
                <button
                  key={i}
                  onClick={action}
                  className={clsx(
                    'p-1.5 rounded-md transition',
                    active ? 'bg-ink-900 text-white' : 'text-ink-400 hover:bg-ink-100 hover:text-ink-700'
                  )}
                >
                  <Icon size={14} />
                </button>
              ))}
            </div>

            {/* Save status */}
            <div className="flex-1 text-center">
              <span className={clsx(
                'text-xs font-medium',
                saveStatus === 'saved'   ? 'text-sage-500' :
                saveStatus === 'saving'  ? 'text-ink-400' :
                'text-amber-500'
              )}>
                {saveStatus === 'saved'  ? '✓ Saved' :
                 saveStatus === 'saving' ? 'Saving…' :
                 '● Unsaved'}
              </span>
            </div>

            {/* Right actions */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setShowVersions(v => !v)}
                className={clsx(
                  'flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs transition',
                  showVersions ? 'border-sage-400 text-sage-600 bg-sage-50' : 'border-ink-200 text-ink-500 hover:border-ink-300'
                )}
              >
                <GitBranch size={12} /> History
              </button>
              <button
                onClick={() => setShowComments(c => !c)}
                className={clsx(
                  'flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs transition',
                  showComments ? 'border-sage-400 text-sage-600 bg-sage-50' : 'border-ink-200 text-ink-500 hover:border-ink-300'
                )}
              >
                <MessageSquare size={12} />
                {content?.comments?.length ? content.comments.length : 'Notes'}
              </button>
              <button
                onClick={() => {
                  if (confirm('Delete this content?')) deleteMutation.mutate(contentId!)
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-red-200
                           text-xs text-red-500 hover:bg-red-50 transition"
              >
                Delete
              </button>
              <button
                onClick={publishMutation}
                disabled={publishing}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-sage-600 text-white text-xs hover:bg-sage-700 transition disabled:opacity-50"
              >
                <Globe size={12} /> {publishing ? 'Publishing…' : 'Publish'}
              </button>
            </div>
          </div>

          {/* Editor body */}
          <div className="flex-1 flex overflow-hidden">
            <div className="flex-1 overflow-y-auto bg-white">
              <div className="max-w-3xl mx-auto px-12 py-10">

                {/* Editable title */}
                <input
                  defaultValue={content?.title}
                  onBlur={e => {
                    if (e.target.value !== content?.title) {
                      updateMutation.mutate({ title: e.target.value })
                    }
                  }}
                  placeholder="Untitled"
                  className="w-full text-4xl font-display text-ink-900 placeholder:text-ink-300
                             border-none outline-none mb-4 leading-tight bg-transparent"
                />

                {/* Meta strip */}
                <div className="flex items-center gap-4 text-xs text-ink-400 mb-8 pb-5 border-b border-ink-100">
                  <span>{formatContentType(content?.type || '')}</span>
                  {content?.wordCount ? <span>{content.wordCount} words</span> : null}
                  {content?.seoScore ? (
                    <span className={clsx(
                      content.seoScore >= 80 ? 'text-sage-500' : 'text-amber-500'
                    )}>
                      SEO {content.seoScore}/100
                    </span>
                  ) : null}
                  {content?.updatedAt && (
                    <span className="flex items-center gap-1">
                      <Clock size={11} />
                      {formatRelativeDate(content.updatedAt)}
                    </span>
                  )}
                  {content?.keywords?.slice(0, 3).map(k => (
                    <span key={k} className="bg-ink-100 px-2 py-0.5 rounded-full text-ink-500">{k}</span>
                  ))}
                </div>

                {contentLoading ? (
                  <div className="flex items-center justify-center py-20">
                    <Loader2 size={20} className="animate-spin text-sage-500" />
                  </div>
                ) : (
                  <EditorContent editor={editor} />
                )}
              </div>
            </div>

            {/* Version History Panel */}
            {showVersions && (
              <div className="w-64 border-l border-ink-200 bg-white flex flex-col flex-shrink-0">
                <div className="px-4 py-3 border-b border-ink-100">
                  <h3 className="text-xs font-semibold text-ink-700 flex items-center gap-1.5">
                    <Clock size={12} /> Version History
                  </h3>
                </div>
                <div className="flex-1 overflow-y-auto divide-y divide-ink-50">
                  {content?.versions?.map(version => (
                    <div key={version.id} className="px-4 py-3 hover:bg-ink-50 transition">
                      <p className="text-xs font-medium text-ink-700">{version.label || 'Auto-saved'}</p>
                      <p className="text-xs text-ink-400 mt-0.5">
                        {formatRelativeDate(version.createdAt)}
                      </p>
                      <button
                        onClick={async () => {
                          await contentApi.restoreVersion(content!.id, version.id)
                          toast.success('Version restored')
                          queryClient.invalidateQueries({ queryKey: ['content', contentId] })
                        }}
                        className="text-xs text-sage-600 hover:underline mt-1"
                      >
                        Restore
                      </button>
                    </div>
                  ))}
                  {(!content?.versions || content.versions.length === 0) && (
                    <p className="text-xs text-ink-400 text-center py-6">No versions yet</p>
                  )}
                </div>
              </div>
            )}

            {/* Comments / Notes Panel */}
            {showComments && (
              <div className="w-64 border-l border-ink-200 bg-white flex flex-col flex-shrink-0">
                <div className="px-4 py-3 border-b border-ink-100">
                  <h3 className="text-xs font-semibold text-ink-700 flex items-center gap-1.5">
                    <MessageSquare size={12} /> Notes
                  </h3>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {content?.comments?.map(comment => (
                    <div key={comment.id} className="bg-ink-50 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-5 h-5 rounded-full bg-sage-400 flex items-center justify-center text-xs text-white font-medium">
                          {comment.createdBy?.name?.[0]}
                        </div>
                        <span className="text-xs font-medium text-ink-700">{comment.createdBy?.name}</span>
                      </div>
                      <p className="text-xs text-ink-600">{comment.body}</p>
                    </div>
                  ))}
                  {(!content?.comments || content.comments.length === 0) && (
                    <p className="text-xs text-ink-400 text-center py-6">No notes yet</p>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
