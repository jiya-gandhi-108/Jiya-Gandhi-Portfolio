import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Wand2, Globe, Brain, Target, ChevronRight,
  Loader2, CheckCircle2, Circle, X, Copy,
  RefreshCw,
} from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { useGenerationStore, useWorkspaceStore } from '@/store'
import type { ContentType, Tone, FunnelStage, GenerateRequest } from '@/types'
import { SEOPanel } from '@/components/seo/SEOPanel'
import toast from 'react-hot-toast'
import { api } from '@/services/api'
import clsx from 'clsx'

const CONTENT_TYPES: { value: ContentType; label: string; icon: string }[] = [
  { value: 'blog',                label: 'Blog Post',        icon: '📝' },
  { value: 'twitter_thread',      label: 'Twitter Thread',   icon: '𝕏'  },
  { value: 'linkedin_post',       label: 'LinkedIn Post',    icon: '💼' },
  { value: 'email_newsletter',    label: 'Email Newsletter', icon: '📧' },
  { value: 'ad_copy',             label: 'Ad Copy',          icon: '📣' },
  { value: 'video_script',        label: 'Video Script',     icon: '🎬' },
  { value: 'carousel',            label: 'Carousel',         icon: '🎠' },
  { value: 'product_description', label: 'Product Desc.',    icon: '🛒' },
]

const TONES: Tone[] = ['professional', 'casual', 'persuasive', 'witty', 'inspirational', 'authoritative', 'empathetic']

const FUNNEL: { value: FunnelStage; label: string; desc: string }[] = [
  { value: 'TOFU', label: 'Top of Funnel', desc: 'Awareness & discovery' },
  { value: 'MOFU', label: 'Mid Funnel',    desc: 'Consideration & research' },
  { value: 'BOFU', label: 'Bottom Funnel', desc: 'Decision & conversion' },
]

const AGENT_STEPS = [
  { id: 'research', name: 'Research Agent', desc: 'Fetching live data, trends & competitor insights' },
  { id: 'outline',  name: 'Outline Agent',  desc: 'Building content structure & topic clusters' },
  { id: 'draft',    name: 'Draft Agent',    desc: 'Writing brand-voice-aware content' },
  { id: 'editor',   name: 'Editor Agent',   desc: 'Removing fluff, improving clarity & tone' },
  { id: 'seo',      name: 'SEO Agent',      desc: 'Optimizing keywords, headings & readability' },
]

export function GeneratePage() {
  const {
    currentJob, isGenerating, streamingText, streamingStep,
    generatedContent, error, startGeneration, cancelGeneration, reset,
  } = useGenerationStore()

  const workspace = useWorkspaceStore(s => s.workspace)
  const [localWorkspaceId, setLocalWorkspaceId] = useState<string | null>(null)

  const [form, setForm] = useState<Partial<GenerateRequest>>({
    contentType: 'blog',
    tone: 'professional',
    targetAudience: 'intermediate',
    funnelStage: 'TOFU',
    useRealTimeData: true,
    useBrandVoice: true,
    outputFormats: [],
  })

  const [topic, setTopic] = useState('')
  const [keywords, setKeywords] = useState('')
  const [wordLimit, setWordLimit] = useState(1000)
  const [publishing, setPublishing] = useState(false)
  const [showSEO, setShowSEO] = useState(false)
  const navigate = useNavigate()

  // ── Load workspace directly if store is empty ─────────────────────────────
  useEffect(() => {
    if (workspace?.id) {
      setLocalWorkspaceId(workspace.id)
      return
    }
    api.get('/workspaces/me')
      .then(r => {
        setLocalWorkspaceId(r.data.id)
        useWorkspaceStore.getState().setWorkspace(r.data)
      })
      .catch(() => {})
  }, [workspace?.id])

  // ── Handlers ──────────────────────────────────────────────────────────────

  const handleGenerate = () => {
    if (!topic.trim()) { toast.error('Please enter a topic'); return }

    const wsId = localWorkspaceId
      || workspace?.id
      || useWorkspaceStore.getState().workspace?.id

    if (!wsId) {
      toast.error('Workspace not loaded. Please wait a moment and try again.')
      return
    }

    startGeneration({
      ...form as GenerateRequest,
      topic: topic.trim(),
      keywords: keywords.split(',').map(k => k.trim()).filter(Boolean),
      workspaceId: wsId,
      wordLimit,
    })
  }

  const handlePublish = async () => {
    if (!generatedContent?.id) return
    setPublishing(true)
    try {
      await api.post(`/content/${generatedContent.id}/publish-to-feed`)
      toast.success('Published to Team Feed! 🎉')
      navigate('/feed')
    } catch {
      toast.error('Failed to publish')
    } finally {
      setPublishing(false)
    }
  }

  const handleCopy = () => {
    const text = generatedContent?.body || streamingText
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard')
  }

  return (
    <div className="h-full flex">

      {/* ── Left Panel: Config ─────────────────────────────────────── */}
      <div className="w-96 flex-shrink-0 border-r border-ink-200 bg-white overflow-y-auto">
        <div className="p-6 space-y-6">
          <div>
            <h1 className="font-display text-2xl text-ink-900">Generate</h1>
            <p className="text-sm text-ink-500 mt-1">Multi-agent AI content pipeline</p>
          </div>

          {/* Topic */}
          <div>
            <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
              Topic / Keyword
            </label>
            <textarea
              rows={3}
              value={topic}
              onChange={e => setTopic(e.target.value)}
              placeholder="e.g. How to build a SaaS product in 2026 with AI tools"
              className="w-full border border-ink-200 rounded-lg px-4 py-3 text-sm text-ink-900
                         placeholder:text-ink-400 focus:outline-none focus:border-sage-500
                         focus:ring-2 focus:ring-sage-100 resize-none transition"
            />
          </div>

          {/* Content Type */}
          <div>
            <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
              Content Type
            </label>
            <div className="grid grid-cols-2 gap-2">
              {CONTENT_TYPES.map(({ value, label, icon }) => (
                <button
                  key={value}
                  onClick={() => setForm(f => ({ ...f, contentType: value }))}
                  className={clsx(
                    'flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition',
                    form.contentType === value
                      ? 'border-sage-500 bg-sage-50 text-sage-700 font-medium'
                      : 'border-ink-200 text-ink-600 hover:border-ink-300'
                  )}
                >
                  <span>{icon}</span>
                  <span className="truncate">{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Tone */}
          <div>
            <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
              Tone
            </label>
            <div className="flex flex-wrap gap-2">
              {TONES.map(tone => (
                <button
                  key={tone}
                  onClick={() => setForm(f => ({ ...f, tone }))}
                  className={clsx(
                    'px-3 py-1.5 rounded-full text-xs font-medium border capitalize transition',
                    form.tone === tone
                      ? 'bg-ink-900 text-white border-ink-900'
                      : 'border-ink-200 text-ink-600 hover:border-ink-400'
                  )}
                >
                  {tone}
                </button>
              ))}
            </div>
          </div>

          {/* Target Audience */}
          <div>
            <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
              Target Audience
            </label>
            <div className="flex gap-2">
              {(['beginner', 'intermediate', 'expert'] as const).map(level => (
                <button
                  key={level}
                  onClick={() => setForm(f => ({ ...f, targetAudience: level }))}
                  className={clsx(
                    'flex-1 py-2 rounded-lg text-xs font-medium border capitalize transition',
                    form.targetAudience === level
                      ? 'bg-sage-600 text-white border-sage-600'
                      : 'border-ink-200 text-ink-600 hover:border-ink-400'
                  )}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          {/* Funnel Stage */}
          <div>
            <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
              Funnel Stage
            </label>
            <div className="space-y-2">
              {FUNNEL.map(({ value, label, desc }) => (
                <button
                  key={value}
                  onClick={() => setForm(f => ({ ...f, funnelStage: value }))}
                  className={clsx(
                    'w-full flex items-center justify-between px-3 py-2 rounded-lg border text-left transition',
                    form.funnelStage === value
                      ? 'border-sage-500 bg-sage-50'
                      : 'border-ink-200 hover:border-ink-300'
                  )}
                >
                  <div>
                    <span className="text-xs font-semibold text-ink-800">{label}</span>
                    <p className="text-xs text-ink-400">{desc}</p>
                  </div>
                  <span className={clsx(
                    'text-xs font-bold px-2 py-0.5 rounded',
                    form.funnelStage === value ? 'bg-sage-500 text-white' : 'bg-ink-100 text-ink-500'
                  )}>
                    {value}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Keywords */}
          <div>
            <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
              Target Keywords{' '}
              <span className="text-ink-400 normal-case font-normal">(comma separated)</span>
            </label>
            <input
              type="text"
              value={keywords}
              onChange={e => setKeywords(e.target.value)}
              placeholder="saas, ai tools, productivity"
              className="w-full border border-ink-200 rounded-lg px-4 py-2.5 text-sm
                         placeholder:text-ink-400 focus:outline-none focus:border-sage-500
                         focus:ring-2 focus:ring-sage-100 transition"
            />
          </div>

          {/* Options */}
          <div className="space-y-3">
            <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider">
              Options
            </label>
            {[
              { key: 'useRealTimeData', icon: Globe, label: 'Real-time web data',  desc: 'Inject live trends & stats' },
              { key: 'useBrandVoice',   icon: Brain, label: 'Brand voice memory',  desc: 'Use your saved style & tone' },
            ].map(({ key, icon: Icon, label, desc }) => (
              <div
                key={key}
                onClick={() => setForm(f => ({ ...f, [key]: !f[key as keyof typeof f] }))}
                className={clsx(
                  'flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition',
                  form[key as keyof typeof form]
                    ? 'border-sage-400 bg-sage-50'
                    : 'border-ink-200 hover:border-ink-300'
                )}
              >
                <Icon size={16} className={form[key as keyof typeof form] ? 'text-sage-600' : 'text-ink-400'} />
                <div className="flex-1 text-left">
                  <span className="text-sm font-medium text-ink-800">{label}</span>
                  <p className="text-xs text-ink-400">{desc}</p>
                </div>
                <div className={clsx(
                  'w-9 h-5 rounded-full transition-colors relative',
                  form[key as keyof typeof form] ? 'bg-sage-500' : 'bg-ink-200'
                )}>
                  <div className={clsx(
                    'w-4 h-4 bg-white rounded-full absolute top-0.5 transition-all',
                    form[key as keyof typeof form] ? 'left-4' : 'left-0.5'
                  )} />
                </div>
              </div>
            ))}
          </div>

          {/* Word Limit */}
          <div>
            <label className="block text-xs font-medium text-ink-500 uppercase tracking-wider mb-2">
              Word Limit:{' '}
              <span className="text-sage-600 font-semibold">{wordLimit} words</span>
            </label>
            <input
              type="range"
              min={200}
              max={5000}
              step={100}
              value={wordLimit}
              onChange={e => setWordLimit(Number(e.target.value))}
              className="w-full accent-sage-600"
            />
            <div className="flex justify-between text-xs text-ink-400 mt-1">
              <span>200</span>
              <span>1000</span>
              <span>2500</span>
              <span>5000</span>
            </div>
          </div>

          {/* Workspace status indicator */}
          {!localWorkspaceId && !workspace?.id && (
            <div className="flex items-center gap-2 text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
              <Loader2 size={12} className="animate-spin" />
              Loading workspace...
            </div>
          )}

          {/* Generate Button */}
          <button
            onClick={isGenerating ? cancelGeneration : handleGenerate}
            disabled={!isGenerating && !localWorkspaceId && !workspace?.id}
            className={clsx(
              'w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition',
              isGenerating
                ? 'bg-red-50 text-red-600 border border-red-200 hover:bg-red-100'
                : !localWorkspaceId && !workspace?.id
                  ? 'bg-ink-300 text-white cursor-not-allowed'
                  : 'bg-ink-900 text-white hover:bg-ink-700'
            )}
          >
            {isGenerating ? (
              <><X size={16} /> Cancel</>
            ) : (
              <><Wand2 size={16} /> Generate Content</>
            )}
          </button>
        </div>
      </div>

      {/* ── Right Panel: Output ────────────────────────────────────── */}
      <div className="flex-1 flex flex-col overflow-hidden bg-ink-50">

        {/* Empty state */}
        {!isGenerating && !generatedContent && !error && (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center space-y-3 max-w-sm">
              <div className="w-16 h-16 bg-sage-100 rounded-2xl flex items-center justify-center mx-auto">
                <Wand2 size={28} className="text-sage-600" />
              </div>
              <h2 className="font-display text-xl text-ink-800">Ready to generate</h2>
              <p className="text-sm text-ink-500 leading-relaxed">
                Configure your options on the left and click Generate. Our 5-agent pipeline
                will research, outline, draft, edit, and SEO-optimize your content.
              </p>
              <div className="flex flex-col gap-1.5 mt-4">
                {AGENT_STEPS.map(step => (
                  <div key={step.id} className="flex items-center gap-2 text-xs text-ink-400">
                    <ChevronRight size={12} className="text-sage-400 flex-shrink-0" />
                    <span>{step.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Agent pipeline progress */}
        <AnimatePresence>
          {isGenerating && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex-1 flex flex-col p-6 gap-4 overflow-y-auto"
            >
              {/* Steps */}
              <div className="bg-white rounded-xl border border-ink-200 p-4 shadow-card">
                <h3 className="text-sm font-semibold text-ink-700 mb-4 flex items-center gap-2">
                  <Loader2 size={14} className="animate-spin text-sage-500" />
                  Agent Pipeline Running
                </h3>
                <div className="space-y-3">
                  {AGENT_STEPS.map((step) => {
                    const stepData = currentJob?.steps.find(s =>
                      s.name.toLowerCase().includes(step.id)
                    )
                    const status = stepData?.status || 'idle'
                    const isCurrent = streamingStep.toLowerCase().includes(
                      step.name.toLowerCase()
                    )
                    return (
                      <div
                        key={step.id}
                        className={clsx(
                          'flex items-start gap-3 p-3 rounded-lg transition',
                          isCurrent ? 'bg-sage-50 border border-sage-200' : ''
                        )}
                      >
                        {status === 'done'
                          ? <CheckCircle2 size={16} className="text-sage-500 mt-0.5 flex-shrink-0" />
                          : isCurrent
                            ? <Loader2 size={16} className="animate-spin text-sage-500 mt-0.5 flex-shrink-0" />
                            : <Circle size={16} className="text-ink-300 mt-0.5 flex-shrink-0" />
                        }
                        <div>
                          <p className={clsx(
                            'text-sm font-medium',
                            isCurrent ? 'text-sage-700' : 'text-ink-600'
                          )}>
                            {step.name}
                          </p>
                          <p className="text-xs text-ink-400">{step.desc}</p>
                          {stepData?.tokensUsed && (
                            <p className="text-xs text-ink-300 mt-0.5">
                              {stepData.tokensUsed} tokens · {stepData.model}
                            </p>
                          )}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* Streaming output */}
              {streamingText && (
                <div className="bg-white rounded-xl border border-ink-200 p-5 shadow-card flex-1">
                  <p className="text-xs font-medium text-ink-400 uppercase tracking-wider mb-3">
                    Live Output
                  </p>
                  <div className="prose prose-ink max-w-none leading-relaxed">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                      {streamingText}
                    </ReactMarkdown>
                    <span className="inline-block w-0.5 h-4 bg-sage-500 ml-0.5 animate-stream align-middle" />
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Generated Content */}
        <AnimatePresence>
          {generatedContent && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex-1 flex flex-col overflow-hidden"
            >
              {/* Toolbar */}
              <div className="flex items-center gap-2 px-6 py-3 border-b border-ink-200 bg-white">
                <div className="flex-1">
                  <span className="text-xs font-medium text-ink-500">
                    {generatedContent.wordCount} words ·{' '}
                    SEO {generatedContent.seoScore}/100 ·{' '}
                    Readability {generatedContent.readabilityScore}/100
                  </span>
                </div>
                <button
                  onClick={() => setShowSEO(s => !s)}
                  className="text-xs border border-ink-200 rounded-lg px-3 py-1.5 hover:border-sage-400 transition flex items-center gap-1"
                >
                  <Target size={12} /> SEO Report
                </button>
                <button
                  onClick={handleCopy}
                  className="text-xs border border-ink-200 rounded-lg px-3 py-1.5 hover:border-sage-400 transition flex items-center gap-1"
                >
                  <Copy size={12} /> Copy
                </button>
                <button
                  onClick={handlePublish}
                  disabled={publishing}
                  className="text-xs bg-sage-600 text-white rounded-lg px-3 py-1.5 hover:bg-sage-700 transition flex items-center gap-1 disabled:opacity-50"
                >
                  <Globe size={12} /> {publishing ? 'Publishing…' : 'Publish to Feed'}
                </button>
                <button
                  onClick={reset}
                  className="text-xs border border-ink-200 rounded-lg px-3 py-1.5 hover:border-ink-400 transition flex items-center gap-1 text-ink-500"
                >
                  <RefreshCw size={12} /> New
                </button>
              </div>

              <div className="flex-1 flex overflow-hidden">
                {/* Content Body */}
                <div className="flex-1 overflow-y-auto p-8">
                  <div className="prose prose-ink max-w-none">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                      {generatedContent.body}
                    </ReactMarkdown>
                  </div>
                </div>

                {/* SEO Panel */}
                <AnimatePresence>
                  {showSEO && (
                    <motion.div
                      initial={{ width: 0, opacity: 0 }}
                      animate={{ width: 320, opacity: 1 }}
                      exit={{ width: 0, opacity: 0 }}
                      className="border-l border-ink-200 overflow-hidden flex-shrink-0"
                    >
                      <SEOPanel
                        contentId={generatedContent.id}
                        onClose={() => setShowSEO(false)}
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Error */}
        {error && (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center space-y-3">
              <p className="text-red-500 font-medium">Generation failed</p>
              <p className="text-sm text-ink-500">{error}</p>
              <button
                onClick={reset}
                className="text-sm text-sage-600 hover:underline"
              >
                Try again
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}