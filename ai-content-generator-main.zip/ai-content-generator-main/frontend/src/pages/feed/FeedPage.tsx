import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { motion, AnimatePresence } from 'framer-motion'
import { useUser } from '@clerk/clerk-react'
import {
  Heart, MessageSquare, Eye, Clock, Send,
  X, ChevronDown, ChevronUp, Bookmark, Globe,
} from 'lucide-react'
import { api } from '@/services/api'
import { useWorkspaceStore } from '@/store'
import { formatRelativeDate, formatContentType, getContentTypeIcon, estimateReadingTime } from '@/utils/formatters'
import ReactMarkdown from 'react-markdown'
import toast from 'react-hot-toast'
import clsx from 'clsx'
import type { Content } from '@/types'

interface FeedContent extends Omit<Content, 'comments'> {
  analytics?: {
    views: number
    socialShares: number
  }
  comments?: any[]
}

export function FeedPage() {
  const workspace = useWorkspaceStore(s => s.workspace)
  const { user } = useUser()
  const queryClient = useQueryClient()
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [commentingId, setCommentingId] = useState<string | null>(null)
  const [commentText, setCommentText] = useState('')
  const [likedIds, setLikedIds] = useState<Set<string>>(new Set())

  const { data: feed, isLoading } = useQuery({
    queryKey: ['feed', workspace?.id],
    queryFn: () => api.get(`/content/feed/workspace/${workspace!.id}`).then(r => r.data),
    enabled: !!workspace?.id,
    refetchInterval: 30_000, // refresh every 30s
  })

  const likeMutation = useMutation({
    mutationFn: (contentId: string) => api.post(`/content/${contentId}/like`),
    onSuccess: (_, contentId) => {
      setLikedIds(s => new Set([...s, contentId]))
      queryClient.invalidateQueries({ queryKey: ['feed'] })
    },
  })

  const commentMutation = useMutation({
    mutationFn: ({ contentId, body }: { contentId: string; body: string }) =>
      api.post(`/content/${contentId}/comment`, { body }),
    onSuccess: () => {
      setCommentText('')
      setCommentingId(null)
      queryClient.invalidateQueries({ queryKey: ['feed'] })
      queryClient.invalidateQueries({ queryKey: ['comments'] })
      toast.success('Comment posted!')
    },
  })

  const { data: comments } = useQuery({
    queryKey: ['comments', commentingId],
    queryFn: () => api.get(`/content/${commentingId}/comments`).then(r => r.data),
    enabled: !!commentingId,
  })

  if (isLoading) {
    return (
      <div className="p-8 max-w-3xl mx-auto space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-48 bg-ink-100 rounded-2xl animate-pulse" />
        ))}
      </div>
    )
  }

  const items: FeedContent[] = feed?.data || []

  return (
    <div className="p-8 max-w-3xl mx-auto">

      {/* Header */}
      <div className="mb-8">
        <h1 className="font-display text-3xl text-ink-900 flex items-center gap-3">
          <Globe size={24} className="text-sage-500" />
          Team Feed
        </h1>
        <p className="text-ink-500 text-sm mt-1">
          Published content from your workspace — like, comment, and collaborate
        </p>
      </div>

      {items.length === 0 && (
        <div className="text-center py-20 bg-white border border-ink-200 rounded-2xl">
          <div className="w-16 h-16 bg-sage-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Globe size={28} className="text-sage-400" />
          </div>
          <h2 className="font-display text-xl text-ink-700 mb-2">Nothing published yet</h2>
          <p className="text-sm text-ink-400 max-w-xs mx-auto">
            When you or your teammates publish content, it will appear here for everyone to see and discuss.
          </p>
        </div>
      )}

      <div className="space-y-5">
        {items.map((item, i) => {
          const isExpanded = expandedId === item.id
          const isCommenting = commentingId === item.id
          const liked = likedIds.has(item.id)

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="bg-white border border-ink-200 rounded-2xl shadow-card overflow-hidden"
            >
              {/* Card header */}
              <div className="px-6 py-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    {/* Type badge */}
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-lg">{getContentTypeIcon(item.type)}</span>
                      <span className="text-xs font-medium text-ink-400 capitalize">
                        {formatContentType(item.type)}
                      </span>
                      <span className="text-ink-200">·</span>
                      <span className="text-xs text-ink-400 flex items-center gap-1">
                        <Clock size={11} />
                        {formatRelativeDate(item.publishedAt || item.updatedAt)}
                      </span>
                      {item.wordCount > 0 && (
                        <>
                          <span className="text-ink-200">·</span>
                          <span className="text-xs text-ink-400">
                            {estimateReadingTime(item.wordCount)}
                          </span>
                        </>
                      )}
                    </div>

                    {/* Title */}
                    <h2 className="font-display text-xl text-ink-900 leading-snug mb-2">
                      {item.title}
                    </h2>

                    {/* Keywords */}
                    {item.keywords?.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {item.keywords.slice(0, 4).map(k => (
                          <span key={k} className="text-xs bg-ink-100 text-ink-500 px-2 py-0.5 rounded-full">
                            {k}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* SEO score badge */}
                  {item.seoScore > 0 && (
                    <div className={clsx(
                      'flex-shrink-0 text-center px-3 py-2 rounded-xl',
                      item.seoScore >= 80 ? 'bg-sage-50 text-sage-700' :
                      item.seoScore >= 60 ? 'bg-amber-50 text-amber-700' :
                      'bg-red-50 text-red-600'
                    )}>
                      <p className="text-lg font-display leading-none">{item.seoScore}</p>
                      <p className="text-xs font-medium mt-0.5">SEO</p>
                    </div>
                  )}
                </div>

                {/* Content preview / expanded */}
                <AnimatePresence>
                  {!isExpanded ? (
                    <div className="mt-3 text-sm text-ink-600 leading-relaxed line-clamp-3">
                      {item.body?.replace(/[#*_>]/g, '').slice(0, 280)}…
                    </div>
                  ) : (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="mt-4 prose prose-ink max-w-none text-sm border-t border-ink-100 pt-4 overflow-hidden"
                    >
                      <ReactMarkdown>{item.body}</ReactMarkdown>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Action bar */}
              <div className="px-6 py-3 border-t border-ink-100 flex items-center gap-1">
                {/* Like */}
                <button
                  onClick={() => {
                    if (!liked) likeMutation.mutate(item.id)
                  }}
                  className={clsx(
                    'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition',
                    liked
                      ? 'bg-red-50 text-red-500'
                      : 'text-ink-500 hover:bg-ink-100 hover:text-red-400'
                  )}
                >
                  <Heart size={14} className={liked ? 'fill-red-400' : ''} />
                  {(item.analytics?.socialShares || 0) + (liked ? 1 : 0)}
                </button>

                {/* Comment */}
                <button
                  onClick={() => setCommentingId(isCommenting ? null : item.id)}
                  className={clsx(
                    'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition',
                    isCommenting
                      ? 'bg-sage-50 text-sage-600'
                      : 'text-ink-500 hover:bg-ink-100'
                  )}
                >
                  <MessageSquare size={14} />
                  {item.comments?.length || 0}
                </button>

                {/* Views */}
                <div className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-ink-400">
                  <Eye size={14} />
                  {item.analytics?.views || 0}
                </div>

                <div className="flex-1" />

                {/* Read more / collapse */}
                <button
                  onClick={() => setExpandedId(isExpanded ? null : item.id)}
                  className="flex items-center gap-1 text-xs text-sage-600 hover:underline font-medium px-2 py-1.5"
                >
                  {isExpanded ? (
                    <><ChevronUp size={13} /> Collapse</>
                  ) : (
                    <><ChevronDown size={13} /> Read full</>
                  )}
                </button>
              </div>

              {/* Comments section */}
              <AnimatePresence>
                {isCommenting && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="border-t border-ink-100 overflow-hidden"
                  >
                    {/* Existing comments */}
                    {comments && comments.length > 0 && (
                      <div className="px-6 pt-4 space-y-3">
                        {comments.map((comment: any) => (
                          <div key={comment.id} className="flex gap-3">
                            <div className="w-7 h-7 rounded-full bg-sage-400 flex items-center justify-center text-xs text-white font-semibold flex-shrink-0">
                              {comment.user?.name?.[0]?.toUpperCase() || '?'}
                            </div>
                            <div className="flex-1 bg-ink-50 rounded-xl px-3 py-2">
                              <p className="text-xs font-semibold text-ink-700">{comment.user?.name}</p>
                              <p className="text-sm text-ink-600 mt-0.5">{comment.body}</p>
                              <p className="text-xs text-ink-400 mt-1">
                                {formatRelativeDate(comment.createdAt)}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Comment input */}
                    <div className="px-6 py-4 flex gap-3">
                      <div className="w-7 h-7 rounded-full bg-ink-300 flex items-center justify-center text-xs text-white font-semibold flex-shrink-0">
                        {user?.firstName?.[0]?.toUpperCase() || '?'}
                      </div>
                      <div className="flex-1 flex gap-2">
                        <input
                          value={commentText}
                          onChange={e => setCommentText(e.target.value)}
                          onKeyDown={e => {
                            if (e.key === 'Enter' && !e.shiftKey && commentText.trim()) {
                              commentMutation.mutate({ contentId: item.id, body: commentText })
                            }
                          }}
                          placeholder="Add a comment… (Enter to post)"
                          autoFocus
                          className="flex-1 border border-ink-200 rounded-xl px-3 py-2 text-sm
                                     focus:outline-none focus:border-sage-400 transition"
                        />
                        <button
                          onClick={() => {
                            if (commentText.trim()) {
                              commentMutation.mutate({ contentId: item.id, body: commentText })
                            }
                          }}
                          disabled={!commentText.trim() || commentMutation.isPending}
                          className="px-3 py-2 bg-ink-900 text-white rounded-xl hover:bg-ink-700
                                     disabled:opacity-50 transition flex items-center gap-1.5 text-xs font-medium"
                        >
                          <Send size={13} />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}
