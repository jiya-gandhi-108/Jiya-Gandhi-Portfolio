import { useQuery } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { useUser, SignOutButton } from '@clerk/clerk-react'
import { LogOut } from 'lucide-react'
import {
  Wand2, FileText, TrendingUp, Zap, Plus,
  BarChart3, Globe, Clock, ArrowRight,
} from 'lucide-react'
import { analyticsApi, contentApi } from '@/services/api'
import { useWorkspaceStore } from '@/store'
import type { Content } from '@/types'
import { formatRelativeDate, getContentTypeIcon, formatContentType } from '@/utils/formatters'
import clsx from 'clsx'

const TYPE_ICONS: Record<string, string> = {
  blog: '📝', twitter_thread: '𝕏', linkedin_post: '💼',
  email_newsletter: '📧', ad_copy: '📣', video_script: '🎬',
  carousel: '🎠', product_description: '🛒',
}

export function DashboardPage() {
  const navigate = useNavigate()
  const { user } = useUser()
  const workspace = useWorkspaceStore(s => s.workspace)

  const { data: analytics } = useQuery({
    queryKey: ['workspace-analytics', workspace?.id],
    queryFn: () => analyticsApi.workspace(workspace!.id, '30d').then(r => r.data),
    enabled: !!workspace?.id,
  })

  const { data: recentContent } = useQuery({
    queryKey: ['recent-content', workspace?.id],
    queryFn: () => contentApi.list(workspace!.id, { page: 1, perPage: 6 }).then(r => r.data),
    enabled: !!workspace?.id,
  })

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'
  const firstName = user?.firstName || user?.username || 'there'

  const statCards = [
    { label: 'Total Content',   value: analytics?.totalContent || 0,         icon: FileText,   color: 'bg-ink-50 text-ink-600' },
    { label: 'Published (30d)', value: analytics?.publishedThisMonth || 0,   icon: Globe,      color: 'bg-sage-50 text-sage-600' },
    { label: 'Avg SEO Score',   value: `${analytics?.avgSeoScore || 0}/100`, icon: TrendingUp, color: 'bg-amber-50 text-amber-600' },
    { label: 'Tokens Used',     value: ((analytics?.tokensUsed || 0) / 1000).toFixed(1) + 'K', icon: Zap, color: 'bg-purple-50 text-purple-600' },
  ]

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">

      {/* ── Header with user profile ─────────────────────────────────── */}
      <div className="flex items-center justify-between mb-8">
  <div className="flex items-center gap-4">
    {/* Avatar */}
    <div className="relative">
      {user?.imageUrl ? (
        <img
          src={user.imageUrl}
          alt={firstName}
          className="w-12 h-12 rounded-xl object-cover border-2 border-ink-200"
        />
      ) : (
        <div className="w-12 h-12 rounded-xl bg-sage-500 flex items-center justify-center text-white font-display text-lg">
          {firstName[0]?.toUpperCase()}
        </div>
      )}
      <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-sage-400 rounded-full border-2 border-white" />
    </div>
    <div>
      <h1 className="font-display text-2xl text-ink-900 leading-tight">
        {greeting}, {firstName} ✦
      </h1>
      <p className="text-sm text-ink-400 mt-0.5">
        {workspace?.name} · {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
      </p>
    </div>
  </div>

  <div className="flex items-center gap-3">
    <button
      onClick={() => navigate('/generate')}
      className="flex items-center gap-2 bg-ink-900 text-white px-5 py-2.5 rounded-xl
                 text-sm font-medium hover:bg-ink-700 transition shadow-card"
    >
      <Plus size={15} />
      New Content
    </button>
    <SignOutButton>
      <button className="flex items-center gap-2 border border-ink-200 text-ink-600 px-4 py-2.5
                         rounded-xl text-sm font-medium hover:bg-ink-50 hover:border-ink-300 transition">
        <LogOut size={15} />
        Sign Out
      </button>
    </SignOutButton>
  </div>
</div>

      {/* ── Stats ────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-4 gap-4">
        {statCards.map(({ label, value, icon: Icon, color }, i) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07 }}
            className="bg-white border border-ink-200 rounded-xl p-5 shadow-card"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs text-ink-400 uppercase tracking-wider font-medium">{label}</p>
                <p className="text-2xl font-display text-ink-900 mt-1">{value}</p>
              </div>
              <div className={clsx('p-2 rounded-lg', color)}>
                <Icon size={17} />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* ── Quick Actions ─────────────────────────────────────────────── */}
      <div>
        <p className="text-xs font-semibold text-ink-400 uppercase tracking-wider mb-3">Quick Generate</p>
        <div className="grid grid-cols-4 gap-3">
          {[
            { icon: '📝', label: 'Blog Post',        type: 'blog' },
            { icon: '💼', label: 'LinkedIn Post',    type: 'linkedin_post' },
            { icon: '📧', label: 'Email Newsletter', type: 'email_newsletter' },
            { icon: '🎬', label: 'Video Script',     type: 'video_script' },
          ].map(({ icon, label, type }) => (
            <button
              key={type}
              onClick={() => navigate('/generate')}
              className="flex items-center gap-3 p-4 bg-white border border-ink-200 rounded-xl
                         hover:border-sage-400 hover:shadow-card transition text-left group"
            >
              <span className="text-xl">{icon}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-ink-800 group-hover:text-sage-700 transition truncate">{label}</p>
              </div>
              <ArrowRight size={13} className="text-ink-300 group-hover:text-sage-500 transition flex-shrink-0" />
            </button>
          ))}
        </div>
      </div>

      {/* ── Recent Content ────────────────────────────────────────────── */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-semibold text-ink-400 uppercase tracking-wider flex items-center gap-2">
            <Clock size={12} /> Recent Content
          </p>
          <button
            onClick={() => navigate('/workspace')}
            className="text-xs text-sage-600 hover:underline"
          >
            View all →
          </button>
        </div>

        <div className="bg-white border border-ink-200 rounded-xl shadow-card overflow-hidden">
          {recentContent?.data?.length > 0 ? (
            <div className="divide-y divide-ink-50">
              {recentContent.data.map((content: Content, i: number) => (
                <motion.div
                  key={content.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => navigate(`/workspace/${content.id}`)}
                  className="flex items-center gap-4 px-5 py-3.5 hover:bg-ink-50 cursor-pointer transition group"
                >
                  <span className="text-xl flex-shrink-0">{TYPE_ICONS[content.type] || '📄'}</span>

                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-ink-800 truncate group-hover:text-sage-700 transition">
                      {content.title}
                    </p>
                    <p className="text-xs text-ink-400 mt-0.5">
                      {formatContentType(content.type)} · {formatRelativeDate(content.updatedAt)}
                      {content.wordCount > 0 && ` · ${content.wordCount} words`}
                    </p>
                  </div>

                  <div className="flex items-center gap-3 flex-shrink-0">
                    {content.seoScore > 0 && (
                      <span className={clsx(
                        'text-xs font-mono px-2 py-0.5 rounded-full',
                        content.seoScore >= 80 ? 'bg-sage-50 text-sage-600' :
                        content.seoScore >= 60 ? 'bg-amber-50 text-amber-600' :
                        'bg-red-50 text-red-500'
                      )}>
                        SEO {content.seoScore}
                      </span>
                    )}
                    <ArrowRight size={13} className="text-ink-300 group-hover:text-sage-400 transition" />
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="px-6 py-12 text-center">
              <div className="w-12 h-12 bg-sage-50 rounded-xl flex items-center justify-center mx-auto mb-3">
                <Wand2 size={22} className="text-sage-500" />
              </div>
              <p className="text-sm font-medium text-ink-600">No content yet</p>
              <p className="text-xs text-ink-400 mt-1">Generate your first piece to get started</p>
              <button
                onClick={() => navigate('/generate')}
                className="mt-4 text-sm text-sage-600 hover:underline font-medium"
              >
                Generate content →
              </button>
            </div>
          )}
        </div>
      </div>

    </div>
  )
}
