import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, LineChart,
  Line, AreaChart, Area, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis,
} from 'recharts'
import { useWorkspaceStore } from '@/store'
import { analyticsApi, contentApi } from '@/services/api'
import {
  TrendingUp, BarChart3, Zap, FileText,
  Clock, Star, Target, Activity,
} from 'lucide-react'
import { formatContentType, getContentTypeIcon, getSEOScoreColor } from '@/utils/formatters'
import { useNavigate } from 'react-router-dom'
import clsx from 'clsx'

const COLORS = ['#528444', '#74a166', '#9dbc8f', '#c4d7b8', '#3d6a32', '#e1ebda']

type DateRange = '7d' | '30d' | '90d'

export function AnalyticsPage() {
  const workspace = useWorkspaceStore(s => s.workspace)
  const navigate = useNavigate()
  const [range, setRange] = useState<DateRange>('30d')

  const { data: analytics, isLoading } = useQuery({
    queryKey: ['analytics', workspace?.id, range],
    queryFn: () => analyticsApi.workspace(workspace!.id, range).then(r => r.data),
    enabled: !!workspace?.id,
  })

  const { data: allContent } = useQuery({
    queryKey: ['all-content', workspace?.id],
    queryFn: () => contentApi.list(workspace!.id, { perPage: 50 }).then(r => r.data),
    enabled: !!workspace?.id,
  })

  // ── Derived data ──────────────────────────────────────────────────────────

  const typeData = analytics?.contentByType
    ? Object.entries(analytics.contentByType).map(([type, count]) => ({
        name: formatContentType(type),
        count: count as number,
        icon: getContentTypeIcon(type),
      }))
    : []

  const statusData = analytics?.contentByStatus
    ? Object.entries(analytics.contentByStatus).map(([status, count]) => ({
        name: status.replace('_', ' '),
        value: count as number,
      }))
    : []

  // SEO score distribution from all content
  const seoDistribution = [
    { label: 'Excellent (80+)', count: 0, color: '#528444' },
    { label: 'Good (60-79)',    count: 0, color: '#f59e0b' },
    { label: 'Needs work (<60)', count: 0, color: '#ef4444' },
  ]
  allContent?.data?.forEach((c: any) => {
    if (c.seoScore >= 80) seoDistribution[0].count++
    else if (c.seoScore >= 60) seoDistribution[1].count++
    else seoDistribution[2].count++
  })

  // Readability radar data
  const radarData = [
    { subject: 'SEO',         value: analytics?.avgSeoScore || 0 },
    { subject: 'Readability', value: analytics?.avgReadabilityScore || 0 },
    { subject: 'Output Rate', value: Math.min(100, (analytics?.publishedThisMonth || 0) * 10) },
    { subject: 'Variety',     value: Math.min(100, typeData.length * 15) },
    { subject: 'Volume',      value: Math.min(100, (analytics?.totalContent || 0) * 5) },
  ]

  // Word count by content type
  const wordCountData = allContent?.data
    ? Object.entries(
        allContent.data.reduce((acc: any, c: any) => {
          const type = formatContentType(c.type)
          if (!acc[type]) acc[type] = { total: 0, count: 0 }
          acc[type].total += c.wordCount || 0
          acc[type].count++
          return acc
        }, {})
      ).map(([type, data]: any) => ({
        type: type.length > 10 ? type.slice(0, 10) + '…' : type,
        avgWords: Math.round(data.total / data.count),
      }))
    : []

  // Simulated weekly trend (replace with real data when tracking is active)
  const trendData = Array.from({ length: 7 }, (_, i) => {
    const d = new Date()
    d.setDate(d.getDate() - (6 - i))
    return {
      day: d.toLocaleDateString('en-US', { weekday: 'short' }),
      content: Math.floor(Math.random() * 4),
      seoScore: 60 + Math.floor(Math.random() * 30),
    }
  })

  if (isLoading) {
    return (
      <div className="p-8 space-y-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-40 bg-ink-100 rounded-xl animate-pulse" />
        ))}
      </div>
    )
  }

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">

      {/* ── Header ──────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl text-ink-900">Analytics</h1>
          <p className="text-ink-500 text-sm mt-1">Content performance and quality insights</p>
        </div>

        {/* Range selector */}
        <div className="flex gap-1 bg-ink-100 rounded-lg p-1">
          {(['7d', '30d', '90d'] as DateRange[]).map(r => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={clsx(
                'px-3 py-1.5 rounded-md text-xs font-medium transition',
                range === r ? 'bg-white text-ink-800 shadow-sm' : 'text-ink-500 hover:text-ink-700'
              )}
            >
              {r === '7d' ? '7 days' : r === '30d' ? '30 days' : '90 days'}
            </button>
          ))}
        </div>
      </div>

      {/* ── KPI Cards ────────────────────────────────────────────────── */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'Total Content',   value: analytics?.totalContent || 0,                    icon: FileText,   bg: 'bg-ink-50',    text: 'text-ink-700' },
          { label: 'Published',       value: analytics?.publishedThisMonth || 0,              icon: TrendingUp, bg: 'bg-sage-50',   text: 'text-sage-700' },
          { label: 'Avg SEO Score',   value: `${analytics?.avgSeoScore || 0}/100`,            icon: Target,     bg: 'bg-amber-50',  text: 'text-amber-700' },
          { label: 'API Cost',        value: `$${(analytics?.apiCost || 0).toFixed(3)}`,      icon: Zap,        bg: 'bg-purple-50', text: 'text-purple-700' },
        ].map(({ label, value, icon: Icon, bg, text }) => (
          <div key={label} className="bg-white border border-ink-200 rounded-xl p-5 shadow-card">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs text-ink-400 uppercase tracking-wider font-medium">{label}</p>
                <p className="text-2xl font-display text-ink-900 mt-1">{value}</p>
              </div>
              <div className={clsx('p-2 rounded-lg', bg, text)}>
                <Icon size={17} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ── Row 1: Content by type + Weekly trend ──────────────────── */}
      <div className="grid grid-cols-2 gap-6">

        {/* Content by type bar chart */}
        <div className="bg-white border border-ink-200 rounded-xl p-6 shadow-card">
          <h2 className="text-sm font-semibold text-ink-800 mb-4 flex items-center gap-2">
            <BarChart3 size={14} className="text-sage-500" />
            Content by Type
          </h2>
          {typeData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={typeData} margin={{ left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0ede7" />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#8a8680' }} />
                <YAxis tick={{ fontSize: 10, fill: '#8a8680' }} />
                <Tooltip
                  contentStyle={{ fontSize: 12, border: '1px solid #e4e0d8', borderRadius: 8 }}
                />
                <Bar dataKey="count" fill="#528444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-ink-400 text-sm">
              No content yet
            </div>
          )}
        </div>

        {/* Weekly generation trend */}
        <div className="bg-white border border-ink-200 rounded-xl p-6 shadow-card">
          <h2 className="text-sm font-semibold text-ink-800 mb-4 flex items-center gap-2">
            <Activity size={14} className="text-sage-500" />
            Weekly Activity
          </h2>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={trendData} margin={{ left: -20 }}>
              <defs>
                <linearGradient id="colorContent" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#528444" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#528444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0ede7" />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#8a8680' }} />
              <YAxis tick={{ fontSize: 11, fill: '#8a8680' }} />
              <Tooltip contentStyle={{ fontSize: 12, border: '1px solid #e4e0d8', borderRadius: 8 }} />
              <Area
                type="monotone"
                dataKey="content"
                stroke="#528444"
                strokeWidth={2}
                fill="url(#colorContent)"
                name="Content generated"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

      </div>

      {/* ── Row 2: Status pie + SEO distribution ───────────────────── */}
      <div className="grid grid-cols-2 gap-6">

        {/* Status breakdown */}
        <div className="bg-white border border-ink-200 rounded-xl p-6 shadow-card">
          <h2 className="text-sm font-semibold text-ink-800 mb-4 flex items-center gap-2">
            <Clock size={14} className="text-sage-500" />
            Content by Status
          </h2>
          <div className="flex items-center gap-6">
            <ResponsiveContainer width="55%" height={180}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%" cy="50%"
                  innerRadius={50} outerRadius={75}
                  dataKey="value" paddingAngle={3}
                >
                  {statusData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ fontSize: 12, border: '1px solid #e4e0d8', borderRadius: 8 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-2 flex-1">
              {statusData.map((item, i) => (
                <div key={item.name} className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                  <span className="text-xs text-ink-600 capitalize flex-1">{item.name}</span>
                  <span className="text-xs font-semibold text-ink-800">{item.value}</span>
                </div>
              ))}
              {statusData.length === 0 && (
                <p className="text-xs text-ink-400">No data yet</p>
              )}
            </div>
          </div>
        </div>

        {/* SEO score distribution */}
        <div className="bg-white border border-ink-200 rounded-xl p-6 shadow-card">
          <h2 className="text-sm font-semibold text-ink-800 mb-4 flex items-center gap-2">
            <Target size={14} className="text-sage-500" />
            SEO Score Distribution
          </h2>
          <div className="space-y-3 mt-2">
            {seoDistribution.map(({ label, count, color }) => {
              const total = seoDistribution.reduce((a, b) => a + b.count, 0)
              const pct = total > 0 ? Math.round((count / total) * 100) : 0
              return (
                <div key={label}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-ink-600">{label}</span>
                    <span className="font-semibold text-ink-800">{count} ({pct}%)</span>
                  </div>
                  <div className="h-2 bg-ink-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%`, background: color }}
                    />
                  </div>
                </div>
              )
            })}
            {allContent?.data?.length === 0 && (
              <p className="text-xs text-ink-400 text-center py-4">Generate content to see SEO scores</p>
            )}
          </div>
        </div>

      </div>

      {/* ── Row 3: Content radar + Avg word count ──────────────────── */}
      <div className="grid grid-cols-2 gap-6">

        {/* Quality radar */}
        <div className="bg-white border border-ink-200 rounded-xl p-6 shadow-card">
          <h2 className="text-sm font-semibold text-ink-800 mb-4 flex items-center gap-2">
            <Star size={14} className="text-sage-500" />
            Content Quality Radar
          </h2>
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#e4e0d8" />
              <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11, fill: '#8a8680' }} />
              <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 9, fill: '#b3ada0' }} />
              <Radar
                name="Score"
                dataKey="value"
                stroke="#528444"
                fill="#528444"
                fillOpacity={0.15}
                strokeWidth={2}
              />
              <Tooltip contentStyle={{ fontSize: 12, border: '1px solid #e4e0d8', borderRadius: 8 }} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Avg word count by type */}
        <div className="bg-white border border-ink-200 rounded-xl p-6 shadow-card">
          <h2 className="text-sm font-semibold text-ink-800 mb-4 flex items-center gap-2">
            <FileText size={14} className="text-sage-500" />
            Avg Word Count by Type
          </h2>
          {wordCountData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={wordCountData} layout="vertical" margin={{ left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0ede7" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 10, fill: '#8a8680' }} />
                <YAxis dataKey="type" type="category" tick={{ fontSize: 10, fill: '#8a8680' }} width={70} />
                <Tooltip contentStyle={{ fontSize: 12, border: '1px solid #e4e0d8', borderRadius: 8 }} />
                <Bar dataKey="avgWords" fill="#9dbc8f" radius={[0, 4, 4, 0]} name="Avg words" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-ink-400 text-sm">
              No content data yet
            </div>
          )}
        </div>

      </div>

      {/* ── Top Performing Content ────────────────────────────────── */}
      {analytics?.topPerformingContent?.length > 0 && (
        <div className="bg-white border border-ink-200 rounded-xl shadow-card">
          <div className="px-6 py-4 border-b border-ink-100 flex items-center gap-2">
            <TrendingUp size={14} className="text-sage-500" />
            <h2 className="text-sm font-semibold text-ink-800">Top Performing Content</h2>
          </div>
          <div className="divide-y divide-ink-50">
            {analytics.topPerformingContent.map((content: any, i: number) => (
              <div
                key={content.id}
                onClick={() => navigate(`/workspace/${content.id}`)}
                className="flex items-center gap-4 px-6 py-3.5 hover:bg-ink-50 cursor-pointer transition"
              >
                <span className="text-lg w-6 text-center">{getContentTypeIcon(content.type)}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-ink-800 truncate">{content.title}</p>
                  <p className="text-xs text-ink-400 capitalize">{formatContentType(content.type)}</p>
                </div>
                <div className="flex items-center gap-5 text-xs flex-shrink-0">
                  {content.analytics?.views > 0 && (
                    <div className="text-center">
                      <p className="font-semibold text-ink-700">{content.analytics.views}</p>
                      <p className="text-ink-400">views</p>
                    </div>
                  )}
                  <div className="text-center">
                    <p className={clsx('font-semibold', getSEOScoreColor(content.seoScore))}>
                      {content.seoScore}
                    </p>
                    <p className="text-ink-400">SEO</p>
                  </div>
                  <div className="text-center">
                    <p className="font-semibold text-ink-700">{content.wordCount}</p>
                    <p className="text-ink-400">words</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  )
}
