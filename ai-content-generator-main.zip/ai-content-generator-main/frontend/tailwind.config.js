/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        body: ['"DM Sans"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        ink: {
          50:  '#f4f3f0',
          100: '#e8e6e0',
          200: '#d1cdc4',
          300: '#b3ada0',
          400: '#93897a',
          500: '#796e5f',
          600: '#635a4d',
          700: '#504940',
          800: '#443e36',
          900: '#3b3630',
          950: '#1e1b17',
        },
        sage: {
          50:  '#f1f5ee',
          100: '#e1ebda',
          200: '#c4d7b8',
          300: '#9dbc8f',
          400: '#74a166',
          500: '#528444',
          600: '#3d6a32',
          700: '#315429',
          800: '#294424',
          900: '#223820',
          950: '#101f0f',
        },
        amber: {
          50:  '#fffbeb',
          100: '#fef3c7',
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
        },
      },
      animation: {
        'fade-up': 'fadeUp 0.4s ease both',
        'fade-in': 'fadeIn 0.3s ease both',
        'slide-in': 'slideIn 0.35s ease both',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
        'stream': 'stream 0.8s ease-in-out infinite',
      },
      keyframes: {
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(16px)' },
          to:   { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          from: { opacity: '0' },
          to:   { opacity: '1' },
        },
        slideIn: {
          from: { opacity: '0', transform: 'translateX(-16px)' },
          to:   { opacity: '1', transform: 'translateX(0)' },
        },
        stream: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.3' },
        },
      },
      boxShadow: {
        'card': '0 1px 3px rgba(0,0,0,0.08), 0 4px 16px rgba(0,0,0,0.04)',
        'elevated': '0 4px 24px rgba(0,0,0,0.12)',
        'inner-sm': 'inset 0 1px 3px rgba(0,0,0,0.06)',
      },
    },
  },
  plugins: [],
}
