export type ContentType =
  | 'blog'
  | 'twitter_thread'
  | 'linkedin_post'
  | 'email_newsletter'
  | 'ad_copy'
  | 'video_script'
  | 'carousel'
  | 'product_description'

export type Tone =
  | 'professional'
  | 'casual'
  | 'persuasive'
  | 'witty'
  | 'inspirational'
  | 'authoritative'
  | 'empathetic'

export type FunnelStage = 'TOFU' | 'MOFU' | 'BOFU'

export interface GenerateRequest {
  topic: string
  contentType: ContentType
  tone: Tone
  targetAudience: 'beginner' | 'intermediate' | 'expert'
  funnelStage?: FunnelStage
  keywords?: string[]
  useRealTimeData?: boolean
  useBrandVoice?: boolean
  outputFormats?: ContentType[]
  niche?: string
}

export interface AgentStep {
  id: string
  name: string
  description: string
  status: 'idle' | 'running' | 'done' | 'error'
  output?: string
  tokensUsed?: number
  model?: string
  durationMs?: number
}
