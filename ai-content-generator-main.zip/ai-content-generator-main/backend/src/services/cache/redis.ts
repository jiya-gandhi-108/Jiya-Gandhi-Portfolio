import Redis from 'ioredis'
import { logger } from '../../utils/logger'

let redisClient: Redis | null = null

export async function initRedis(): Promise<void> {
  if (!process.env.REDIS_URL) {
    logger.warn('REDIS_URL not set — caching disabled')
    return
  }

  redisClient = new Redis(process.env.REDIS_URL, {
    maxRetriesPerRequest: 3,
    lazyConnect: true,
    connectTimeout: 5000,
  })

  redisClient.on('error', (err) => logger.error('Redis error', err))
  redisClient.on('connect', () => logger.info('✅ Redis connected'))

  await redisClient.connect().catch(err => {
  logger.warn('Redis failed — caching disabled:', err.message)
  redisClient = null
})
}

export function getRedisClient(): Redis | null {
  return redisClient
}

export async function cacheGet(key: string): Promise<string | null> {
  if (!redisClient) return null
  try {
    return await redisClient.get(key)
  } catch (err) {
    logger.warn(`Cache GET failed: ${key}`, err)
    return null
  }
}

export async function cacheSet(key: string, value: string, ttlSeconds: number): Promise<void> {
  if (!redisClient) return
  try {
    await redisClient.setex(key, ttlSeconds, value)
  } catch (err) {
    logger.warn(`Cache SET failed: ${key}`, err)
  }
}

export async function cacheDel(key: string): Promise<void> {
  if (!redisClient) return
  try {
    await redisClient.del(key)
  } catch (err) {
    logger.warn(`Cache DEL failed: ${key}`, err)
  }
}

export async function cacheGetOrSet<T>(
  key: string,
  factory: () => Promise<T>,
  ttlSeconds: number
): Promise<T> {
  const cached = await cacheGet(key)
  if (cached) {
    try {
      return JSON.parse(cached) as T
    } catch {}
  }

  const value = await factory()
  await cacheSet(key, JSON.stringify(value), ttlSeconds)
  return value
}
