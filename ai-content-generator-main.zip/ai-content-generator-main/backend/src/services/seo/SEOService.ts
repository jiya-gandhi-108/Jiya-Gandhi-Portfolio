import axios from 'axios'
import { complete } from '../ai/modelRouter'
import { cacheGetOrSet } from '../cache/redis'
import { logger } from '../../utils/logger'

export class SEOService {
  // ─── Keyword research via DataForSEO ─────────────────────────────────────

  async getKeywords(topic: string): Promise<{
    keyword: string
    searchVolume: number
    difficulty: number
    cpc: number
    intent: string
    relatedKeywords: string[]
  }[]> {
    return cacheGetOrSet(`seo:keywords:${topic}`, async () => {
      if (!process.env.DATAFORSEO_LOGIN) {
        return this.getFallbackKeywords(topic)
      }

      try {
        const auth = Buffer.from(
          `${process.env.DATAFORSEO_LOGIN}:${process.env.DATAFORSEO_PASSWORD}`
        ).toString('base64')

        const { data } = await axios.post(
          'https://api.dataforseo.com/v3/keywords_data/google/search_volume/live',
          [{ keywords: [topic], location_code: 2840, language_code: 'en' }],
          {
            headers: {
              Authorization: `Basic ${auth}`,
              'Content-Type': 'application/json',
            },
            timeout: 10000,
          }
        )

        const results = data?.tasks?.[0]?.result || []
        return results.map((r: any) => ({
          keyword: r.keyword,
          searchVolume: r.search_volume || 0,
          difficulty: r.keyword_difficulty || 0,
          cpc: r.cpc || 0,
          intent: this.detectIntent(r.keyword),
          relatedKeywords: [],
        }))
      } catch (err) {
        logger.warn('DataForSEO failed, using AI fallback', err)
        return this.getFallbackKeywords(topic)
      }
    }, 86400) // 24h cache
  }

  // ─── Competitor analysis ──────────────────────────────────────────────────

  async analyzeCompetitors(keyword: string): Promise<{
    url: string
    title: string
    wordCount: number
    headings: string[]
    keyInsights: string[]
  }[]> {
    return cacheGetOrSet(`seo:competitors:${keyword}`, async () => {
      if (!process.env.SERPER_API_KEY) return []

      try {
        const { data } = await axios.post(
          'https://google.serper.dev/search',
          { q: keyword, num: 5 },
          {
            headers: { 'X-API-KEY': process.env.SERPER_API_KEY },
            timeout: 8000,
          }
        )

        const results = data.organic?.slice(0, 5) || []

        // Use AI to extract insights from snippets
        const analysisResult = await complete({
          task: 'seo',
          system: 'Extract SEO insights from search results. Return JSON array.',
          messages: [{
            role: 'user',
            content: `Analyze these top-ranking pages for "${keyword}" and extract insights:
${results.map((r: any) => `URL: ${r.link}\nTitle: ${r.title}\nSnippet: ${r.snippet}`).join('\n\n')}

Return JSON array with: [{url, title, wordCount (estimate), headings (extract from snippet), keyInsights (what makes it rank)}]`,
          }],
        })

        const jsonMatch = analysisResult.text.match(/\[[\s\S]*\]/)
        if (jsonMatch) return JSON.parse(jsonMatch[0])
        return []
      } catch (err) {
        logger.warn('Competitor analysis failed', err)
        return []
      }
    }, 3600)
  }

  // ─── Analyze existing content ─────────────────────────────────────────────

  async analyzeContent(text: string, keywords: string[]) {
    const wordCount = text.split(/\s+/).length
    const keywordDensity = this.calculateDensity(text, keywords)
    const headingStructure = this.extractHeadings(text)
    const suggestions = this.generateSuggestions(text, keywords, keywordDensity, headingStructure)
    const readabilityScore = this.calculateReadability(text)

    return {
      keywordDensity,
      headingStructure,
      suggestions,
      readabilityScore,
      wordCount,
    }
  }

  // ─── Generate content calendar ────────────────────────────────────────────

  async generateContentCalendar(params: {
    topic: string
    weeks: number
    contentTypes: string[]
    funnelStrategy: boolean
  }) {
    const result = await complete({
      task: 'outline',
      system: 'You are a content strategist. Return structured content calendar as JSON.',
      messages: [{
        role: 'user',
        content: `Create a ${params.weeks}-week content calendar for: "${params.topic}"
Content types: ${params.contentTypes.join(', ')}
${params.funnelStrategy ? 'Map content to TOFU/MOFU/BOFU funnel stages.' : ''}

Return JSON array: [{
  week: number,
  day: string (Mon/Wed/Fri),
  title: string,
  type: string,
  funnelStage: string,
  keywords: string[],
  angle: string,
  estimatedTime: string
}]`,
      }],
    })

    const jsonMatch = result.text.match(/\[[\s\S]*\]/)
    return jsonMatch ? JSON.parse(jsonMatch[0]) : []
  }

  // ─── Topic cluster generation ─────────────────────────────────────────────

  async generateTopicCluster(pillarTopic: string) {
    const result = await complete({
      task: 'outline',
      messages: [{
        role: 'user',
        content: `Generate a complete topic cluster for the pillar topic: "${pillarTopic}"

Return JSON: {
  pillarTopic: string,
  pillarArticle: { title, targetKeyword, wordCount, funnelStage },
  clusterArticles: [{ title, targetKeyword, wordCount, funnelStage, internalLinkAnchor }],
  supportingContent: [{ type, title, platform }]
}

Include 8-12 cluster articles and 4-6 supporting content pieces.`,
      }],
    })

    const jsonMatch = result.text.match(/\{[\s\S]*\}/)
    return jsonMatch ? JSON.parse(jsonMatch[0]) : null
  }

  // ─── Private helpers ──────────────────────────────────────────────────────

  private calculateDensity(text: string, keywords: string[]): Record<string, number> {
    const words = text.toLowerCase().split(/\s+/).length
    const density: Record<string, number> = {}

    for (const kw of keywords) {
      const regex = new RegExp(kw.toLowerCase(), 'g')
      const matches = (text.toLowerCase().match(regex) || []).length
      density[kw] = parseFloat(((matches / words) * 100).toFixed(2))
    }

    return density
  }

  private extractHeadings(text: string): { level: number; text: string }[] {
    const lines = text.split('\n')
    return lines
      .filter(l => l.startsWith('#'))
      .map(l => {
        const match = l.match(/^(#{1,6})\s+(.+)$/)
        return match ? { level: match[1].length, text: match[2] } : null
      })
      .filter(Boolean) as { level: number; text: string }[]
  }

  private generateSuggestions(
    text: string,
    keywords: string[],
    density: Record<string, number>,
    headings: { level: number; text: string }[]
  ) {
    const suggestions: { type: 'error' | 'warning' | 'info'; message: string; fix?: string }[] = []

    if (!headings.some(h => h.level === 1)) {
      suggestions.push({ type: 'error', message: 'Missing H1 heading', fix: 'Add a single H1 with your primary keyword' })
    }

    for (const [kw, d] of Object.entries(density)) {
      if (d > 3) suggestions.push({ type: 'warning', message: `Keyword "${kw}" density is ${d}% (too high)`, fix: 'Reduce to 1-2%' })
      if (d < 0.5) suggestions.push({ type: 'warning', message: `Keyword "${kw}" density is ${d}% (too low)`, fix: 'Include keyword more naturally' })
    }

    const wordCount = text.split(/\s+/).length
    if (wordCount < 800) suggestions.push({ type: 'warning', message: `Content is only ${wordCount} words`, fix: 'Target 1500+ words for better ranking' })

    if (headings.length < 3) suggestions.push({ type: 'info', message: 'Few headings detected', fix: 'Add more H2/H3 headings for structure' })

    return suggestions
  }

  private calculateReadability(text: string): number {
    const sentences = text.split(/[.!?]+/).filter(Boolean)
    const words = text.split(/\s+/).filter(Boolean)
    const syllables = words.reduce((acc, w) => acc + this.countSyllables(w), 0)

    if (sentences.length === 0 || words.length === 0) return 70

    const avgSentenceLength = words.length / sentences.length
    const avgSyllablesPerWord = syllables / words.length

    // Flesch Reading Ease formula
    const score = 206.835 - 1.015 * avgSentenceLength - 84.6 * avgSyllablesPerWord
    return Math.min(100, Math.max(0, Math.round(score)))
  }

  private countSyllables(word: string): number {
    word = word.toLowerCase().replace(/[^a-z]/g, '')
    if (word.length <= 3) return 1
    const matches = word.match(/[aeiouy]{1,2}/g)
    return matches ? matches.length : 1
  }

  private detectIntent(keyword: string): string {
    const kw = keyword.toLowerCase()
    if (kw.startsWith('buy ') || kw.startsWith('best ') || kw.includes('price') || kw.includes('cheap')) return 'commercial'
    if (kw.startsWith('how to') || kw.startsWith('what is') || kw.startsWith('why')) return 'informational'
    if (kw.includes(' vs ') || kw.includes('review') || kw.includes('compare')) return 'commercial'
    return 'informational'
  }

  private async getFallbackKeywords(topic: string) {
    const result = await complete({
      task: 'seo',
      messages: [{
        role: 'user',
        content: `Generate 10 SEO keyword variations for "${topic}". 
Return JSON array: [{keyword, searchVolume (estimate), difficulty (0-100), cpc (estimate), intent, relatedKeywords}]`,
      }],
    })

    const jsonMatch = result.text.match(/\[[\s\S]*\]/)
    return jsonMatch ? JSON.parse(jsonMatch[0]) : []
  }
}
