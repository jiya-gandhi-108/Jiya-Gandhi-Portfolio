import 'dotenv/config'
import Groq from 'groq-sdk'
import { logger } from '../../utils/logger'
import { cacheGet, cacheSet } from '../cache/redis'
import crypto from 'crypto'

function getGroqClient() {
  const apiKey = process.env.GROQ_API_KEY
  if (!apiKey) throw new Error('GROQ_API_KEY is not set')
  return new Groq({ apiKey })
}

export type ModelTier = 'fast' | 'balanced' | 'quality'

const MODELS: Record<ModelTier, string> = {
  fast:     'llama-3.1-8b-instant',
  balanced: 'llama-3.3-70b-versatile',
  quality:  'llama-3.3-70b-versatile',
}

const TASK_ROUTING: Record<string, ModelTier> = {
  research:     'balanced',
  outline:      'fast',
  draft:        'balanced',
  editor:       'balanced',
  seo:          'fast',
  repurpose:    'fast',
  seo_keywords: 'fast',
  brand_voice:  'quality',
  fact_check:   'balanced',
  image_prompt: 'fast',
  score:        'fast',
}

export interface CompletionRequest {
  system?: string
  messages: { role: 'user' | 'assistant'; content: string }[]
  task: keyof typeof TASK_ROUTING
  preferredTier?: ModelTier
  maxTokens?: number
  stream?: boolean
  cacheKey?: string
  cacheTtl?: number
}

export interface CompletionResult {
  text: string
  model: string
  inputTokens: number
  outputTokens: number
  costUsd: number
  cached: boolean
}

export async function complete(req: CompletionRequest): Promise<CompletionResult> {
  // Check cache first
  if (req.cacheKey) {
    const cached = await cacheGet(req.cacheKey)
    if (cached) {
      logger.debug(`Cache hit: ${req.cacheKey}`)
      return { ...JSON.parse(cached), cached: true }
    }
  }

  const autoKey = req.cacheTtl && !req.cacheKey
    ? `llm:${crypto.createHash('md5').update(JSON.stringify(req.messages)).digest('hex')}`
    : null

  const tier = req.preferredTier || TASK_ROUTING[req.task] || 'balanced'
  const modelName = MODELS[tier]

  logger.debug(`Routing task "${req.task}" → ${tier} (${modelName})`)

  try {
    const groq = getGroqClient()

    const messages: any[] = []
    if (req.system) messages.push({ role: 'system', content: req.system })
    messages.push(...req.messages)

    const response = await groq.chat.completions.create({
      model: modelName,
      messages,
      max_tokens: req.maxTokens || 8192,
      temperature: 0.7,
    })

    const text = response.choices[0]?.message?.content || ''

    const output: CompletionResult = {
      text,
      model: modelName,
      inputTokens: response.usage?.prompt_tokens || 0,
      outputTokens: response.usage?.completion_tokens || 0,
      costUsd: 0,
      cached: false,
    }

    const cKey = req.cacheKey || autoKey
    if (cKey && req.cacheTtl) {
      await cacheSet(cKey, JSON.stringify(output), req.cacheTtl)
    }

    return output
  } catch (err: any) {
    logger.error('Groq API error:', err?.message)
    throw err
  }
}

export async function completeStream(
  req: CompletionRequest,
  onChunk: (text: string) => void,
  onDone: (result: Omit<CompletionResult, 'cached'>) => void
): Promise<void> {
  const tier = req.preferredTier || TASK_ROUTING[req.task] || 'balanced'
  const modelName = MODELS[tier]

  const groq = getGroqClient()

  const messages: any[] = []
  if (req.system) messages.push({ role: 'system', content: req.system })
  messages.push(...req.messages)

  const stream = await groq.chat.completions.create({
    model: modelName,
    messages,
    max_tokens: req.maxTokens || 8192,
    temperature: 0.7,
    stream: true,
  })

  let fullText = ''
  let inputTokens = 0
  let outputTokens = 0

  for await (const chunk of stream) {
    const text = chunk.choices[0]?.delta?.content || ''
    if (text) {
      fullText += text
      onChunk(text)
    }
    if (chunk.x_groq?.usage) {
      inputTokens = chunk.x_groq.usage.prompt_tokens || 0
      outputTokens = chunk.x_groq.usage.completion_tokens || 0
    }
  }

  onDone({
    text: fullText,
    model: modelName,
    inputTokens,
    outputTokens,
    costUsd: 0,
  })
}

export function getTierForPreference(preference: string): ModelTier {
  if (preference === 'fast') return 'fast'
  if (preference === 'quality') return 'quality'
  return 'balanced'
}