import axios from 'axios'
import OpenAI from 'openai'
import { complete } from './modelRouter'
import { logger } from '../../utils/logger'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

export class MediaService {
  // ─── Image Generation ─────────────────────────────────────────────────────

  async generateImage(prompt: string, style?: string): Promise<{ url: string; prompt: string; model: string }> {
    // First enhance the prompt with AI
    const enhancedPrompt = await this.enhanceImagePrompt(prompt, style)

    // Try Stability AI first, fall back to DALL-E
    if (process.env.STABILITY_API_KEY) {
      try {
        return await this.generateWithStability(enhancedPrompt)
      } catch (err) {
        logger.warn('Stability AI failed, falling back to DALL-E', err)
      }
    }

    return await this.generateWithDallE(enhancedPrompt)
  }

  private async enhanceImagePrompt(topic: string, style?: string): Promise<string> {
    const result = await complete({
      task: 'image_prompt',
      messages: [{
        role: 'user',
        content: `Create a detailed image generation prompt for: "${topic}"
Style: ${style || 'professional, clean, modern'}
Requirements: photorealistic OR illustration, suitable for blog/social media header,
16:9 ratio composition. No text in image. Include lighting, mood, subject, composition.
Return only the prompt, nothing else.`,
      }],
    })
    return result.text.trim()
  }

  private async generateWithStability(prompt: string): Promise<{ url: string; prompt: string; model: string }> {
    const { data } = await axios.post(
      'https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image',
      {
        text_prompts: [{ text: prompt, weight: 1 }],
        cfg_scale: 7,
        height: 576,
        width: 1024,
        steps: 30,
        samples: 1,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.STABILITY_API_KEY}`,
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        timeout: 60000,
      }
    )

    const base64 = data.artifacts[0].base64
    // In production: upload to S3/Cloudflare R2 and return URL
    const url = `data:image/png;base64,${base64}`

    return { url, prompt, model: 'stable-diffusion-xl' }
  }

  private async generateWithDallE(prompt: string): Promise<{ url: string; prompt: string; model: string }> {
    const response = await openai.images.generate({
      model: 'dall-e-3',
      prompt,
      n: 1,
      size: '1792x1024',
      quality: 'standard',
    })

    return {
      url: response.data[0].url || '',
      prompt,
      model: 'dall-e-3',
    }
  }

  // ─── Voiceover / TTS ──────────────────────────────────────────────────────

  async generateVoiceover(text: string, voice?: string): Promise<{ url: string; model: string }> {
    if (process.env.ELEVENLABS_API_KEY) {
      try {
        return await this.generateWithElevenLabs(text, voice)
      } catch (err) {
        logger.warn('ElevenLabs failed, falling back to OpenAI TTS', err)
      }
    }

    return await this.generateWithOpenAITTS(text, voice)
  }

  private async generateWithElevenLabs(text: string, voiceId?: string): Promise<{ url: string; model: string }> {
    const { data } = await axios.post(
      `https://api.elevenlabs.io/v1/text-to-speech/${voiceId || 'EXAVITQu4vr4xnSDxMaL'}`,
      {
        text: text.slice(0, 5000),
        model_id: 'eleven_multilingual_v2',
        voice_settings: { stability: 0.5, similarity_boost: 0.75 },
      },
      {
        headers: {
          'xi-api-key': process.env.ELEVENLABS_API_KEY,
          'Content-Type': 'application/json',
          Accept: 'audio/mpeg',
        },
        responseType: 'arraybuffer',
        timeout: 60000,
      }
    )

    // In production: upload buffer to S3
    const url = 'audio-placeholder-url'
    return { url, model: 'elevenlabs-v2' }
  }

  private async generateWithOpenAITTS(text: string, voice?: string): Promise<{ url: string; model: string }> {
    const response = await openai.audio.speech.create({
      model: 'tts-1',
      voice: (voice as any) || 'alloy',
      input: text.slice(0, 4096),
    })

    const buffer = Buffer.from(await response.arrayBuffer())
    // In production: upload buffer to S3
    const url = 'audio-placeholder-url'
    return { url, model: 'openai-tts-1' }
  }
}
