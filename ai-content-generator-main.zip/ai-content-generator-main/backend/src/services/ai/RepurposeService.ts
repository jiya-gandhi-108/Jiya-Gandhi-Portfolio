import { complete } from './modelRouter'

const REPURPOSE_PROMPTS: Record<string, string> = {
  twitter_thread: `Convert this content into a high-engagement Twitter/X thread.
Format: 
- Tweet 1: Hook (bold claim or surprising fact)
- Tweets 2-9: One key insight each, max 240 chars
- Tweet 10: CTA + follow prompt
Number each tweet. Use line breaks for readability. Add relevant emojis sparingly.`,

  linkedin_post: `Rewrite this content as a LinkedIn long-form post.
Structure:
- Hook line (standalone, scroll-stopping)
- 3-5 short paragraphs (2-3 sentences each)
- Key insight or lesson
- Question or CTA
Use line breaks between paragraphs. Professional but conversational tone.`,

  email_newsletter: `Convert this into an email newsletter.
Include:
- Subject line (curiosity-driven, 50 chars max)
- Preview text (90 chars max)
- Personalized greeting
- 3 sections with subheadings
- Main CTA button text
- P.S. line
HTML-friendly formatting with clear sections.`,

  carousel: `Convert into a 10-slide LinkedIn/Instagram carousel outline.
Slide 1: Hook (bold claim)
Slides 2-9: One insight per slide (headline + 2-3 bullet points or 40-word explanation)
Slide 10: CTA slide (follow/save/share + value promise)
Label each slide clearly.`,

  video_script: `Convert into a video script.
Format:
[0-15s] HOOK: (attention-grabbing opener, state the big promise)
[15-30s] INTRO: (who this is for, what they'll learn)
[30s-4min] MAIN CONTENT: (3-5 points with transitions)
[Last 30s] CTA: (subscribe, comment, next video)
Include [B-ROLL suggestions] and [ON-SCREEN TEXT] notes.`,

  ad_copy: `Create 3 ad copy variations from this content.
Variation A — Problem/Solution:
Headline: (max 8 words)
Body: (max 30 words, pain-point focused)
CTA: (action verb + benefit)

Variation B — Benefit/Feature:
Headline: ...
Body: ...
CTA: ...

Variation C — Social Proof/Authority:
Headline: ...
Body: ...
CTA: ...`,
}

const PLATFORM_MAP: Record<string, string> = {
  twitter_thread: 'Twitter/X',
  linkedin_post: 'LinkedIn',
  email_newsletter: 'Email',
  carousel: 'LinkedIn/Instagram',
  video_script: 'YouTube/TikTok',
  ad_copy: 'Google/Meta Ads',
}

export class RepurposeService {
  async repurpose(
    content: { title: string; body: string; type: string },
    targetTypes: string[]
  ): Promise<{ type: string; platform: string; body: string }[]> {
    const results = await Promise.allSettled(
      targetTypes.map(async (type) => {
        const prompt = REPURPOSE_PROMPTS[type]
        if (!prompt) throw new Error(`Unknown type: ${type}`)

        const result = await complete({
          task: 'repurpose',
          system: `You are an expert content repurposer. Transform content for different platforms
while preserving the core message, value, and insights. Adapt format and tone to platform norms.`,
          messages: [{
            role: 'user',
            content: `${prompt}

Original content title: "${content.title}"
Original content:
${content.body.slice(0, 4000)}

Write the repurposed version now:`,
          }],
        })

        return {
          type,
          platform: PLATFORM_MAP[type] || type,
          body: result.text,
        }
      })
    )

    return results
      .filter((r): r is PromiseFulfilledResult<any> => r.status === 'fulfilled')
      .map(r => r.value)
  }
}
