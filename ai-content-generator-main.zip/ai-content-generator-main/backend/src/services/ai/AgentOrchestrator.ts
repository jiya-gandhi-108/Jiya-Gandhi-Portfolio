import { PrismaClient } from '@prisma/client'
import { emitToJob, getIO } from '../../utils/socketEmitter'
import { logger } from '../../utils/logger'
import { complete, completeStream, getTierForPreference } from '../ai/modelRouter'
import { ResearchAgent } from '../../agents/research/ResearchAgent'
import { OutlineAgent } from '../../agents/outline/OutlineAgent'
import { DraftAgent } from '../../agents/draft/DraftAgent'
import { EditorAgent } from '../../agents/editor/EditorAgent'
import { SEOAgent } from '../../agents/seo/SEOAgent'
import { MemoryService } from '../memory/MemoryService'
import type { GenerateRequest, AgentStep } from '../../types'

const prisma = new PrismaClient()

export interface OrchestratorResult {
  contentId: string
  title: string
  body: string
  seoScore: number
  readabilityScore: number
  wordCount: number
  metaTitle: string
  metaDescription: string
  totalTokens: number
  totalCostUsd: number
}

export class AgentOrchestrator {
  private jobId: string
  private workspaceId: string
  private userId: string
  private request: GenerateRequest
  private modelTier: string
  private memory: MemoryService

  constructor(params: {
    jobId: string
    workspaceId: string
    userId: string
    request: GenerateRequest
    modelTier: string
  }) {
    this.jobId = params.jobId
    this.workspaceId = params.workspaceId
    this.userId = params.userId
    this.request = params.request
    this.modelTier = params.modelTier
    this.memory = new MemoryService(params.workspaceId)
  }

  async run(): Promise<OrchestratorResult> {
    let totalTokens = 0
    let totalCostUsd = 0

    const track = (tokens: number, cost: number) => {
      totalTokens += tokens
      totalCostUsd += cost
    }

    try {
      // ── Step 1: Research ─────────────────────────────────────────────────
      await this.startStep('research', 'Research Agent', 'Fetching live data, trends & competitor insights')

      const researchAgent = new ResearchAgent()
      const research = await researchAgent.run({
        topic: this.request.topic,
        useRealTimeData: this.request.useRealTimeData,
        keywords: this.request.keywords,
      })
      track(research.tokens, research.cost)

      await this.completeStep('research', research.output)
      this.emitStream(`\n📊 Research complete. Found ${research.sources.length} sources.\n`)

      // ── Step 2: Outline ──────────────────────────────────────────────────
      await this.startStep('outline', 'Outline Agent', 'Building content structure & topic clusters')

      // Pull similar past content from memory to avoid repetition
      const similarContent = this.request.useBrandVoice
        ? await this.memory.getSimilarContent(this.request.topic, 3)
        : []

      const outlineAgent = new OutlineAgent()
      const outline = await outlineAgent.run({
        topic: this.request.topic,
        contentType: this.request.contentType,
        funnelStage: this.request.funnelStage,
        targetAudience: this.request.targetAudience,
        research: research.output,
        avoidTopics: similarContent.map(c => c.title),
        modelTier: getTierForPreference(this.modelTier) as any,
      })
      track(outline.tokens, outline.cost)

      await this.completeStep('outline', outline.output)

      // ── Step 3: Draft ────────────────────────────────────────────────────
      await this.startStep('draft', 'Draft Agent', 'Writing brand-voice-aware content')

      // Load brand voice from memory
      const brandVoice = this.request.useBrandVoice
        ? await this.memory.getBrandVoiceContext()
        : null

      const draftAgent = new DraftAgent()
      let draftOutput = ''
      const draftResult = await draftAgent.runStreaming({
        topic: this.request.topic,
        contentType: this.request.contentType,
        tone: this.request.tone,
        targetAudience: this.request.targetAudience,
        outline: outline.output,
        research: research.output,
        brandVoice,
        keywords: this.request.keywords,
        modelTier: getTierForPreference(this.modelTier) as any,
        wordLimit: (this.request as any).wordLimit || 1000,
        onChunk: (chunk) => {
          draftOutput += chunk
          this.emitStream(chunk)
        },
      })
      track(draftResult.tokens, draftResult.cost)

      await this.completeStep('draft', draftOutput)

      // ── Step 4: Editor ───────────────────────────────────────────────────
      await this.startStep('editor', 'Editor Agent', 'Removing fluff, improving clarity & tone')

      const editorAgent = new EditorAgent()
      const edited = await editorAgent.run({
        content: draftOutput,
        tone: this.request.tone,
        targetAudience: this.request.targetAudience,
        modelTier: getTierForPreference(this.modelTier) as any,
      })
      track(edited.tokens, edited.cost)

      await this.completeStep('editor', edited.output)

      // ── Step 5: SEO ──────────────────────────────────────────────────────
      await this.startStep('seo', 'SEO Agent', 'Optimizing keywords, headings & readability')

      const seoAgent = new SEOAgent()
      const seoResult = await seoAgent.run({
        content: edited.output,
        topic: this.request.topic,
        keywords: this.request.keywords || [],
        contentType: this.request.contentType,
      })
      track(seoResult.tokens, seoResult.cost)

      await this.completeStep('seo', seoResult.optimizedContent)

      // ── Save to DB ───────────────────────────────────────────────────────
      const wordCount = seoResult.optimizedContent.trim().split(/\s+/).length
      const title = this.extractTitle(seoResult.optimizedContent) || this.request.topic

      const content = await prisma.content.create({
        data: {
          workspaceId: this.workspaceId,
          title,
          body: seoResult.optimizedContent,
          type: this.request.contentType as any,
          status: 'draft',
          tone: this.request.tone as any,
          keywords: this.request.keywords || [],
          seoScore: seoResult.seoScore,
          readabilityScore: seoResult.readabilityScore,
          wordCount,
          funnelStage: this.request.funnelStage as any,
          metaTitle: seoResult.metaTitle,
          metaDescription: seoResult.metaDescription,
        },
      })

      // Save initial version
      await prisma.contentVersion.create({
        data: {
          contentId: content.id,
          body: seoResult.optimizedContent,
          label: 'Initial generation',
          createdBy: this.userId,
        },
      })

      // Link job to content
      await prisma.agentJob.update({
        where: { id: this.jobId },
        data: {
          contentId: content.id,
          status: 'completed',
          completedAt: new Date(),
          totalTokens,
          totalCostUsd,
        },
      })

      // Store embedding for future RAG queries
      await this.memory.storeContentEmbedding(content.id, `${title}\n${seoResult.optimizedContent}`)

      // Emit completion
      this.emitComplete(content.id)

      return {
        contentId: content.id,
        title,
        body: seoResult.optimizedContent,
        seoScore: seoResult.seoScore,
        readabilityScore: seoResult.readabilityScore,
        wordCount,
        metaTitle: seoResult.metaTitle || '',
        metaDescription: seoResult.metaDescription || '',
        totalTokens,
        totalCostUsd,
      }
    } catch (err: any) {
      logger.error(`AgentOrchestrator failed for job ${this.jobId}`, err)

      await prisma.agentJob.update({
        where: { id: this.jobId },
        data: { status: 'failed', error: err.message },
      })

      emitToJob(this.jobId, 'job:error', {
        jobId: this.jobId,
        error: err.message || 'Agent pipeline failed',
      })

      throw err
    }
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────

  private async startStep(id: string, name: string, description: string) {
    const step = await prisma.agentStep.create({
      data: {
        jobId: this.jobId,
        name,
        description,
        status: 'running',
        startedAt: new Date(),
      },
    })

    const job = await prisma.agentJob.findUnique({
      where: { id: this.jobId },
      include: { steps: true },
    })

    emitToJob(this.jobId, 'job:step', job)
    logger.info(`[${this.jobId}] Starting step: ${name}`)

    return step
  }

  private async completeStep(id: string, output: string) {
    await prisma.agentStep.updateMany({
      where: { jobId: this.jobId, status: 'running' },
      data: {
        status: 'done',
        output: output.slice(0, 10000), // truncate for DB
        completedAt: new Date(),
      },
    })

    const job = await prisma.agentJob.findUnique({
      where: { id: this.jobId },
      include: { steps: true },
    })

    emitToJob(this.jobId, 'job:step', job)
  }

  private emitStream(text: string) {
    emitToJob(this.jobId, 'job:stream', {
      jobId: this.jobId,
      text,
    })
  }

  private async emitComplete(contentId: string) {
    const content = await prisma.content.findUnique({
      where: { id: contentId },
      include: { versions: true, mediaAssets: true },
    })

    emitToJob(this.jobId, 'job:complete', {
      jobId: this.jobId,
      content,
    })
  }

  private extractTitle(body: string): string | null {
    const match = body.match(/^#\s+(.+)$/m)
    return match ? match[1].trim() : null
  }
}
