import { PrismaClient } from '@prisma/client'
import OpenAI from 'openai'
import { logger } from '../../utils/logger'
import { cacheGet, cacheSet } from '../cache/redis'

const prisma = new PrismaClient()
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

export class MemoryService {
  private workspaceId: string

  constructor(workspaceId: string) {
    this.workspaceId = workspaceId
  }

  // ─── Embeddings ───────────────────────────────────────────────────────────

  async embed(text: string): Promise<number[]> {
    const cacheKey = `embed:${Buffer.from(text.slice(0, 200)).toString('base64')}`
    const cached = await cacheGet(cacheKey)
    if (cached) return JSON.parse(cached)

    const response = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: text.slice(0, 8000),
    })

    const embedding = response.data[0].embedding
    await cacheSet(cacheKey, JSON.stringify(embedding), 86400) // 24h
    return embedding
  }

  // ─── Store content embedding in pgvector ──────────────────────────────────

  async storeContentEmbedding(contentId: string, text: string): Promise<void> {
    try {
      const embedding = await this.embed(text)
      const vectorStr = `[${embedding.join(',')}]`

      await prisma.$executeRaw`
        UPDATE "Content" 
        SET embedding = ${vectorStr}::vector
        WHERE id = ${contentId}
      `
      logger.debug(`Stored embedding for content ${contentId}`)
    } catch (err) {
      logger.warn('Failed to store content embedding', err)
    }
  }

  // ─── Find similar past content (avoid repetition) ─────────────────────────

  async getSimilarContent(
    topic: string,
    limit = 5
  ): Promise<{ id: string; title: string; similarity: number }[]> {
    try {
      const embedding = await this.embed(topic)
      const vectorStr = `[${embedding.join(',')}]`

      const results = await prisma.$queryRaw<any[]>`
        SELECT 
          id, title,
          1 - (embedding <=> ${vectorStr}::vector) AS similarity
        FROM "Content"
        WHERE "workspaceId" = ${this.workspaceId}
          AND embedding IS NOT NULL
          AND status != 'draft'
        ORDER BY embedding <=> ${vectorStr}::vector
        LIMIT ${limit}
      `

      return results.filter(r => r.similarity > 0.7)
    } catch (err) {
      logger.warn('Similar content search failed', err)
      return []
    }
  }

  // ─── Get brand voice context for generation ───────────────────────────────

  async getBrandVoiceContext(): Promise<string | null> {
    const cacheKey = `brand-voice:${this.workspaceId}`
    const cached = await cacheGet(cacheKey)
    if (cached) return cached

    try {
      const brandVoice = await prisma.brandVoice.findUnique({
        where: { workspaceId: this.workspaceId },
        include: { audienceProfiles: true },
      })

      if (!brandVoice) return null

      // Get recent high-performing content as style examples
      const exampleContent = await prisma.content.findMany({
        where: {
          workspaceId: this.workspaceId,
          status: 'published',
        },
        orderBy: { createdAt: 'desc' },
        take: 3,
        select: { title: true, body: true },
      })

      const context = `
Brand Voice Profile:
- Tone: ${brandVoice.tone.join(', ')}
- Writing Style: ${brandVoice.writingStyle}
- Vocabulary to USE: ${brandVoice.vocabulary.join(', ')}
- Words to AVOID: ${brandVoice.avoidWords.join(', ')}

${exampleContent.length > 0 ? `Style Reference (excerpt from past content):
${exampleContent.map(c => `Title: ${c.title}\nExcerpt: ${c.body.slice(0, 300)}...`).join('\n\n')}` : ''}
`.trim()

      await cacheSet(cacheKey, context, 3600)
      return context
    } catch (err) {
      logger.warn('Failed to get brand voice context', err)
      return null
    }
  }

  // ─── RAG: retrieve relevant past content chunks ───────────────────────────

  async retrieveRelevantChunks(query: string, limit = 5): Promise<string[]> {
    const similar = await this.getSimilarContent(query, limit)

    if (similar.length === 0) return []

    const contents = await prisma.content.findMany({
      where: { id: { in: similar.map(s => s.id) } },
      select: { title: true, body: true },
    })

    return contents.map(c => `[${c.title}]\n${c.body.slice(0, 500)}`)
  }

  // ─── Update brand voice after successful generation ───────────────────────

  async updateBrandVoiceFromContent(contentId: string): Promise<void> {
    // Clear cache so next request gets fresh context
    const cacheKey = `brand-voice:${this.workspaceId}`
    await cacheSet(cacheKey, '', 1) // expire immediately
  }
}
