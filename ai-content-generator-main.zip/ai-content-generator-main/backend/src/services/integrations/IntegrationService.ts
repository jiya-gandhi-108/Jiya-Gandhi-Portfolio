import axios from 'axios'
import { logger } from '../../utils/logger'

interface ContentData {
  title: string
  body: string
  metaTitle?: string | null
  metaDescription?: string | null
  keywords: string[]
}

interface IntegrationData {
  type: string
  config: any
}

export class IntegrationService {
  async publish(content: ContentData, integration: IntegrationData): Promise<{ url?: string; success: boolean; message: string }> {
    switch (integration.type) {
      case 'wordpress':  return this.publishToWordPress(content, integration.config)
      case 'ghost':      return this.publishToGhost(content, integration.config)
      case 'webflow':    return this.publishToWebflow(content, integration.config)
      case 'zapier':     return this.triggerZapier(content, integration.config)
      case 'make':       return this.triggerMake(content, integration.config)
      default:
        return { success: false, message: `Unknown integration: ${integration.type}` }
    }
  }

  // ─── WordPress REST API ───────────────────────────────────────────────────

  private async publishToWordPress(content: ContentData, config: any) {
    const { siteUrl, username, appPassword } = config
    const auth = Buffer.from(`${username}:${appPassword}`).toString('base64')

    const { data } = await axios.post(
      `${siteUrl}/wp-json/wp/v2/posts`,
      {
        title: content.title,
        content: this.markdownToHtml(content.body),
        status: 'draft', // always draft first for safety
        excerpt: content.metaDescription || '',
        tags: content.keywords,
      },
      {
        headers: {
          Authorization: `Basic ${auth}`,
          'Content-Type': 'application/json',
        },
        timeout: 15000,
      }
    )

    return { url: data.link, success: true, message: `Published to WordPress (ID: ${data.id})` }
  }

  // ─── Ghost Admin API ──────────────────────────────────────────────────────

  private async publishToGhost(content: ContentData, config: any) {
    const { adminUrl, adminApiKey } = config

    // Ghost Admin API uses JWT auth
    const [id, secret] = adminApiKey.split(':')
    const token = this.createGhostJWT(id, secret)

    const { data } = await axios.post(
      `${adminUrl}/ghost/api/admin/posts/`,
      {
        posts: [{
          title: content.title,
          html: this.markdownToHtml(content.body),
          status: 'draft',
          meta_title: content.metaTitle,
          meta_description: content.metaDescription,
          tags: content.keywords.map(k => ({ name: k })),
        }],
      },
      {
        headers: {
          Authorization: `Ghost ${token}`,
          'Content-Type': 'application/json',
        },
        timeout: 15000,
      }
    )

    const post = data.posts[0]
    return { url: post.url, success: true, message: `Published to Ghost (ID: ${post.id})` }
  }

  // ─── Webflow CMS ──────────────────────────────────────────────────────────

  private async publishToWebflow(content: ContentData, config: any) {
    const { apiToken, siteId, collectionId } = config

    const { data } = await axios.post(
      `https://api.webflow.com/v2/collections/${collectionId}/items`,
      {
        isArchived: false,
        isDraft: true,
        fieldData: {
          name: content.title,
          slug: content.title.toLowerCase().replace(/\s+/g, '-'),
          'post-body': this.markdownToHtml(content.body),
          'meta-title': content.metaTitle || content.title,
          'meta-description': content.metaDescription || '',
        },
      },
      {
        headers: {
          Authorization: `Bearer ${apiToken}`,
          'Content-Type': 'application/json',
        },
        timeout: 15000,
      }
    )

    return { success: true, message: `Published to Webflow CMS (ID: ${data.id})` }
  }

  // ─── Zapier Webhook ───────────────────────────────────────────────────────

  private async triggerZapier(content: ContentData, config: any) {
    const { webhookUrl } = config

    await axios.post(webhookUrl, {
      title: content.title,
      body: content.body,
      metaTitle: content.metaTitle,
      metaDescription: content.metaDescription,
      keywords: content.keywords,
      timestamp: new Date().toISOString(),
    }, { timeout: 10000 })

    return { success: true, message: 'Zapier webhook triggered' }
  }

  // ─── Make.com Webhook ─────────────────────────────────────────────────────

  private async triggerMake(content: ContentData, config: any) {
    const { webhookUrl } = config

    await axios.post(webhookUrl, {
      title: content.title,
      body: content.body,
      keywords: content.keywords.join(', '),
      timestamp: new Date().toISOString(),
    }, { timeout: 10000 })

    return { success: true, message: 'Make.com webhook triggered' }
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────

  private markdownToHtml(markdown: string): string {
    // Basic markdown to HTML conversion
    // In production use `marked` or `remark` packages
    return markdown
      .replace(/^### (.+)$/gm, '<h3>$1</h3>')
      .replace(/^## (.+)$/gm, '<h2>$1</h2>')
      .replace(/^# (.+)$/gm, '<h1>$1</h1>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/^/, '<p>')
      .replace(/$/, '</p>')
  }

  private createGhostJWT(id: string, secret: string): string {
    // Simplified JWT creation for Ghost
    // In production: use jsonwebtoken package
    const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT', kid: id })).toString('base64url')
    const payload = Buffer.from(JSON.stringify({
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 300,
      aud: '/admin/',
    })).toString('base64url')
    return `${header}.${payload}.signature` // placeholder
  }
}
