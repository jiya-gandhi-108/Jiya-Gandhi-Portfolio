import { logger } from './logger'

// ─── Slug ─────────────────────────────────────────────────────────────────────

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80)
}

export function uniqueSlug(base: string, suffix?: string): string {
  const s = slugify(base)
  return suffix ? `${s}-${suffix}` : `${s}-${Date.now()}`
}

// ─── Retry ───────────────────────────────────────────────────────────────────

export async function withRetry<T>(
  fn: () => Promise<T>,
  options: {
    retries?: number
    delayMs?: number
    backoff?: boolean
    label?: string
  } = {}
): Promise<T> {
  const { retries = 3, delayMs = 500, backoff = true, label = 'operation' } = options

  let lastError: Error | undefined

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      return await fn()
    } catch (err: any) {
      lastError = err
      if (attempt < retries) {
        const wait = backoff ? delayMs * Math.pow(2, attempt - 1) : delayMs
        logger.warn(`${label} failed (attempt ${attempt}/${retries}), retrying in ${wait}ms…`)
        await sleep(wait)
      }
    }
  }

  throw lastError
}

// ─── Sleep ────────────────────────────────────────────────────────────────────

export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

// ─── Chunk array ─────────────────────────────────────────────────────────────

export function chunk<T>(arr: T[], size: number): T[][] {
  const chunks: T[][] = []
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size))
  }
  return chunks
}

// ─── Parse JSON safely ────────────────────────────────────────────────────────

export function safeJsonParse<T>(text: string, fallback: T): T {
  try {
    // Strip markdown code fences if present
    const clean = text
      .replace(/^```(?:json)?\s*/i, '')
      .replace(/\s*```$/i, '')
      .trim()
    return JSON.parse(clean)
  } catch {
    // Try extracting first JSON object/array
    const objMatch = text.match(/\{[\s\S]*\}/)
    const arrMatch = text.match(/\[[\s\S]*\]/)
    const match = objMatch || arrMatch
    if (match) {
      try { return JSON.parse(match[0]) } catch {}
    }
    return fallback
  }
}

// ─── Text helpers ─────────────────────────────────────────────────────────────

export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength).trimEnd() + '…'
}

export function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length
}

export function extractFirstHeading(markdown: string): string | null {
  const match = markdown.match(/^#\s+(.+)$/m)
  return match ? match[1].trim() : null
}

export function stripMarkdown(markdown: string): string {
  return markdown
    .replace(/#{1,6}\s+/g, '')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/\*(.+?)\*/g, '$1')
    .replace(/`(.+?)`/g, '$1')
    .replace(/\[(.+?)\]\(.+?\)/g, '$1')
    .replace(/\n{2,}/g, '\n')
    .trim()
}

// ─── Environment helpers ──────────────────────────────────────────────────────

export function requireEnv(key: string): string {
  const val = process.env[key]
  if (!val) throw new Error(`Missing required environment variable: ${key}`)
  return val
}

export function isProduction(): boolean {
  return process.env.NODE_ENV === 'production'
}
