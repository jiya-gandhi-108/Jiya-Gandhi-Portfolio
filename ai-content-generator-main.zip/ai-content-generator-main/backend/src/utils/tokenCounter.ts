/**
 * Token estimation utilities.
 * Uses tiktoken for accuracy, falls back to character-based estimate.
 */

let encoder: any = null

async function getEncoder() {
  if (encoder) return encoder
  try {
    const { get_encoding } = await import('tiktoken')
    encoder = get_encoding('cl100k_base') // same tokenizer as Claude/GPT-4
    return encoder
  } catch {
    return null
  }
}

/**
 * Estimate token count for a string.
 * Accurate when tiktoken is available, ±10% otherwise.
 */
export async function countTokens(text: string): Promise<number> {
  const enc = await getEncoder()
  if (enc) {
    return enc.encode(text).length
  }
  // Fallback: ~4 chars per token (conservative estimate)
  return Math.ceil(text.length / 4)
}

/**
 * Synchronous rough estimate — use when async is not possible.
 */
export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4)
}

/**
 * Truncate text to fit within a token budget.
 */
export async function truncateToTokens(
  text: string,
  maxTokens: number
): Promise<string> {
  const total = await countTokens(text)
  if (total <= maxTokens) return text

  // Binary-search the right character cutoff
  let lo = 0
  let hi = text.length
  while (lo < hi) {
    const mid = Math.floor((lo + hi) / 2)
    const tokens = await countTokens(text.slice(0, mid))
    if (tokens <= maxTokens) {
      lo = mid + 1
    } else {
      hi = mid
    }
  }

  return text.slice(0, lo - 1) + '…'
}

/**
 * Calculate approximate cost for a model call.
 */
export function estimateCost(params: {
  inputTokens: number
  outputTokens: number
  model: 'haiku' | 'sonnet' | 'opus'
}): number {
  const rates = {
    haiku:  { input: 0.00025, output: 0.00125 },
    sonnet: { input: 0.003,   output: 0.015   },
    opus:   { input: 0.015,   output: 0.075   },
  }
  const r = rates[params.model]
  return (
    (params.inputTokens  / 1000) * r.input +
    (params.outputTokens / 1000) * r.output
  )
}
