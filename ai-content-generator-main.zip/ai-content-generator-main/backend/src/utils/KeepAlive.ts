import https from 'https'

export function keepAlive(url: string) {
  if (process.env.NODE_ENV !== 'production') return

  setInterval(() => {
    https.get(url, (res) => {
      console.log(`Keep-alive ping: ${res.statusCode}`)
    }).on('error', () => {})
  }, 14 * 60 * 1000) // ping every 14 minutes
}