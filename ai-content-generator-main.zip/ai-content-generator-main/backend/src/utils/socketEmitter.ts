/**
 * Singleton socket.io server reference.
 * Avoids circular imports between index.ts and services that need to emit events.
 */
import { Server } from 'socket.io'

let _io: Server | null = null

export function setIO(io: Server) {
  _io = io
}

export function getIO(): Server {
  if (!_io) throw new Error('Socket.io server not initialized')
  return _io
}

export function emitToJob(jobId: string, event: string, data: any) {
  _io?.to(`job:${jobId}`).emit(event, data)
}

export function emitToRoom(room: string, event: string, data: any) {
  _io?.to(room).emit(event, data)
}
