import { Request, Response, NextFunction } from 'express'
import { ZodError } from 'zod'
import { logger } from '../utils/logger'

export function errorHandler(
  err: any,
  req: Request,
  res: Response,
  _next: NextFunction
) {
  // Log full error with stack trace
  logger.error({
    msg: `${req.method} ${req.path} failed`,
    error: err?.message,
    stack: err?.stack,
    code: err?.code,
    details: err?.response?.data || err?.cause,
  })

  if (err instanceof ZodError) {
    return res.status(400).json({
      error: 'Validation failed',
      details: err.flatten().fieldErrors,
    })
  }

  if (err.code === 'P2002') {
    return res.status(409).json({ error: 'Resource already exists' })
  }

  if (err.code === 'P2025') {
    return res.status(404).json({ error: 'Resource not found' })
  }

  const status = err.statusCode || err.status || 500
  const message = err.message || 'Internal server error'

  res.status(status).json({ error: message })
}