import { Request, Response, NextFunction } from 'express'

declare global {
  namespace Express {
    interface Request {
      auth: {
        userId: string
        sessionId: string
        getToken: () => Promise<string | null>
      }
    }
  }
}

export function authMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
) {
  req.auth = {
    userId: 'test-user-id',
    sessionId: 'test-session-id',
    getToken: async () => null,
  }
  next()
}