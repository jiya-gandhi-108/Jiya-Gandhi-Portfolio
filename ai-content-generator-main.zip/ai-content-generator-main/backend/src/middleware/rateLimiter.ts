// ─── Rate Limiter ─────────────────────────────────────────────────────────────
import rateLimit from 'express-rate-limit'

export const rateLimiter = rateLimit({
  windowMs: 60 * 1000,      // 1 minute
  max: 120,                  // 120 requests per minute per IP
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please slow down.' },
  skip: (req) => req.path === '/health',
})

export const generateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,                   // 10 generation requests per minute
  message: { error: 'Generation rate limit hit. Please wait a moment.' },
})
