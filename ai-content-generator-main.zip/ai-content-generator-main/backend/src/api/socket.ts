import { Server, Socket } from 'socket.io'
import { ClerkExpressRequireAuth } from '@clerk/clerk-sdk-node'
import { logger } from '../utils/logger'

export function registerSocketHandlers(io: Server) {
  // Middleware: authenticate socket connections
  io.use(async (socket, next) => {
    const token = socket.handshake.auth?.token
    if (!token) return next(new Error('Unauthorized'))

    try {
      // In production: verify Clerk token
      // const session = await clerkClient.sessions.verifySession(sessionId, token)
      ;(socket as any).userId = 'user-id-from-token'
      next()
    } catch {
      next(new Error('Unauthorized'))
    }
  })

  io.on('connection', (socket: Socket) => {
    const userId = (socket as any).userId
    logger.debug(`[WS] Connected: ${socket.id} (user: ${userId})`)

    // ── Job Subscription ──────────────────────────────────────────────────

    socket.on('job:subscribe', ({ jobId }: { jobId: string }) => {
      socket.join(`job:${jobId}`)
      logger.debug(`[WS] ${socket.id} subscribed to job:${jobId}`)
    })

    socket.on('job:unsubscribe', ({ jobId }: { jobId: string }) => {
      socket.leave(`job:${jobId}`)
    })

    // ── Collaboration ─────────────────────────────────────────────────────

    socket.on('collab:join', ({ contentId, userId: uid }: { contentId: string; userId: string }) => {
      socket.join(`collab:${contentId}`)
      socket.to(`collab:${contentId}`).emit('collab:user-joined', { userId: uid, socketId: socket.id })
      logger.debug(`[WS] ${uid} joined collab room: ${contentId}`)
    })

    socket.on('collab:leave', ({ contentId }: { contentId: string }) => {
      socket.leave(`collab:${contentId}`)
      socket.to(`collab:${contentId}`).emit('collab:user-left', { socketId: socket.id })
    })

    socket.on('collab:cursor', ({ contentId, position }: { contentId: string; position: any }) => {
      socket.to(`collab:${contentId}`).emit('collab:cursor', {
        userId,
        socketId: socket.id,
        position,
      })
    })

    socket.on('collab:update', ({ contentId, patch }: { contentId: string; patch: any }) => {
      socket.to(`collab:${contentId}`).emit('collab:update', { userId, patch })
    })

    socket.on('disconnect', (reason) => {
      logger.debug(`[WS] Disconnected: ${socket.id} — ${reason}`)
    })
  })
}
