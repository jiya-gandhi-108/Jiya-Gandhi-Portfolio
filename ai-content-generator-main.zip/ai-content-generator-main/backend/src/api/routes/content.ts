import { Router, Request, Response } from 'express'
import { PrismaClient } from '@prisma/client'
import { z } from 'zod'
import { validate } from '../validators/validate'
import { asyncHandler } from '../../utils/asyncHandler'
import { RepurposeService } from '../../services/ai/RepurposeService'
import { SEOService } from '../../services/seo/SEOService'
import { IntegrationService } from '../../services/integrations/IntegrationService'
import { MediaService } from '../../services/ai/MediaService'

const router = Router()
const prisma = new PrismaClient()
const repurposeService = new RepurposeService()
const seoService = new SEOService()
const integrationService = new IntegrationService()
const mediaService = new MediaService()

// GET /api/content/:id
router.get('/:id', asyncHandler(async (req, res) => {
  const content = await prisma.content.findUnique({
    where: { id: req.params.id },
    include: {
      versions: { orderBy: { createdAt: 'desc' }, take: 10 },
      comments: { include: { user: true }, orderBy: { createdAt: 'asc' } },
      repurposed: true,
      mediaAssets: true,
      analytics: true,
    },
  })
  if (!content) return res.status(404).json({ error: 'Not found' })
  res.json(content)
}))

// PATCH /api/content/:id
router.patch('/:id', asyncHandler(async (req, res) => {
  const { body, title, status, keywords, scheduledAt } = req.body

  const current = await prisma.content.findUnique({ where: { id: req.params.id } })
  if (!current) return res.status(404).json({ error: 'Not found' })

  // Create version snapshot before update
  if (body && body !== current.body) {
    await prisma.contentVersion.create({
      data: {
        contentId: current.id,
        body: current.body,
        label: 'Auto-saved',
        createdBy: req.auth.userId,
      },
    })
  }

  const updated = await prisma.content.update({
    where: { id: req.params.id },
    data: {
      ...(title && { title }),
      ...(body && {
        body,
        wordCount: body.trim().split(/\s+/).length,
      }),
      ...(status && { status }),
      ...(keywords && { keywords }),
      ...(scheduledAt && { scheduledAt: new Date(scheduledAt) }),
    },
  })

  res.json(updated)
}))

// DELETE /api/content/:id
router.delete('/:id', asyncHandler(async (req, res) => {
  await prisma.content.delete({ where: { id: req.params.id } })
  res.json({ message: 'Deleted' })
}))

// POST /api/content/:id/repurpose
router.post('/:id/repurpose', asyncHandler(async (req, res) => {
  const { targetTypes } = req.body
  const content = await prisma.content.findUnique({ where: { id: req.params.id } })
  if (!content) return res.status(404).json({ error: 'Not found' })

  const repurposed = await repurposeService.repurpose(content, targetTypes)

  // Save to DB
  const saved = await Promise.all(
    repurposed.map(r =>
      prisma.repurposedContent.create({
        data: {
          contentId: content.id,
          type: r.type as any,
          platform: r.platform,
          body: r.body,
        },
      })
    )
  )

  res.json({ repurposed: saved })
}))

// POST /api/content/:id/publish
router.post('/:id/publish', asyncHandler(async (req, res) => {
  const { integrationId } = req.body
  const content = await prisma.content.findUnique({ where: { id: req.params.id } })
  if (!content) return res.status(404).json({ error: 'Not found' })

  const integration = await prisma.integration.findUnique({ where: { id: integrationId } })
  if (!integration) return res.status(404).json({ error: 'Integration not found' })

  const result = await integrationService.publish(content, integration)

  await prisma.content.update({
    where: { id: content.id },
    data: { status: 'published', publishedAt: new Date() },
  })

  res.json(result)
}))

// GET /api/content/:id/seo
router.get('/:id/seo', asyncHandler(async (req, res) => {
  const content = await prisma.content.findUnique({ where: { id: req.params.id } })
  if (!content) return res.status(404).json({ error: 'Not found' })

  const analysis = await seoService.analyzeContent(content.body, content.keywords)
  res.json({
    ...analysis,
    score: content.seoScore,
    readabilityScore: content.readabilityScore,
    metaTitle: content.metaTitle,
    metaDescription: content.metaDescription,
  })
}))

// GET /api/content/:id/versions
router.get('/:id/versions', asyncHandler(async (req, res) => {
  const versions = await prisma.contentVersion.findMany({
    where: { contentId: req.params.id },
    include: { user: true },
    orderBy: { createdAt: 'desc' },
  })
  res.json(versions)
}))

// POST /api/content/:id/versions/:versionId/restore
router.post('/:id/versions/:versionId/restore', asyncHandler(async (req, res) => {
  const version = await prisma.contentVersion.findUnique({ where: { id: req.params.versionId } })
  if (!version) return res.status(404).json({ error: 'Version not found' })

  const updated = await prisma.content.update({
    where: { id: req.params.id },
    data: { body: version.body, wordCount: version.body.split(/\s+/).length },
  })

  res.json(updated)
}))

// POST /api/content/:id/feedback
router.post('/:id/feedback', asyncHandler(async (req, res) => {
  const { score, comment } = req.body
  await prisma.feedbackEntry.create({
    data: { contentId: req.params.id, score, comment },
  })
  res.json({ message: 'Feedback recorded' })
}))

// POST /api/content/:id/generate-image
router.post('/:id/generate-image', asyncHandler(async (req, res) => {
  const { prompt, style } = req.body
  const content = await prisma.content.findUnique({ where: { id: req.params.id } })
  if (!content) return res.status(404).json({ error: 'Not found' })

  const asset = await mediaService.generateImage(prompt || content.title, style)

  const saved = await prisma.mediaAsset.create({
    data: {
      workspaceId: content.workspaceId,
      contentId: content.id,
      type: 'image',
      url: asset.url,
      prompt: asset.prompt,
      model: asset.model,
    },
  })

  res.json(saved)
}))

// GET /api/content/:id/analytics
router.get('/:id/analytics', asyncHandler(async (req, res) => {
  const analytics = await prisma.contentAnalytics.findUnique({
    where: { contentId: req.params.id },
  })
  res.json(analytics || {})
}))

export default router

// ─── Community Feed Routes ────────────────────────────────────────────────────

// GET /api/content/feed — all published content in workspace
router.get('/feed/workspace/:workspaceId', asyncHandler(async (req, res) => {
  const { workspaceId } = req.params
  const { page = 1, perPage = 20 } = req.query

  const [items, total] = await Promise.all([
    prisma.content.findMany({
      where: { workspaceId, status: 'published' },
      orderBy: { publishedAt: 'desc' },
      skip: (Number(page) - 1) * Number(perPage),
      take: Number(perPage),
      include: {
        analytics: true,
      },
    }),
    prisma.content.count({ where: { workspaceId, status: 'published' } }),
  ])

  res.json({ data: items, meta: { page: Number(page), perPage: Number(perPage), total } })
}))

// POST /api/content/:id/publish-to-feed — publish to community feed
router.post('/:id/publish-to-feed', asyncHandler(async (req, res) => {
  const updated = await prisma.content.update({
    where: { id: req.params.id },
    data: { status: 'published', publishedAt: new Date() },
  })

  // Create analytics record if not exists
  await prisma.contentAnalytics.upsert({
    where: { contentId: req.params.id },
    create: { contentId: req.params.id },
    update: {},
  })

  res.json(updated)
}))

// POST /api/content/:id/unpublish — unpublish from feed
router.post('/:id/unpublish', asyncHandler(async (req, res) => {
  const updated = await prisma.content.update({
    where: { id: req.params.id },
    data: { status: 'draft', publishedAt: null },
  })
  res.json(updated)
}))

// POST /api/content/:id/like — like/unlike a published piece
router.post('/:id/like', asyncHandler(async (req, res) => {
  await prisma.contentAnalytics.upsert({
    where: { contentId: req.params.id },
    create: { contentId: req.params.id, socialShares: 1 },
    update: { socialShares: { increment: 1 } },
  })
  res.json({ liked: true })
}))

// POST /api/content/:id/comment — add a comment
router.post('/:id/comment', asyncHandler(async (req, res) => {
  const { body } = req.body
  if (!body?.trim()) return res.status(400).json({ error: 'Comment body required' })

  // Get user from clerkId
  const user = await prisma.user.findUnique({ where: { clerkId: req.auth.userId } })
  if (!user) return res.status(404).json({ error: 'User not found' })

  const comment = await prisma.comment.create({
    data: {
      contentId: req.params.id,
      body: body.trim(),
      createdBy: user.id,
    },
    include: { user: true },
  })

  res.json(comment)
}))

// GET /api/content/:id/comments — get all comments
router.get('/:id/comments', asyncHandler(async (req, res) => {
  const comments = await prisma.comment.findMany({
    where: { contentId: req.params.id, resolved: false },
    include: { user: true },
    orderBy: { createdAt: 'asc' },
  })
  res.json(comments)
}))
