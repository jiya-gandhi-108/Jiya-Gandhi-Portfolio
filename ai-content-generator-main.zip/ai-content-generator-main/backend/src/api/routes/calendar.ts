import { Router } from 'express'
import { PrismaClient } from '@prisma/client'
import { asyncHandler } from '../../utils/asyncHandler'

const router = Router()
const prisma = new PrismaClient()

router.post('/', asyncHandler(async (req, res) => {
  const entry = await prisma.calendarEntry.create({ data: req.body })
  res.status(201).json(entry)
}))

router.patch('/:id', asyncHandler(async (req, res) => {
  const entry = await prisma.calendarEntry.update({
    where: { id: req.params.id },
    data: req.body,
  })
  res.json(entry)
}))

router.delete('/:id', asyncHandler(async (req, res) => {
  await prisma.calendarEntry.delete({ where: { id: req.params.id } })
  res.json({ message: 'Deleted' })
}))

export default router
