import { Router, Request, Response } from 'express'
import { z } from 'zod'
import { PrismaClient } from '@prisma/client'
import { AgentOrchestrator } from '../../services/ai/AgentOrchestrator'
import { validate } from '../validators/validate'
import { asyncHandler } from '../../utils/asyncHandler'
import { logger } from '../../utils/logger'

const router = Router()
const prisma = new PrismaClient()

const GenerateSchema = z.object({
  topic: z.string().min(3).max(500),
  contentType: z.enum([
    'blog', 'twitter_thread', 'linkedin_post', 'email_newsletter',
    'ad_copy', 'video_script', 'carousel', 'product_description'
  ]),
  tone: z.enum([
    'professional', 'casual', 'persuasive', 'witty',
    'inspirational', 'authoritative', 'empathetic'
  ]).default('professional'),
  targetAudience: z.enum(['beginner', 'intermediate', 'expert']).default('intermediate'),
  funnelStage: z.enum(['TOFU', 'MOFU', 'BOFU']).optional(),
  keywords: z.array(z.string()).optional().default([]),
  useRealTimeData: z.boolean().default(true),
  useBrandVoice: z.boolean().default(true),
  outputFormats: z.array(z.string()).optional().default([]),
  niche: z.string().optional(),
  workspaceId: z.string().uuid(),
  wordLimit: z.number().min(100).max(5000).optional().default(1000),
})

// POST /api/generate — start agent job
router.post('/', validate(GenerateSchema), asyncHandler(async (req: Request, res: Response) => {
  const { workspaceId, ...generateRequest } = req.body

  // ── Look up real DB user from Clerk ID ────────────────────────────────────
  const user = await prisma.user.findUnique({
    where: { clerkId: req.auth.userId },
  })

  if (!user) {
    return res.status(404).json({ error: 'User not found. Please sign out and back in.' })
  }

  // ── Look up workspace settings for model preference ───────────────────────
  const settings = await prisma.workspaceSettings.findUnique({
    where: { workspaceId },
  })

  const modelTier = settings?.modelPreference || 'balanced'

  // ── Create job record ─────────────────────────────────────────────────────
  const job = await prisma.agentJob.create({
    data: {
      workspaceId,
      userId: user.id,
      status: 'queued',
      request: generateRequest,
    },
    include: { steps: true },
  })

  console.log('Job created:', job.id)
  res.status(202).json(job)

  // ── Run pipeline async ────────────────────────────────────────────────────
  const orchestrator = new AgentOrchestrator({
    jobId: job.id,
    workspaceId,
    userId: user.id,
    request: generateRequest,
    modelTier,
  })

  orchestrator.run().catch(err => {
    logger.error({
      msg: `Job ${job.id} failed`,
      error: err?.message,
      stack: err?.stack,
    })
  })
}))

// DELETE /api/generate/:jobId — cancel job
router.delete('/:jobId', asyncHandler(async (req: Request, res: Response) => {
  const { jobId } = req.params

  await prisma.agentJob.update({
    where: { id: jobId },
    data: { status: 'failed', error: 'Cancelled by user' },
  })

  res.json({ message: 'Job cancelled' })
}))

// GET /api/generate/:jobId — get job status
router.get('/:jobId', asyncHandler(async (req: Request, res: Response) => {
  const job = await prisma.agentJob.findUnique({
    where: { id: req.params.jobId },
    include: { steps: true },
  })

  if (!job) return res.status(404).json({ error: 'Job not found' })
  res.json(job)
}))

export default router