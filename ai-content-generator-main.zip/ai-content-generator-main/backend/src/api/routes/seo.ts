// ─── SEO Routes ───────────────────────────────────────────────────────────────
import { Router } from 'express'
import { SEOService } from '../../services/seo/SEOService'
import { asyncHandler } from '../../utils/asyncHandler'

export const seoRouter = Router()
const seoService = new SEOService()

seoRouter.get('/keywords', asyncHandler(async (req, res) => {
  const { topic } = req.query as { topic: string }
  const keywords = await seoService.getKeywords(topic)
  res.json(keywords)
}))

seoRouter.get('/competitors', asyncHandler(async (req, res) => {
  const { keyword } = req.query as { keyword: string }
  const competitors = await seoService.analyzeCompetitors(keyword)
  res.json(competitors)
}))

seoRouter.post('/analyze', asyncHandler(async (req, res) => {
  const { text, keywords } = req.body
  const analysis = await seoService.analyzeContent(text, keywords)
  res.json(analysis)
}))

export default seoRouter
