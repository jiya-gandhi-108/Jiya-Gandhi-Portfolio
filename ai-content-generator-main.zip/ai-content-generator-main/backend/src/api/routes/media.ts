// ─── Media Routes ─────────────────────────────────────────────────────────────
import { Router } from 'express'
import { asyncHandler } from '../../utils/asyncHandler'
import { MediaService } from '../../services/ai/MediaService'

export const mediaRouter = Router()
const mediaService = new MediaService()

mediaRouter.post('/image', asyncHandler(async (req, res) => {
  const { prompt, style } = req.body
  const asset = await mediaService.generateImage(prompt, style)
  res.json(asset)
}))

mediaRouter.post('/voiceover', asyncHandler(async (req, res) => {
  const { text, voice } = req.body
  const asset = await mediaService.generateVoiceover(text, voice)
  res.json(asset)
}))

export default mediaRouter
