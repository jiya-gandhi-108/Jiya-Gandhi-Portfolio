import { Router } from 'express'
import { PrismaClient } from '@prisma/client'
import { asyncHandler } from '../../utils/asyncHandler'

const prisma = new PrismaClient()

// ─── Integrations ─────────────────────────────────────────────────────────────
export const integrationRouter = Router()

integrationRouter.get('/', asyncHandler(async (req, res) => {
  const { workspaceId } = req.query
  const integrations = await prisma.integration.findMany({ where: { workspaceId: workspaceId as string } })
  res.json(integrations)
}))

integrationRouter.post('/', asyncHandler(async (req, res) => {
  const integration = await prisma.integration.create({ data: req.body })
  res.json(integration)
}))

integrationRouter.patch('/:id', asyncHandler(async (req, res) => {
  const integration = await prisma.integration.update({ where: { id: req.params.id }, data: req.body })
  res.json(integration)
}))

integrationRouter.delete('/:id', asyncHandler(async (req, res) => {
  await prisma.integration.delete({ where: { id: req.params.id } })
  res.json({ message: 'Deleted' })
}))

// ─── Analytics ────────────────────────────────────────────────────────────────
export const analyticsRouter = Router()

analyticsRouter.get('/content/:id', asyncHandler(async (req, res) => {
  const analytics = await prisma.contentAnalytics.findUnique({ where: { contentId: req.params.id } })
  res.json(analytics || {})
}))

// ─── Calendar ─────────────────────────────────────────────────────────────────
export const calendarRouter = Router()

calendarRouter.post('/', asyncHandler(async (req, res) => {
  const entry = await prisma.calendarEntry.create({ data: req.body })
  res.json(entry)
}))

calendarRouter.patch('/:id', asyncHandler(async (req, res) => {
  const entry = await prisma.calendarEntry.update({ where: { id: req.params.id }, data: req.body })
  res.json(entry)
}))

calendarRouter.delete('/:id', asyncHandler(async (req, res) => {
  await prisma.calendarEntry.delete({ where: { id: req.params.id } })
  res.json({ message: 'Deleted' })
}))

// ─── Webhooks ─────────────────────────────────────────────────────────────────
export const webhookRouter = Router()

webhookRouter.post('/clerk', asyncHandler(async (req, res) => {
  // Clerk user sync — create workspace on new user signup
  const event = JSON.parse(req.body.toString())

  if (event.type === 'user.created') {
    const { id, email_addresses, first_name, last_name } = event.data
    const email = email_addresses[0]?.email_address
    const name = [first_name, last_name].filter(Boolean).join(' ')

    await prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: { clerkId: id, email, name },
      })

      const workspace = await tx.workspace.create({
        data: {
          name: `${name}'s Workspace`,
          slug: `${name.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}`,
        },
      })

      await tx.workspaceMember.create({
        data: { workspaceId: workspace.id, userId: user.id, role: 'owner' },
      })

      await tx.workspaceSettings.create({
        data: { workspaceId: workspace.id },
      })
    })
  }

  res.json({ received: true })
}))

export { integrationRouter as default }
