import { Router } from 'express'
import { PrismaClient } from '@prisma/client'
import { asyncHandler } from '../../utils/asyncHandler'
import { logger } from '../../utils/logger'

const router = Router()
const prisma = new PrismaClient()

// POST /api/webhooks/clerk — user lifecycle events
router.post('/clerk', asyncHandler(async (req, res) => {
  const svixId = req.headers['svix-id']
  const svixTimestamp = req.headers['svix-timestamp']
  const svixSignature = req.headers['svix-signature']

  // In production: verify Svix signature
  // const wh = new Webhook(process.env.CLERK_WEBHOOK_SECRET!)
  // const event = wh.verify(req.body, { 'svix-id': svixId, ... })

  let event: any
  try {
    event = JSON.parse(req.body.toString())
  } catch {
    return res.status(400).json({ error: 'Invalid payload' })
  }

  logger.info(`Clerk webhook: ${event.type}`)

  if (event.type === 'user.created') {
    const { id, email_addresses, first_name, last_name } = event.data
    const email = email_addresses[0]?.email_address
    const name = [first_name, last_name].filter(Boolean).join(' ') || email

    try {
      await prisma.$transaction(async (tx) => {
        const user = await tx.user.create({
          data: { clerkId: id, email, name },
        })

        const slug = `${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now()}`
        const workspace = await tx.workspace.create({
          data: { name: `${name}'s Workspace`, slug },
        })

        await tx.workspaceMember.create({
          data: { workspaceId: workspace.id, userId: user.id, role: 'owner' },
        })

        await tx.workspaceSettings.create({
          data: { workspaceId: workspace.id },
        })

        logger.info(`Created user + workspace for ${email}`)
      })
    } catch (err) {
      logger.error('Failed to create user from Clerk webhook', err)
    }
  }

  if (event.type === 'user.deleted') {
    try {
      await prisma.user.delete({ where: { clerkId: event.data.id } })
    } catch (err) {
      logger.warn('User not found for deletion', err)
    }
  }

  res.json({ received: true })
}))

export default router
