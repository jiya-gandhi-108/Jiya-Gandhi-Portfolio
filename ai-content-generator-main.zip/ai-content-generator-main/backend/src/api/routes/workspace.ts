import { Router, Request, Response } from 'express'
import { PrismaClient } from '@prisma/client'
import { z } from 'zod'
import { validate } from '../validators/validate'
import { asyncHandler } from '../../utils/asyncHandler'
import { SEOService } from '../../services/seo/SEOService'
import { MemoryService } from '../../services/memory/MemoryService'

const router = Router()
const prisma = new PrismaClient()
const seoService = new SEOService()

// GET /api/workspaces/me — get current user's workspace
router.get('/me', asyncHandler(async (req, res) => {
  const userId = req.auth.userId

  // Find the user by Clerk ID
  const user = await prisma.user.findUnique({ where: { clerkId: userId } })
  if (!user) return res.status(404).json({ error: 'User not found. Please sign out and back in.' })

  // Get workspace where user is a member
  const membership = await prisma.workspaceMember.findFirst({
    where: { userId: user.id },
    include: {
      workspace: {
        include: {
          members: { include: { user: true } },
          brandVoice: { include: { audienceProfiles: true } },
          integrations: true,
          settings: true,
        },
      },
    },
    orderBy: { joinedAt: 'asc' },
  })

  if (!membership) return res.status(404).json({ error: 'No workspace found for this user.' })
  res.json(membership.workspace)
}))

// GET /api/workspaces/:id
router.get('/:id', asyncHandler(async (req, res) => {
  const workspace = await prisma.workspace.findUnique({
    where: { id: req.params.id },
    include: {
      members: { include: { user: true } },
      brandVoice: { include: { audienceProfiles: true } },
      integrations: true,
      settings: true,
    },
  })
  if (!workspace) return res.status(404).json({ error: 'Not found' })
  res.json(workspace)
}))

// PATCH /api/workspaces/:id/settings
router.patch('/:id/settings', asyncHandler(async (req, res) => {
  const settings = await prisma.workspaceSettings.upsert({
    where: { workspaceId: req.params.id },
    create: { workspaceId: req.params.id, ...req.body },
    update: req.body,
  })
  res.json(settings)
}))

// GET /api/workspaces/:id/content
router.get('/:id/content', asyncHandler(async (req, res) => {
  const { page = 1, perPage = 20, type, status, search } = req.query

  const where: any = { workspaceId: req.params.id }
  if (type) where.type = type
  if (status) where.status = status
  if (search) where.title = { contains: search, mode: 'insensitive' }

  const [items, total] = await Promise.all([
    prisma.content.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
      skip: (Number(page) - 1) * Number(perPage),
      take: Number(perPage),
      include: { analytics: true },
    }),
    prisma.content.count({ where }),
  ])

  res.json({ data: items, meta: { page: Number(page), perPage: Number(perPage), total } })
}))

// GET /api/workspaces/:id/brand-voice
router.get('/:id/brand-voice', asyncHandler(async (req, res) => {
  const brandVoice = await prisma.brandVoice.findUnique({
    where: { workspaceId: req.params.id },
    include: { audienceProfiles: true },
  })
  res.json(brandVoice || null)
}))

// PUT /api/workspaces/:id/brand-voice
router.put('/:id/brand-voice', asyncHandler(async (req, res) => {
  const { tone, vocabulary, avoidWords, writingStyle, sampleContent, audienceProfiles } = req.body

  const brandVoice = await prisma.brandVoice.upsert({
    where: { workspaceId: req.params.id },
    create: {
      workspaceId: req.params.id,
      tone, vocabulary, avoidWords, writingStyle, sampleContent,
    },
    update: { tone, vocabulary, avoidWords, writingStyle, sampleContent, embeddingUpdatedAt: new Date() },
    include: { audienceProfiles: true },
  })

  res.json(brandVoice)
}))

// GET /api/workspaces/:id/similar
router.get('/:id/similar', asyncHandler(async (req, res) => {
  const { topic } = req.query as { topic: string }
  const memory = new MemoryService(req.params.id)
  const similar = await memory.getSimilarContent(topic, 5)
  res.json(similar)
}))

// GET /api/workspaces/:id/analytics
router.get('/:id/analytics', asyncHandler(async (req, res) => {
  const { range = '30d' } = req.query
  const days = range === '7d' ? 7 : range === '90d' ? 90 : 30
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000)

  const [totalContent, publishedThisMonth, contentByType, contentByStatus, topContent, jobs] = await Promise.all([
    prisma.content.count({ where: { workspaceId: req.params.id } }),
    prisma.content.count({
      where: { workspaceId: req.params.id, status: 'published', publishedAt: { gte: since } },
    }),
    prisma.content.groupBy({
      by: ['type'],
      where: { workspaceId: req.params.id },
      _count: { type: true },
    }),
    prisma.content.groupBy({
      by: ['status'],
      where: { workspaceId: req.params.id },
      _count: { status: true },
    }),
    prisma.content.findMany({
      where: { workspaceId: req.params.id, status: 'published' },
      include: { analytics: true },
      orderBy: { analytics: { views: 'desc' } },
      take: 5,
    }),
    prisma.agentJob.aggregate({
      where: { workspaceId: req.params.id, status: 'completed' },
      _sum: { totalTokens: true, totalCostUsd: true },
    }),
  ])

  res.json({
    totalContent,
    publishedThisMonth,
    contentByType: Object.fromEntries(contentByType.map(c => [c.type, c._count.type])),
    contentByStatus: Object.fromEntries(contentByStatus.map(c => [c.status, c._count.status])),
    topContent,
    tokensUsed: jobs._sum.totalTokens || 0,
    apiCost: jobs._sum.totalCostUsd || 0,
  })
}))

// GET /api/workspaces/:id/clusters
router.get('/:id/clusters', asyncHandler(async (req, res) => {
  const clusters = await prisma.topicCluster.findMany({
    where: { workspaceId: req.params.id },
    orderBy: { createdAt: 'desc' },
  })
  res.json(clusters)
}))

// POST /api/workspaces/:id/clusters
router.post('/:id/clusters', asyncHandler(async (req, res) => {
  const { pillarTopic } = req.body
  const clusterData = await seoService.generateTopicCluster(pillarTopic)

  const cluster = await prisma.topicCluster.create({
    data: {
      workspaceId: req.params.id,
      pillarTopic,
      subtopics: clusterData?.clusterArticles?.map((a: any) => a.title) || [],
      funnelMapping: clusterData?.clusterArticles?.reduce((acc: any, a: any) => {
        acc[a.title] = a.funnelStage
        return acc
      }, {}) || {},
      contentIds: [],
    },
  })

  res.json({ cluster, details: clusterData })
}))

// GET /api/workspaces/:id/calendar
router.get('/:id/calendar', asyncHandler(async (req, res) => {
  const { start, end } = req.query

  const entries = await prisma.calendarEntry.findMany({
    where: {
      workspaceId: req.params.id,
      scheduledAt: {
        gte: new Date(start as string),
        lte: new Date(end as string),
      },
    },
    include: { content: true },
    orderBy: { scheduledAt: 'asc' },
  })

  res.json(entries)
}))

// POST /api/workspaces/:id/calendar/generate
router.post('/:id/calendar/generate', asyncHandler(async (req, res) => {
  const { topic, weeks, contentTypes, funnelStrategy } = req.body
  const plan = await seoService.generateContentCalendar({ topic, weeks, contentTypes, funnelStrategy })
  res.json(plan)
}))

// GET /api/workspaces/:id/media
router.get('/:id/media', asyncHandler(async (req, res) => {
  const media = await prisma.mediaAsset.findMany({
    where: { workspaceId: req.params.id },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })
  res.json(media)
}))


// POST /api/workspaces/:id/invite — invite a member by email
router.post('/:id/invite', asyncHandler(async (req, res) => {
  const { email, role } = req.body
  if (!email) return res.status(400).json({ error: 'Email is required' })

  // Check if user already exists
  const existingUser = await prisma.user.findUnique({ where: { email } })

  if (existingUser) {
    // Check if already a member
    const existing = await prisma.workspaceMember.findFirst({
      where: { workspaceId: req.params.id, userId: existingUser.id },
    })
    if (existing) return res.status(409).json({ error: 'User is already a member' })

    // Add them directly
    await prisma.workspaceMember.create({
      data: {
        workspaceId: req.params.id,
        userId: existingUser.id,
        role: role || 'editor',
      },
    })
    return res.json({ message: `${email} added to workspace`, status: 'added' })
  }

  // User doesn't exist yet — in production send an email invitation
  // For now return success (email would be sent via SendGrid/Resend in production)
  res.json({
    message: `Invitation sent to ${email}`,
    status: 'invited',
    email,
    role: role || 'editor',
  })
}))

export default router
