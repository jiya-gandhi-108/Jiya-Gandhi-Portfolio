import { Router } from 'express'
import { PrismaClient } from '@prisma/client'
import { asyncHandler } from '../../utils/asyncHandler'

const router = Router()
const prisma = new PrismaClient()

router.get('/content/:id', asyncHandler(async (req, res) => {
  const analytics = await prisma.contentAnalytics.findUnique({
    where: { contentId: req.params.id },
  })
  res.json(analytics || {})
}))

router.post('/content/:id/track', asyncHandler(async (req, res) => {
  const { event, value } = req.body

  const updateData: any = {}
  if (event === 'view') updateData.views = { increment: 1 }
  if (event === 'click') updateData.clicks = { increment: 1 }
  if (event === 'share') updateData.socialShares = { increment: 1 }
  if (event === 'conversion') updateData.conversions = { increment: 1 }

  const analytics = await prisma.contentAnalytics.upsert({
    where: { contentId: req.params.id },
    create: { contentId: req.params.id, ...updateData },
    update: updateData,
  })

  res.json(analytics)
}))

export default router
