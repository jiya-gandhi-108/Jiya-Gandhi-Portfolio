import 'dotenv/config'
import express from 'express'
import http from 'http'
import cors from 'cors'
import helmet from 'helmet'
import compression from 'compression'
import morgan from 'morgan'
import { Server as SocketIOServer } from 'socket.io'
import { keepAlive } from './utils/KeepALive'

import { logger } from './utils/logger'
import { setIO } from './utils/socketEmitter'
import { initRedis } from './services/cache/redis'
import { registerSocketHandlers } from './api/socket'
import { errorHandler } from './middleware/errorHandler'
import { authMiddleware } from './middleware/auth'
import { rateLimiter } from './middleware/rateLimiter'

// Routes
import generateRoutes from './api/routes/generate'
import contentRoutes from './api/routes/content'
import workspaceRoutes from './api/routes/workspace'
import seoRoutes from './api/routes/seo'
import calendarRoutes from './api/routes/calendar'
import analyticsRoutes from './api/routes/analytics'
import mediaRoutes from './api/routes/media'
import integrationRoutes from './api/routes/integrations'
import webhookRoutes from './api/routes/webhooks'

console.log('CLERK_SECRET_KEY loaded:', !!process.env.CLERK_SECRET_KEY)
console.log('NODE_ENV:', process.env.NODE_ENV)

const app = express()
const httpServer = http.createServer(app)

// ─── Socket.io ────────────────────────────────────────────────────────────────
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: ['http://localhost:5173', 'http://127.0.0.1:5173'],
    methods: ['GET', 'POST'],
    credentials: true,
  },
  transports: ['websocket', 'polling'],
})

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(helmet())
app.use(compression())
app.use(cors({
  origin: ['http://localhost:5173', 'http://127.0.0.1:5173'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}))
app.options('*', cors())
app.use(morgan('dev'))

// Webhooks need raw body
app.use('/api/webhooks', express.raw({ type: 'application/json' }), webhookRoutes)

app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true }))

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', ts: new Date().toISOString() }))

// ─── API Routes ───────────────────────────────────────────────────────────────
app.use('/api', rateLimiter)
app.use('/api', authMiddleware)

app.use('/api/generate',     generateRoutes)
app.use('/api/content',      contentRoutes)
app.use('/api/workspaces',   workspaceRoutes)
app.use('/api/seo',          seoRoutes)
app.use('/api/media',        mediaRoutes)
app.use('/api/integrations', integrationRoutes)
app.use('/api/calendar',     calendarRoutes)
app.use('/api/analytics',    analyticsRoutes)

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use(errorHandler)

// ─── Socket Handlers ──────────────────────────────────────────────────────────
setIO(io)
registerSocketHandlers(io)

// ─── Start ────────────────────────────────────────────────────────────────────
async function bootstrap() {
  // Redis is optional — don't crash if it fails
  try {
    await initRedis()
  } catch (err) {
    logger.warn('Redis unavailable — continuing without cache')
  }

  const PORT = process.env.PORT || 3001
  httpServer.listen(PORT, () => {
    logger.info(`🚀 ContentCraft API running on http://localhost:${PORT}`)
    logger.info(`🔌 WebSocket server ready`)
    logger.info(`🌍 Environment: ${process.env.NODE_ENV}`)
  })
  keepAlive(`https://ai-content-generator-tpyk.onrender.com/health`)

}

bootstrap().catch((err) => {
  logger.error('Failed to start server', err)
  process.exit(1)
})