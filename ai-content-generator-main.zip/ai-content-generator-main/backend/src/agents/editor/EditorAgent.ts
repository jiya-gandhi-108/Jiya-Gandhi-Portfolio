import { complete, ModelTier } from '../../services/ai/modelRouter'

export interface EditorInput {
  content: string
  tone: string
  targetAudience: string
  modelTier: ModelTier
  contentType?: string
}

export interface EditorOutput {
  output: string
  tokens: number
  cost: number
  editsApplied: string[]
}

// These content types have strict formats — editor should only fix errors, not rewrite
const FORMAT_SENSITIVE_TYPES = [
  'video_script',
  'ad_copy',
  'carousel',
  'twitter_thread',
  'email_newsletter',
  'product_description',
]

export class EditorAgent {
  async run(input: EditorInput): Promise<EditorOutput> {
    // For format-sensitive content types, do a light edit only
    const isFormatSensitive = FORMAT_SENSITIVE_TYPES.includes(input.contentType || '')

    const result = await complete({
      task: 'editor',
      preferredTier: input.modelTier,
      system: isFormatSensitive
        ? `You are a careful content editor. The content has a strict required format. 
Your ONLY jobs are:
1. Fix spelling and grammar errors
2. Improve weak word choices
3. Make sure every section is complete and not cut off
4. DO NOT change the structure, format, or layout in any way
5. DO NOT remove section headers, slide labels, tweet numbers, or any formatting markers
6. Return the content exactly as structured, just with errors fixed
Return the full corrected content immediately with no preamble.`
        : `You are a ruthless, world-class content editor. Your job:
1. Remove ALL fluff, filler, and generic statements
2. Tighten sentences — say more with fewer words
3. Fix passive voice → active voice
4. Ensure logical flow between paragraphs
5. Strengthen the hook and CTA
6. Make sure tone is consistent: ${input.tone}
7. Verify the content matches ${input.targetAudience} audience level
Return the edited content in full (markdown), followed by a separator "---EDITS---" 
and a bullet list of the top edits you made.`,
      messages: [{
        role: 'user',
        content: isFormatSensitive
          ? `Fix only spelling, grammar, and incomplete sections. Keep all formatting exactly as is:\n\n${input.content}`
          : `Edit this content ruthlessly. Make it tighter, clearer, and more impactful:\n\n${input.content}`,
      }],
    })

    if (isFormatSensitive) {
      return {
        output: result.text.trim(),
        tokens: result.inputTokens + result.outputTokens,
        cost: result.costUsd,
        editsApplied: ['Light edit: spelling and grammar only'],
      }
    }

    const parts = result.text.split('---EDITS---')
    const editedContent = parts[0].trim()
    const editsRaw = parts[1] || ''
    const editsApplied = editsRaw
      .split('\n')
      .map(l => l.replace(/^[-*]\s*/, '').trim())
      .filter(Boolean)

    return {
      output: editedContent,
      tokens: result.inputTokens + result.outputTokens,
      cost: result.costUsd,
      editsApplied,
    }
  }
}