import { complete } from '../../services/ai/modelRouter'
import { logger } from '../../utils/logger'

export interface SEOAgentInput {
  content: string
  topic: string
  keywords: string[]
  contentType: string
}

export interface SEOAgentOutput {
  optimizedContent: string
  seoScore: number
  readabilityScore: number
  metaTitle: string
  metaDescription: string
  tokens: number
  cost: number
}

export class SEOAgent {
  async run(input: SEOAgentInput): Promise<SEOAgentOutput> {
    const result = await complete({
      task: 'seo',
      system: `You are an expert SEO optimizer and content analyst. 
Optimize content for search engines without sacrificing quality or readability.
Return JSON with these exact keys:
{
  "optimizedContent": "full markdown content",
  "metaTitle": "60 char max",
  "metaDescription": "155 char max",  
  "seoScore": 0-100,
  "readabilityScore": 0-100,
  "changesApplied": ["list of changes"]
}`,
      messages: [{
        role: 'user',
        content: `SEO optimize this ${input.contentType} content for the topic: "${input.topic}"
Primary keywords: ${input.keywords.join(', ')}

Rules:
- Ensure H1 contains primary keyword
- Add keyword naturally to first 100 words
- Add keyword to at least 2 H2s
- Keyword density 1-2% (not more)
- Optimize image alt text placeholders
- Add FAQ schema-friendly questions if appropriate
- Improve internal linking placeholders [LINK: relevant topic]
- Write compelling meta title and description
- Score based on: keyword placement (30%), content depth (25%), 
  readability (25%), structure (20%)

Content to optimize:
${input.content.slice(0, 8000)}`,
      }],
    })

    try {
      const jsonMatch = result.text.match(/\{[\s\S]*\}/)
      if (!jsonMatch) throw new Error('No JSON in response')

      const parsed = JSON.parse(jsonMatch[0])

      return {
        optimizedContent: parsed.optimizedContent || input.content,
        seoScore: Math.min(100, Math.max(0, parsed.seoScore || 70)),
        readabilityScore: Math.min(100, Math.max(0, parsed.readabilityScore || 70)),
        metaTitle: parsed.metaTitle || input.topic.slice(0, 60),
        metaDescription: parsed.metaDescription || '',
        tokens: result.inputTokens + result.outputTokens,
        cost: result.costUsd,
      }
    } catch (err) {
      logger.warn('SEO agent JSON parse failed, returning original content')
      return {
        optimizedContent: input.content,
        seoScore: 65,
        readabilityScore: 70,
        metaTitle: input.topic.slice(0, 60),
        metaDescription: '',
        tokens: result.inputTokens + result.outputTokens,
        cost: result.costUsd,
      }
    }
  }
}
