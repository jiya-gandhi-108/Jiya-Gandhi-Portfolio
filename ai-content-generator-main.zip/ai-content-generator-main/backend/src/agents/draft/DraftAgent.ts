import { completeStream, ModelTier } from '../../services/ai/modelRouter'

export interface DraftInput {
  topic: string
  contentType: string
  tone: string
  targetAudience: string
  outline: string
  research: string
  brandVoice: string | null
  keywords?: string[]
  modelTier: ModelTier
  wordLimit?: number
  onChunk: (text: string) => void
}

export interface DraftOutput {
  tokens: number
  cost: number
}

const TONE_INSTRUCTIONS: Record<string, string> = {
  professional:  'Authoritative, clear, data-backed. No fluff. Precise vocabulary.',
  casual:        'Conversational, warm, approachable. Use contractions. Write like you talk.',
  persuasive:    'Compelling, benefit-focused, action-oriented. Use power words.',
  witty:         'Clever, slightly edgy, memorable. Unexpected angles. Smart humor.',
  inspirational: 'Uplifting, story-driven, emotionally resonant. Paint a vision.',
  authoritative: 'Expert voice, confident assertions, deep credibility signals.',
  empathetic:    'Understanding, validating, supportive. Speak to pain points directly.',
}

const FORMATTING_RULES = `
MANDATORY FORMATTING RULES — follow these exactly:
- Use **bold** for key terms, important stats, and critical points
- Use *italics* for emphasis, quotes, and nuanced points
- Use proper ## H2 headings for major sections
- Use ### H3 headings for subsections
- Use bullet points (- item) for lists of 3+ items
- Use numbered lists (1. item) for sequential steps
- Use > blockquote for important quotes or key insights
- Separate every paragraph with a blank line
- Every section must have a heading
- End with a strong ## Conclusion or ## Key Takeaways section
`

const CONTENT_PROMPTS: Record<string, (topic: string, tone: string, audience: string, research: string, keywords: string, wordLimit: number) => string> = {

  blog: (topic, tone, audience, research, keywords, wordLimit) => `
Write a complete, professionally formatted blog post about: **"${topic}"**
Target length: **${wordLimit} words**
Tone: ${tone} | Audience: ${audience} level

${FORMATTING_RULES}

REQUIRED STRUCTURE:
# [Write a compelling, SEO-optimized H1 title here]

*[Write a 2-3 sentence italicized introduction that hooks the reader immediately with a surprising fact, bold claim, or compelling question]*

## Introduction
[Write 2-3 paragraphs. Start with the reader's pain point or desire. Include the primary keyword "${keywords}" naturally in the first 100 words. End with a clear statement of what they'll learn.]

## [Section 1 — write a benefit-driven heading]
[Write 2-3 full paragraphs with specific examples, data points from research. Use **bold** for key terms. Include at least one bullet list.]

### [Subsection if needed]
[Write detailed subsection content]

## [Section 2 — write a specific, actionable heading]
[Write 2-3 full paragraphs. Include a numbered list or bullet points for clarity.]

> **Key insight:** [Write a memorable, quotable insight from this section]

## [Section 3 — write a heading focused on outcomes]
[Write 2-3 full paragraphs. Use *italics* for emphasis on important nuances.]

## [Section 4 — write a practical, how-to heading]
[Write step-by-step or actionable advice. Use numbered list for steps.]

## [Add 1-2 more sections as needed based on the topic]

## Key Takeaways
- **[Takeaway 1]:** [Brief explanation]
- **[Takeaway 2]:** [Brief explanation]  
- **[Takeaway 3]:** [Brief explanation]
- **[Takeaway 4]:** [Brief explanation]

## Conclusion
[Write 2-3 paragraphs that summarize the key points, reinforce the main argument, and end with a clear call to action telling the reader what to do next.]

Research to use: ${research.slice(0, 3000)}
Keywords to include naturally: ${keywords}

Write the COMPLETE blog post now, every section fully written, ${wordLimit} words.`,

  video_script: (topic, tone, audience, research, keywords, wordLimit) => `
Write a complete, professionally formatted video script about: **"${topic}"**
Target length: **${wordLimit} words**
Tone: ${tone} | Audience: ${audience} level

FORMAT RULES:
- Use **[SECTION LABEL]** for each section header
- Use *stage directions* in italics for camera/action notes
- Use **bold** for emphasis on key words to stress when speaking
- Separate each section with a clear divider line (---)

---
**[HOOK — 0:00 to 0:15]**

*[Open with a close-up shot or attention-grabbing visual]*

[Write 2-3 punchy sentences that immediately grab attention. Start with the most surprising stat, boldest claim, or most relatable pain point about ${topic}. End with a direct question to the viewer.]

---
**[INTRO — 0:15 to 0:30]**

*[Cut to presenter, friendly smile, energetic posture]*

[Write a warm, direct intro. State your name/channel if applicable. Tell them **exactly** what they'll learn in this video and **why it matters to them**. Create anticipation.]

---
**[MAIN CONTENT]**

**Point 1: [Write descriptive heading]** *(~${Math.round(wordLimit * 0.15)} words)*

*[B-ROLL: show relevant footage or graphics]*
*[ON-SCREEN TEXT: display key stat or phrase]*

[Write the complete script for this point. Speak naturally, use contractions. Include a specific example or story. Bold the most important words to emphasize.]

---

**Point 2: [Write descriptive heading]** *(~${Math.round(wordLimit * 0.15)} words)*

*[B-ROLL: suggest relevant visual]*
*[ON-SCREEN TEXT: key phrase]*

[Write complete script for point 2. Include data from research. Use a relatable analogy.]

---

**Point 3: [Write descriptive heading]** *(~${Math.round(wordLimit * 0.15)} words)*

*[B-ROLL: suggest visual]*
*[ON-SCREEN TEXT: key phrase]*

[Write complete script for point 3. Address a common misconception or objection.]

---

**Point 4: [Write descriptive heading]** *(~${Math.round(wordLimit * 0.15)} words)*

*[B-ROLL: suggest visual]*
*[ON-SCREEN TEXT: key phrase]*

[Write complete script for point 4. Include actionable advice.]

---

**Point 5: [Write descriptive heading]** *(~${Math.round(wordLimit * 0.15)} words)*

*[B-ROLL: suggest visual]*
*[ON-SCREEN TEXT: key phrase]*

[Write complete script for point 5. Build toward the conclusion.]

---
**[OUTRO — Last 0:30]**

*[Return to presenter, direct eye contact with camera]*

[Summarize the **3 most important takeaways** in 3 crisp sentences. Tell them exactly what to do next — subscribe, comment, watch the next video. End with a memorable, repeatable sign-off line.]

*[End card: show subscribe button, related videos]*

---

**[TOTAL ESTIMATED RUNTIME]:** [Calculate based on ~130 words per minute]

Research: ${research.slice(0, 2000)}
Keywords: ${keywords}

Write the COMPLETE script now, every section fully written.`,

  ad_copy: (topic, tone, audience, research, keywords, wordLimit) => `
Write 5 complete, professionally formatted ad copy variations for: **"${topic}"**
Tone: ${tone} | Audience: ${audience} level

FORMAT RULES:
- Use ## for each variation header
- Use **bold** for headlines and CTAs
- Use *italics* for subheadlines
- Clearly label every element

---

## Variation 1 — Problem/Solution

**Headline:** [Write a punchy 6-8 word headline focusing on the problem being solved]

*Subheadline: [Write a supporting 10-15 word line that introduces the solution]*

**Body Copy:**
[Write 2-3 sentences. Open with the pain point. Present the solution. Include a specific benefit or result.]

**CTA Button:** [Write exact button text — action verb + specific benefit]

---

## Variation 2 — Benefit/Outcome

**Headline:** [Write a headline focused on the transformation or result]

*Subheadline: [Write a supporting line about how they get there]*

**Body Copy:**
[Write 2-3 sentences focused on the end result. Paint the picture of life after using this. Include a specific metric or outcome if possible.]

**CTA Button:** [Write exact CTA text]

---

## Variation 3 — Social Proof/Authority

**Headline:** [Write a headline using credibility, numbers, or authority]

*Subheadline: [Write a supporting line with proof]*

**Body Copy:**
[Write 2-3 sentences with proof points, statistics from research, or social proof. Make claims specific and credible.]

**CTA Button:** [Write exact CTA text]

---

## Variation 4 — Urgency/Scarcity

**Headline:** [Write an urgency-driven headline]

*Subheadline: [Write a supporting line about why now]*

**Body Copy:**
[Write 2-3 sentences creating genuine urgency. Explain why waiting costs them. Include a time-sensitive or scarcity element.]

**CTA Button:** [Write exact CTA text — include urgency]

---

## Variation 5 — Curiosity/Story

**Headline:** [Write a curiosity-gap headline that creates an open loop]

*Subheadline: [Write a line that deepens the curiosity]*

**Body Copy:**
[Write 2-3 sentences that open a story or reveal a surprising insight. Leave them wanting to click to find out more.]

**CTA Button:** [Write exact CTA text]

---

## Bonus: Google Search Ad

**Headline 1:** [Max 30 chars — primary keyword focus]
**Headline 2:** [Max 30 chars — benefit focus]
**Headline 3:** [Max 30 chars — CTA focus]

*Description 1:* [Max 90 chars — expand on headline 1]
*Description 2:* [Max 90 chars — social proof or urgency]

---

## Copywriter's Notes
> **Best performing variation:** [Recommend which variation to test first and why]
> **A/B test suggestion:** [Suggest what specific element to split test]

Research: ${research.slice(0, 1000)}
Keywords: ${keywords}

Write ALL variations in full now.`,

  carousel: (topic, tone, audience, research, keywords, wordLimit) => `
Write a complete, professionally formatted 10-slide carousel about: **"${topic}"**
Tone: ${tone} | Audience: ${audience} level

FORMAT RULES:
- Use ## Slide N for each slide header  
- Use **bold** for slide titles and key points
- Use *italics* for supporting text and notes
- Use bullet points for slide content
- Include visual direction for each slide

---

## Slide 1 — Hook

**Title:** [Write a bold, scroll-stopping headline — big promise or surprising stat]

*Subtitle:* [Write a supporting line that makes them swipe — create curiosity or urgency]

*Visual direction: [Suggest color scheme, imagery, or graphic style]*

**Swipe prompt:** "Swipe to see →"

---

## Slide 2

**Title:** [Write a specific, insight-driven heading]

*Key content:*
- **[Point 1]:** [Write 1-2 sentence explanation]
- **[Point 2]:** [Write 1-2 sentence explanation]  
- **[Point 3]:** [Write 1-2 sentence explanation]

*Visual direction: [Suggest graphic or icon]*

---

## Slide 3

**Title:** [Write heading]

*Key content:*
- **[Point 1]:** [Explanation]
- **[Point 2]:** [Explanation]
- **[Point 3]:** [Explanation]

*Visual direction: [Suggestion]*

---

## Slide 4

**Title:** [Write heading]

*Key content:*
[Write 40-50 words of insight or a mini story/example for this slide]

*Visual direction: [Suggestion]*

---

## Slide 5

**Title:** [Write heading]

*Key content:*
- **[Point 1]:** [Explanation]
- **[Point 2]:** [Explanation]
- **[Point 3]:** [Explanation]

*Visual direction: [Suggestion]*

---

## Slide 6

**Title:** [Write heading — address a common myth or misconception]

> *"[Write a memorable, quotable statement about this topic]"*

[Write 2-3 sentences busting the myth or challenging conventional wisdom]

*Visual direction: [Suggestion]*

---

## Slide 7

**Title:** [Write heading — practical tips or how-to]

*Step-by-step:*
1. **[Step 1]:** [Explanation]
2. **[Step 2]:** [Explanation]
3. **[Step 3]:** [Explanation]
4. **[Step 4]:** [Explanation]

*Visual direction: [Suggestion]*

---

## Slide 8

**Title:** [Write heading — data or proof point]

*Key stats:*
- 📊 **[Stat 1]** — [Context]
- 📈 **[Stat 2]** — [Context]
- 💡 **[Insight]** — [Explanation]

*Visual direction: [Suggest data visualization style]*

---

## Slide 9 — Case Study/Example

**Title:** [Write heading — real example or transformation]

**The situation:** [Write 1-2 sentences setting the scene]

**What happened:** [Write 2-3 sentences describing the approach]

**The result:** *[Write the outcome in bold, specific terms]*

*Visual direction: [Suggest before/after or story visual]*

---

## Slide 10 — CTA

**Title:** [Write a strong, memorable closing statement]

*What you learned:*
- ✅ [Key takeaway 1]
- ✅ [Key takeaway 2]
- ✅ [Key takeaway 3]

**[Write your CTA]** — Follow for more | Save this post | DM me "[keyword]"

*Visual direction: [Suggest branded, high-contrast design]*

---

Research: ${research.slice(0, 1500)}
Keywords: ${keywords}

Write ALL 10 slides completely filled in now.`,

  twitter_thread: (topic, tone, audience, research, keywords, wordLimit) => `
Write a complete, professionally formatted Twitter/X thread about: **"${topic}"**
Target: **${Math.max(10, Math.round(wordLimit / 30))} tweets**
Tone: ${tone} | Audience: ${audience} level

FORMAT RULES:
- Number each tweet clearly: **Tweet 1/N:**
- Keep each tweet under 280 characters
- Use **bold** in the header to indicate emphasis (reader sees plain text)
- End thread tweet with a summary
- Include engagement hooks

---

**Tweet 1/N — HOOK:**
[Write a single punchy sentence that is the most shocking stat, boldest claim, or most relatable frustration about ${topic}. End with "🧵 Thread:"]

*[Character count: XX/280]*

---

**Tweet 2/N — Context:**
[Set up why this matters. Who is affected? What's at stake? Be specific.]

*[Character count: XX/280]*

---

**Tweet 3/N — Point 1:**
[First key insight. Lead with the most important word. Include a specific example or number.]

*[Character count: XX/280]*

---

**Tweet 4/N — Point 2:**
[Second key insight. Add a layer of depth. Surprise them.]

*[Character count: XX/280]*

---

**Tweet 5/N — Point 3:**
[Third key insight. Include a data point from research.]

*[Character count: XX/280]*

---

**Tweet 6/N — Counterintuitive take:**
[Challenge a common assumption. Start with "Most people think..." or "Conventional wisdom says..."]

*[Character count: XX/280]*

---

**Tweet 7/N — Story/Example:**
[Mini story or real example that proves your point. Make it concrete and visual.]

*[Character count: XX/280]*

---

**Tweet 8/N — Practical advice:**
[3-5 specific, actionable tips. Use line breaks for readability.]

*[Character count: XX/280]*

---

**Tweet 9/N — The bigger picture:**
[Zoom out. What does this mean for the future? What's the trend?]

*[Character count: XX/280]*

---

**Tweet 10/N — Summary:**
[Recap the 3 most important takeaways as a numbered list]

*[Character count: XX/280]*

---

**Tweet 11/N — CTA:**
[Tell them exactly what to do: follow for more, retweet tweet 1, reply with their experience, or click the link.]

*[Character count: XX/280]*

---

Research: ${research.slice(0, 1500)}
Keywords: ${keywords}

Write ALL tweets completely filled in now with real content.`,

  linkedin_post: (topic, tone, audience, research, keywords, wordLimit) => `
Write a complete, professionally formatted LinkedIn post about: **"${topic}"**
Target length: **${wordLimit} words**
Tone: ${tone} | Audience: ${audience} level

${FORMATTING_RULES}

LINKEDIN-SPECIFIC RULES:
- First line must stand alone — it's the preview before "see more"
- Use line breaks between every paragraph (LinkedIn doesn't render markdown headers)
- Use ➤ or • for bullet points
- Max 3-5 hashtags at the end

---

**[HOOK LINE — standalone, scroll-stopping]**
[Write ONE sentence. The most surprising, controversial, or relatable statement about ${topic}. This appears before "...see more" — make it impossible to ignore.]

[blank line]

[PARAGRAPH 1 — Expand the hook]
[Write 2-3 short sentences. What's the context? Why does this matter right now?]

[blank line]

[PARAGRAPH 2 — First main insight]
[Write 2-3 sentences with a specific point, example, or data. Be direct.]

[blank line]

[PARAGRAPH 3 — Second main insight]
[Write 2-3 sentences going deeper. Add a contrarian angle or surprising fact.]

[blank line]

[PARAGRAPH 4 — Third main insight]
[Write 2-3 sentences. Include practical, actionable advice.]

[blank line]

[PARAGRAPH 5 — Personal reflection or lesson]
[Write 2-3 sentences from a first-person perspective. Make it human and authentic.]

[blank line]

**The bottom line:**
[Write one powerful, memorable sentence that captures the entire post's message.]

[blank line]

[CTA — Question or action]
[Ask a specific, open-ended question that invites comments. Or tell them to save/share.]

[blank line]

#[Hashtag1] #[Hashtag2] #[Hashtag3] #[Hashtag4] #[Hashtag5]

---

Research: ${research.slice(0, 1500)}
Keywords: ${keywords}

Write the complete LinkedIn post now.`,

  email_newsletter: (topic, tone, audience, research, keywords, wordLimit) => `
Write a complete, professionally formatted email newsletter about: **"${topic}"**
Target length: **${wordLimit} words**
Tone: ${tone} | Audience: ${audience} level

${FORMATTING_RULES}

---

## Subject Lines (choose the best one)

**Option A:** [Write a curiosity-driven subject line, max 50 chars]
**Option B:** [Write a benefit-driven subject line, max 50 chars]
**Option C:** [Write a number/list format, max 50 chars]

*→ Recommended: Option [X] because [brief reason]*

**Preview text:** [Write 90 chars that complement the subject line and tease the content]

---

## Email Body

Hi [First Name],

*[Write a 2-3 sentence opening that feels personal and timely. Connect to something in the reader's world before introducing the topic.]*

---

## [Section 1 Heading — write a compelling subheading]

[Write 2-3 short paragraphs. Use **bold** for key terms. Include a specific insight or data point. Keep paragraphs to 3-4 sentences max.]

> *[Write a key insight as a pullquote that stands out visually]*

---

## [Section 2 Heading]

[Write 2-3 short paragraphs. Include a practical example or case study. Use bullet points if listing 3+ items.]

- **[Point 1]:** [Explanation]
- **[Point 2]:** [Explanation]
- **[Point 3]:** [Explanation]

---

## [Section 3 Heading]

[Write 2-3 short paragraphs with actionable advice. End with a transition to the CTA.]

---

## The One Thing to Remember

*[Write 1-2 sentences — the single most important takeaway they should remember from this email.]*

---

**[CTA Button Text]** → [URL placeholder]

*[Write 1-2 sentences under the CTA explaining what happens when they click and why they should]*

---

Talk soon,
[Your Name]

*P.S. — [Write a P.S. that either teases next week's issue or adds a bonus insight that didn't fit in the main email]*

---

Research: ${research.slice(0, 1500)}
Keywords: ${keywords}

Write the complete email newsletter now.`,

  product_description: (topic, tone, audience, research, keywords, wordLimit) => `
Write a complete, professionally formatted product description for: **"${topic}"**
Target length: **${wordLimit} words**
Tone: ${tone} | Audience: ${audience} level

${FORMATTING_RULES}

---

# [Write a benefit-driven product headline — max 10 words]

*[Write a subheadline that elaborates on the main benefit — max 20 words]*

---

## The Problem

[Write 2-3 sentences describing the pain point this product solves. Make the reader feel understood.]

## The Solution

[Write 2-3 sentences introducing the product as the answer. Focus on transformation, not features.]

---

## Key Benefits

- **[Benefit 1]:** [Write 1-2 sentences — lead with the benefit, then explain the feature that delivers it]
- **[Benefit 2]:** [Write 1-2 sentences]
- **[Benefit 3]:** [Write 1-2 sentences]
- **[Benefit 4]:** [Write 1-2 sentences]
- **[Benefit 5]:** [Write 1-2 sentences]

---

## What's Included

[Write 2-3 sentences about what the customer gets. Be specific about features, components, or deliverables.]

> *"[Write a realistic, compelling customer testimonial quote with a name and title]"*
> — [Name, Title/Company]

---

## Who It's For

*This is perfect for you if:*
- [Ideal customer description 1]
- [Ideal customer description 2]
- [Ideal customer description 3]

---

## [CTA Headline — create urgency]

[Write 2-3 sentences with urgency and a clear CTA. Overcome the final objection.]

**[CTA Button Text]**

---

**SEO Meta Description:** [Write exactly 155 chars]

Research: ${research.slice(0, 1000)}
Keywords: ${keywords}

Write the complete product description now.`,
}

export class DraftAgent {
  async runStreaming(input: DraftInput): Promise<DraftOutput> {
    const toneInstruction = TONE_INSTRUCTIONS[input.tone] || TONE_INSTRUCTIONS.professional
    const keywordsStr = (input.keywords || []).join(', ') || 'none specified'
    const wordLimit = input.wordLimit || 1000

    const brandVoiceSection = input.brandVoice
      ? `\nBrand Voice Guidelines (follow strictly):\n${input.brandVoice}`
      : ''

    const specificPrompt = CONTENT_PROMPTS[input.contentType]

    const userMessage = specificPrompt
      ? specificPrompt(input.topic, input.tone, input.targetAudience, input.research, keywordsStr, wordLimit)
      : `Write complete, publication-ready ${input.contentType} content for:
Topic: "${input.topic}"
Target length: ${wordLimit} words

${FORMATTING_RULES}

Follow this outline:
${input.outline}

Use these research insights:
${input.research.slice(0, 4000)}

Keywords to include naturally: ${keywordsStr}

Write the full content now. Every section complete. No placeholders. Properly formatted with headings, bold, italics.`

    let tokens = 0
    let cost = 0

    await completeStream(
      {
        task: 'draft',
        preferredTier: input.modelTier,
        stream: true,
        system: `You are an elite content writer producing publication-ready, professionally formatted content.
Tone: ${toneInstruction}
Audience: ${input.targetAudience} level.

CRITICAL RULES:
1. Write EVERYTHING in full — no placeholders, no [brackets with instructions], no "add your content here"
2. Use proper markdown formatting: # H1, ## H2, ### H3, **bold**, *italics*, bullet lists, numbered lists, > blockquotes
3. Every section must be completely written with real content
4. Use specific examples, real data points from research, concrete details
5. Target the specified word count
6. Make it professional, publication-ready, and properly structured${brandVoiceSection}`,
        messages: [{ role: 'user', content: userMessage }],
      },
      input.onChunk,
      (result) => {
        tokens = result.inputTokens + result.outputTokens
        cost = result.costUsd
      }
    )

    return { tokens, cost }
  }
}
