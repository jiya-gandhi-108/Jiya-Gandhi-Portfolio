import { complete, ModelTier } from '../../services/ai/modelRouter'

export interface OutlineInput {
  topic: string
  contentType: string
  funnelStage?: string
  targetAudience: string
  research: string
  avoidTopics: string[]
  modelTier: ModelTier
}

export interface OutlineOutput {
  output: string
  tokens: number
  cost: number
}

const CONTENT_INSTRUCTIONS: Record<string, string> = {
  blog: 'Structured blog post with H1, H2s, H3s, intro, body sections, and conclusion. 1500-2500 words target.',
  twitter_thread: '10-15 tweets numbered. Hook tweet, value tweets, CTA tweet. Each tweet under 280 chars.',
  linkedin_post: 'LinkedIn long-form: hook line, 3-5 short paragraphs, insight, CTA. 800-1200 words.',
  email_newsletter: 'Subject, preview text, greeting, 3 sections with headers, CTA button, sign-off.',
  ad_copy: '3 variations: each with headline (8 words), body (30 words), CTA. Label Variation A/B/C.',
  video_script: 'Hook (0-15s), intro (15-30s), 3-5 main points, CTA (last 30s). Include [B-ROLL] notes.',
  carousel: '10 slides: Slide 1 = hook, Slides 2-9 = one insight each, Slide 10 = CTA. Each ≤40 words.',
  product_description: 'Headline, subheadline, 3 benefit bullets, social proof section, urgency CTA.',
}

const FUNNEL_ANGLE: Record<string, string> = {
  TOFU: 'Awareness focus: educate, entertain, no selling. Answer broad questions.',
  MOFU: 'Consideration focus: compare options, address objections, build trust.',
  BOFU: 'Conversion focus: clear CTA, urgency, specific value proposition, proof.',
}

export class OutlineAgent {
  async run(input: OutlineInput): Promise<OutlineOutput> {
    const contentInstruction = CONTENT_INSTRUCTIONS[input.contentType] || CONTENT_INSTRUCTIONS.blog
    const funnelInstruction = input.funnelStage ? FUNNEL_ANGLE[input.funnelStage] || '' : ''

    const result = await complete({
      task: 'outline',
      preferredTier: input.modelTier,
      system: `You are a senior content strategist specializing in ${input.contentType} content.
Create a detailed, actionable content outline that a writer can follow precisely.`,
      messages: [{
        role: 'user',
        content: `Create a detailed content outline for:
Topic: ${input.topic}
Format: ${contentInstruction}
Funnel Stage: ${funnelInstruction}
Target Audience: ${input.targetAudience} level readers
Avoid these already-covered angles: ${input.avoidTopics.join(', ') || 'none'}

Research to incorporate:
${input.research.slice(0, 3000)}

Output a structured outline with:
- Title options (3 variations)
- Hook/opening approach
- Section headers with 1-2 sentence descriptions of what to cover
- Key data points to include in each section
- CTA approach
- Estimated word count per section`,
      }],
    })

    return {
      output: result.text,
      tokens: result.inputTokens + result.outputTokens,
      cost: result.costUsd,
    }
  }
}
