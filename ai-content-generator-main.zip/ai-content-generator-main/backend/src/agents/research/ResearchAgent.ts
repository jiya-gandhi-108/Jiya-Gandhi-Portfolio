import axios from 'axios'
import { complete } from '../../services/ai/modelRouter'
import { logger } from '../../utils/logger'
import { cacheGet, cacheSet } from '../../services/cache/redis'

export interface ResearchInput {
  topic: string
  useRealTimeData?: boolean
  keywords?: string[]
}

export interface ResearchOutput {
  output: string
  sources: string[]
  tokens: number
  cost: number
}

export class ResearchAgent {
  async run(input: ResearchInput): Promise<ResearchOutput> {
    let webContext = ''
    const sources: string[] = []

    if (input.useRealTimeData) {
      try {
        const webData = await this.fetchWebData(input.topic, input.keywords)
        webContext = webData.context
        sources.push(...webData.sources)
      } catch (err) {
        logger.warn('Web research failed, continuing without live data', err)
      }
    }

    const result = await complete({
      task: 'research',
      system: `You are a world-class content research analyst. Your job is to synthesize research 
into structured insights that a content writer will use. Be factual, specific, and cite data points.
Output format: JSON with keys: keyInsights (array), statistics (array), trends (array), 
audienceQuestions (array), competitorAngles (array), contentGaps (array)`,
      messages: [{
        role: 'user',
        content: `Research topic: "${input.topic}"
Keywords: ${(input.keywords || []).join(', ')}

${webContext ? `Live web data:\n${webContext}` : 'No live data available — use your knowledge.'}

Synthesize comprehensive research for writing high-quality content about this topic.
Focus on: key insights, surprising statistics, current trends (2025-2026), common audience questions,
angles competitors miss, and content gaps to exploit.`,
      }],
      cacheKey: `research:${input.topic}:${input.useRealTimeData}`,
      cacheTtl: 3600, // 1 hour
    })

    return {
      output: result.text,
      sources,
      tokens: result.inputTokens + result.outputTokens,
      cost: result.costUsd,
    }
  }

  private async fetchWebData(topic: string, keywords?: string[]): Promise<{ context: string; sources: string[] }> {
    const cacheKey = `serper:${topic}`
    const cached = await cacheGet(cacheKey)
    if (cached) return JSON.parse(cached)

    if (!process.env.SERPER_API_KEY) {
      return { context: '', sources: [] }
    }

    const queries = [
      topic,
      `${topic} statistics 2025 2026`,
      `${topic} trends latest`,
    ]

    const allResults: any[] = []

    for (const query of queries) {
      try {
        const { data } = await axios.post(
          'https://google.serper.dev/search',
          { q: query, num: 5 },
          {
            headers: {
              'X-API-KEY': process.env.SERPER_API_KEY,
              'Content-Type': 'application/json',
            },
            timeout: 8000,
          }
        )
        if (data.organic) allResults.push(...data.organic)
      } catch (err) {
        logger.warn(`Serper query failed for: ${query}`)
      }
    }

    const sources = allResults.slice(0, 10).map(r => r.link).filter(Boolean)
    const context = allResults
      .slice(0, 8)
      .map(r => `Source: ${r.link}\nTitle: ${r.title}\nSnippet: ${r.snippet}`)
      .join('\n\n---\n\n')

    const result = { context, sources }
    await cacheSet(cacheKey, JSON.stringify(result), 1800)

    return result
  }
}
