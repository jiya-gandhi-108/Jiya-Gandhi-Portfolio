/**
 * BullMQ Worker — runs agent jobs from the queue
 * Start with: npm run worker
 * 
 * This enables horizontal scaling: multiple workers can process
 * jobs concurrently without overloading the API server.
 */

import 'dotenv/config'
import { Worker, Queue } from 'bullmq'
import { AgentOrchestrator } from './src/services/ai/AgentOrchestrator'
import { initRedis, getRedisClient } from './src/services/cache/redis'
import { logger } from './src/utils/logger'

const QUEUE_NAME = 'agent-jobs'

async function startWorker() {
  await initRedis()
  const redis = getRedisClient()

  if (!redis) {
    logger.error('Redis not connected — worker cannot start')
    process.exit(1)
  }

  const worker = new Worker(
    QUEUE_NAME,
    async (job) => {
      logger.info(`Processing job ${job.id}: ${job.data.request.topic}`)

      const orchestrator = new AgentOrchestrator({
        jobId: job.data.jobId,
        workspaceId: job.data.workspaceId,
        userId: job.data.userId,
        request: job.data.request,
        modelTier: job.data.modelTier,
      })

      return await orchestrator.run()
    },
    {
      connection: redis as any,
      concurrency: 3,           // process up to 3 jobs at once
      limiter: {
        max: 10,
        duration: 60_000,       // max 10 jobs/minute per worker
      },
    }
  )

  worker.on('completed', (job) => {
    logger.info(`Job ${job.id} completed`)
  })

  worker.on('failed', (job, err) => {
    logger.error(`Job ${job?.id} failed:`, err)
  })

  worker.on('error', (err) => {
    logger.error('Worker error:', err)
  })

  logger.info(`🤖 Agent worker started (concurrency: 3)`)
  logger.info(`📋 Listening to queue: ${QUEUE_NAME}`)
}

startWorker().catch((err) => {
  logger.error('Failed to start worker', err)
  process.exit(1)
})
