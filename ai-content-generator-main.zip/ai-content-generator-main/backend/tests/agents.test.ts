/**
 * Tests for the Agent Pipeline
 * Run: npm test
 */

import { ResearchAgent } from '../src/agents/research/ResearchAgent'
import { OutlineAgent } from '../src/agents/outline/OutlineAgent'
import { EditorAgent } from '../src/agents/editor/EditorAgent'
import { SEOAgent } from '../src/agents/seo/SEOAgent'

// Mock the AI model router
jest.mock('../src/services/ai/modelRouter', () => ({
  complete: jest.fn().mockResolvedValue({
    text: '{"keyInsights": ["Test insight"], "statistics": [], "trends": [], "audienceQuestions": [], "competitorAngles": [], "contentGaps": []}',
    inputTokens: 100,
    outputTokens: 200,
    costUsd: 0.001,
    cached: false,
  }),
  completeStream: jest.fn().mockImplementation(async (_req, onChunk, onDone) => {
    onChunk('Test content ')
    onChunk('streaming output')
    onDone({ text: 'Test content streaming output', inputTokens: 100, outputTokens: 50, costUsd: 0.0005 })
  }),
  getTierForPreference: jest.fn().mockReturnValue('balanced'),
}))

jest.mock('../src/services/cache/redis', () => ({
  cacheGet: jest.fn().mockResolvedValue(null),
  cacheSet: jest.fn().mockResolvedValue(undefined),
  cacheGetOrSet: jest.fn().mockImplementation(async (_key, factory) => factory()),
}))

describe('ResearchAgent', () => {
  it('returns structured research output', async () => {
    const agent = new ResearchAgent()
    const result = await agent.run({
      topic: 'AI content generation',
      useRealTimeData: false,
    })

    expect(result).toHaveProperty('output')
    expect(result).toHaveProperty('sources')
    expect(result).toHaveProperty('tokens')
    expect(result).toHaveProperty('cost')
    expect(typeof result.output).toBe('string')
    expect(Array.isArray(result.sources)).toBe(true)
  })
})

describe('OutlineAgent', () => {
  it('generates an outline for blog content', async () => {
    const agent = new OutlineAgent()
    const result = await agent.run({
      topic: 'AI content generation trends',
      contentType: 'blog',
      funnelStage: 'TOFU',
      targetAudience: 'intermediate',
      research: 'Key insight: AI content tools are growing 40% YoY',
      avoidTopics: [],
      modelTier: 'balanced',
    })

    expect(result).toHaveProperty('output')
    expect(result).toHaveProperty('tokens')
    expect(result.tokens).toBeGreaterThan(0)
  })
})

describe('EditorAgent', () => {
  it('edits content and returns improvements', async () => {
    const agent = new EditorAgent()
    const result = await agent.run({
      content: '# Test Article\n\nThis is a test article about AI. It is very interesting and amazing.',
      tone: 'professional',
      targetAudience: 'intermediate',
      modelTier: 'balanced',
    })

    expect(result).toHaveProperty('output')
    expect(result).toHaveProperty('editsApplied')
    expect(Array.isArray(result.editsApplied)).toBe(true)
  })
})

describe('SEOAgent', () => {
  it('returns SEO-optimized content with scores', async () => {
    // Override mock for this test to return proper JSON
    const { complete } = require('../src/services/ai/modelRouter')
    complete.mockResolvedValueOnce({
      text: JSON.stringify({
        optimizedContent: '# Optimized Title\n\nOptimized content here.',
        metaTitle: 'Test Meta Title | Brand',
        metaDescription: 'A 155-character meta description for the content.',
        seoScore: 82,
        readabilityScore: 74,
        changesApplied: ['Added keyword to H1', 'Improved meta description'],
      }),
      inputTokens: 200,
      outputTokens: 300,
      costUsd: 0.002,
      cached: false,
    })

    const agent = new SEOAgent()
    const result = await agent.run({
      content: '# Test Article\n\nContent about AI tools.',
      topic: 'AI tools',
      keywords: ['AI tools', 'content generation'],
      contentType: 'blog',
    })

    expect(result.seoScore).toBeGreaterThanOrEqual(0)
    expect(result.seoScore).toBeLessThanOrEqual(100)
    expect(result.readabilityScore).toBeGreaterThanOrEqual(0)
    expect(result).toHaveProperty('metaTitle')
    expect(result).toHaveProperty('optimizedContent')
  })
})
