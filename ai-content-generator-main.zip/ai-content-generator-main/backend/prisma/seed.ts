import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Create demo workspace
  const workspace = await prisma.workspace.upsert({
    where: { slug: 'demo-workspace' },
    update: {},
    create: {
      name: 'Demo Workspace',
      slug: 'demo-workspace',
      plan: 'pro',
    },
  })

  // Workspace settings
  await prisma.workspaceSettings.upsert({
    where: { workspaceId: workspace.id },
    update: {},
    create: {
      workspaceId: workspace.id,
      defaultTone: 'professional',
      defaultContentType: 'blog',
      modelPreference: 'balanced',
      autoSeoOptimize: true,
      niche: 'SaaS & Technology',
    },
  })

  // Brand voice
  await prisma.brandVoice.upsert({
    where: { workspaceId: workspace.id },
    update: {},
    create: {
      workspaceId: workspace.id,
      tone: ['professional', 'authoritative'],
      vocabulary: ['build', 'ship', 'iterate', 'founders', 'growth'],
      avoidWords: ['synergy', 'leverage', 'paradigm', 'disruption', 'innovative'],
      writingStyle: 'Direct, clear, data-backed. Write like a knowledgeable peer, not a marketer. Short sentences. Real examples. No buzzwords.',
      sampleContent: [],
    },
  })

  // Sample integrations (not connected)
  const integrationTypes = ['wordpress', 'ghost', 'zapier', 'linkedin'] as const
  for (const type of integrationTypes) {
    await prisma.integration.upsert({
      where: { workspaceId_type: { workspaceId: workspace.id, type } },
      update: {},
      create: {
        workspaceId: workspace.id,
        type,
        name: type.charAt(0).toUpperCase() + type.slice(1),
        connected: false,
        config: {},
      },
    })
  }

  console.log('✅ Seed complete')
  console.log(`   Workspace: ${workspace.name} (${workspace.id})`)
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(() => prisma.$disconnect())
